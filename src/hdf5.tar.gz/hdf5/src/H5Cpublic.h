// (c) The HDF Group
#ifndef H5Cpublic_H
#define H5Cpublic_H
#include "H5public.h"
enum H5C_cache_incr_mode {
    H5C_incr__off,
    H5C_incr__threshold
};
enum H5C_cache_flash_incr_mode {
    H5C_flash_incr__off,
    H5C_flash_incr__add_space
};
enum H5C_cache_decr_mode {
    H5C_decr__off,
    H5C_decr__threshold,
    H5C_decr__age_out,
    H5C_decr__age_out_with_threshold
};
#endif
