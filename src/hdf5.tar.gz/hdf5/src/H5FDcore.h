// (c) The HDF Group
#ifndef H5FDcore_H
#define H5FDcore_H
#define H5FD_CORE (H5FDperform_init(H5FD_core_init))
#define H5FD_CORE_VALUE H5_VFD_CORE
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL hid_t H5FD_core_init(void);
H5_DLL herr_t H5Pset_fapl_core(hid_t fapl_id, size_t increment, hbool_t backing_store);
H5_DLL herr_t H5Pget_fapl_core(hid_t fapl_id, size_t *increment, hbool_t *backing_store);
#ifdef __cplusplus
}
#endif
#endif
