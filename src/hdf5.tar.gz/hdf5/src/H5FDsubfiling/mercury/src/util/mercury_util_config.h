// (c) The HDF Group
#ifndef MERCURY_UTIL_CONFIG_H
#define MERCURY_UTIL_CONFIG_H
#include "H5private.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define HG_UTIL_VERSION_MAJOR 4
#define HG_UTIL_VERSION_MINOR 0
#define HG_UTIL_VERSION_PATCH 0
#define HG_UTIL_SUCCESS 0
#define HG_UTIL_FAIL    -1
#include <mercury_compiler_attributes.h>
#ifdef _WIN32
#define HG_UTIL_INLINE __inline
#else
#define HG_UTIL_INLINE __inline__
#endif
#define HG_UTIL_PUBLIC
#define HG_UTIL_PRIVATE
#define HG_UTIL_PLUGIN
#endif
