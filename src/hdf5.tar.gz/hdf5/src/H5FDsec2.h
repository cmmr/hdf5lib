// (c) The HDF Group
#ifndef H5FDsec2_H
#define H5FDsec2_H
#define H5FD_SEC2 (H5FDperform_init(H5FD_sec2_init))
#define H5FD_SEC2_VALUE H5_VFD_SEC2
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL hid_t H5FD_sec2_init(void);
H5_DLL herr_t H5Pset_fapl_sec2(hid_t fapl_id);
#ifdef __cplusplus
}
#endif
#endif
