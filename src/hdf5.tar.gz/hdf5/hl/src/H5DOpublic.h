// (c) The HDF Group
#ifndef H5DOpublic_H
#define H5DOpublic_H
#ifdef __cplusplus
extern "C" {
#endif
H5_HLDLL herr_t H5DOappend(hid_t dset_id, hid_t dxpl_id, unsigned axis, size_t extension, hid_t memtype,
                           const void *buf);
#ifndef H5_NO_DEPRECATED_SYMBOLS
H5_HLDLL herr_t H5DOwrite_chunk(hid_t dset_id, hid_t dxpl_id, uint32_t filters, const hsize_t *offset,
                                size_t data_size, const void *buf);
H5_HLDLL herr_t H5DOread_chunk(hid_t dset_id, hid_t dxpl_id, const hsize_t *offset, uint32_t *filters,
                               void *buf);
#endif
#ifdef __cplusplus
}
#endif
#endif
