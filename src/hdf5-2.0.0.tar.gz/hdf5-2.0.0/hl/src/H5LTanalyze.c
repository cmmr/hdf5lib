#if defined (__GNUC__)                                            
#if ((__GNUC__ * 100) + __GNUC_MINOR__) >= 402                    
#pragma GCC diagnostic ignored "-Wconversion"                     
#pragma GCC diagnostic ignored "-Wimplicit-function-declaration"  
#pragma GCC diagnostic ignored "-Wmissing-prototypes"             
#pragma GCC diagnostic ignored "-Wnested-externs"                 
#pragma GCC diagnostic ignored "-Wold-style-definition"           
#pragma GCC diagnostic ignored "-Wredundant-decls"                
#pragma GCC diagnostic ignored "-Wsign-compare"                   
#pragma GCC diagnostic ignored "-Wsign-conversion"                
#pragma GCC diagnostic ignored "-Wstrict-overflow"                
#pragma GCC diagnostic ignored "-Wstrict-prototypes"              
#pragma GCC diagnostic ignored "-Wimplicit-fallthrough"           
#if !defined (__clang__)                                          
#pragma GCC diagnostic ignored "-Wlarger-than="                   
#pragma GCC diagnostic ignored "-Wsuggest-attribute=const"        
#pragma GCC diagnostic ignored "-Wsuggest-attribute=pure"         
#endif                                                            
#pragma GCC diagnostic ignored "-Wswitch-default"                 
#pragma GCC diagnostic ignored "-Wunused-function"                
#pragma GCC diagnostic ignored "-Wunused-macros"                  
#pragma GCC diagnostic ignored "-Wunused-parameter"               
#endif                                                            
#if ((__GNUC__ * 100) + __GNUC_MINOR__) >= 600                    
#pragma GCC diagnostic ignored "-Wnull-dereference"               
#endif                                                            
#elif defined _MSC_VER                                            
#pragma warning(push, 1)                                          
#endif                                                            
#line 1 "hl/src//H5LTanalyze.c"

#include <stdint.h>

#line 8 "hl/src//H5LTanalyze.c"

#define  YY_INT_ALIGNED short int

#define yy_create_buffer H5LTyy_create_buffer
#define yy_delete_buffer H5LTyy_delete_buffer
#define yy_scan_buffer H5LTyy_scan_buffer
#define yy_scan_string H5LTyy_scan_string
#define yy_scan_bytes H5LTyy_scan_bytes
#define yy_init_buffer H5LTyy_init_buffer
#define yy_flush_buffer H5LTyy_flush_buffer
#define yy_load_buffer_state H5LTyy_load_buffer_state
#define yy_switch_to_buffer H5LTyy_switch_to_buffer
#define yypush_buffer_state H5LTyypush_buffer_state
#define yypop_buffer_state H5LTyypop_buffer_state
#define yyensure_buffer_stack H5LTyyensure_buffer_stack
#define yy_flex_debug H5LTyy_flex_debug
#define yyin H5LTyyin
#define yyleng H5LTyyleng
#define yylex H5LTyylex
#define yylineno H5LTyylineno
#define yyout H5LTyyout
#define yyrestart H5LTyyrestart
#define yytext H5LTyytext
#define yywrap H5LTyywrap
#define yyalloc H5LTyyalloc
#define yyrealloc H5LTyyrealloc
#define yyfree H5LTyyfree

#define FLEX_SCANNER
#define YY_FLEX_MAJOR_VERSION 2
#define YY_FLEX_MINOR_VERSION 6
#define YY_FLEX_SUBMINOR_VERSION 4
#if YY_FLEX_SUBMINOR_VERSION > 0
#define FLEX_BETA
#endif

#ifdef yy_create_buffer
#define H5LTyy_create_buffer_ALREADY_DEFINED
#else
#define yy_create_buffer H5LTyy_create_buffer
#endif

#ifdef yy_delete_buffer
#define H5LTyy_delete_buffer_ALREADY_DEFINED
#else
#define yy_delete_buffer H5LTyy_delete_buffer
#endif

#ifdef yy_scan_buffer
#define H5LTyy_scan_buffer_ALREADY_DEFINED
#else
#define yy_scan_buffer H5LTyy_scan_buffer
#endif

#ifdef yy_scan_string
#define H5LTyy_scan_string_ALREADY_DEFINED
#else
#define yy_scan_string H5LTyy_scan_string
#endif

#ifdef yy_scan_bytes
#define H5LTyy_scan_bytes_ALREADY_DEFINED
#else
#define yy_scan_bytes H5LTyy_scan_bytes
#endif

#ifdef yy_init_buffer
#define H5LTyy_init_buffer_ALREADY_DEFINED
#else
#define yy_init_buffer H5LTyy_init_buffer
#endif

#ifdef yy_flush_buffer
#define H5LTyy_flush_buffer_ALREADY_DEFINED
#else
#define yy_flush_buffer H5LTyy_flush_buffer
#endif

#ifdef yy_load_buffer_state
#define H5LTyy_load_buffer_state_ALREADY_DEFINED
#else
#define yy_load_buffer_state H5LTyy_load_buffer_state
#endif

#ifdef yy_switch_to_buffer
#define H5LTyy_switch_to_buffer_ALREADY_DEFINED
#else
#define yy_switch_to_buffer H5LTyy_switch_to_buffer
#endif

#ifdef yypush_buffer_state
#define H5LTyypush_buffer_state_ALREADY_DEFINED
#else
#define yypush_buffer_state H5LTyypush_buffer_state
#endif

#ifdef yypop_buffer_state
#define H5LTyypop_buffer_state_ALREADY_DEFINED
#else
#define yypop_buffer_state H5LTyypop_buffer_state
#endif

#ifdef yyensure_buffer_stack
#define H5LTyyensure_buffer_stack_ALREADY_DEFINED
#else
#define yyensure_buffer_stack H5LTyyensure_buffer_stack
#endif

#ifdef yylex
#define H5LTyylex_ALREADY_DEFINED
#else
#define yylex H5LTyylex
#endif

#ifdef yyrestart
#define H5LTyyrestart_ALREADY_DEFINED
#else
#define yyrestart H5LTyyrestart
#endif

#ifdef yylex_init
#define H5LTyylex_init_ALREADY_DEFINED
#else
#define yylex_init H5LTyylex_init
#endif

#ifdef yylex_init_extra
#define H5LTyylex_init_extra_ALREADY_DEFINED
#else
#define yylex_init_extra H5LTyylex_init_extra
#endif

#ifdef yylex_destroy
#define H5LTyylex_destroy_ALREADY_DEFINED
#else
#define yylex_destroy H5LTyylex_destroy
#endif

#ifdef yyget_debug
#define H5LTyyget_debug_ALREADY_DEFINED
#else
#define yyget_debug H5LTyyget_debug
#endif

#ifdef yyset_debug
#define H5LTyyset_debug_ALREADY_DEFINED
#else
#define yyset_debug H5LTyyset_debug
#endif

#ifdef yyget_extra
#define H5LTyyget_extra_ALREADY_DEFINED
#else
#define yyget_extra H5LTyyget_extra
#endif

#ifdef yyset_extra
#define H5LTyyset_extra_ALREADY_DEFINED
#else
#define yyset_extra H5LTyyset_extra
#endif

#ifdef yyget_in
#define H5LTyyget_in_ALREADY_DEFINED
#else
#define yyget_in H5LTyyget_in
#endif

#ifdef yyset_in
#define H5LTyyset_in_ALREADY_DEFINED
#else
#define yyset_in H5LTyyset_in
#endif

#ifdef yyget_out
#define H5LTyyget_out_ALREADY_DEFINED
#else
#define yyget_out H5LTyyget_out
#endif

#ifdef yyset_out
#define H5LTyyset_out_ALREADY_DEFINED
#else
#define yyset_out H5LTyyset_out
#endif

#ifdef yyget_leng
#define H5LTyyget_leng_ALREADY_DEFINED
#else
#define yyget_leng H5LTyyget_leng
#endif

#ifdef yyget_text
#define H5LTyyget_text_ALREADY_DEFINED
#else
#define yyget_text H5LTyyget_text
#endif

#ifdef yyget_lineno
#define H5LTyyget_lineno_ALREADY_DEFINED
#else
#define yyget_lineno H5LTyyget_lineno
#endif

#ifdef yyset_lineno
#define H5LTyyset_lineno_ALREADY_DEFINED
#else
#define yyset_lineno H5LTyyset_lineno
#endif

#ifdef yywrap
#define H5LTyywrap_ALREADY_DEFINED
#else
#define yywrap H5LTyywrap
#endif

#ifdef yyalloc
#define H5LTyyalloc_ALREADY_DEFINED
#else
#define yyalloc H5LTyyalloc
#endif

#ifdef yyrealloc
#define H5LTyyrealloc_ALREADY_DEFINED
#else
#define yyrealloc H5LTyyrealloc
#endif

#ifdef yyfree
#define H5LTyyfree_ALREADY_DEFINED
#else
#define yyfree H5LTyyfree
#endif

#ifdef yytext
#define H5LTyytext_ALREADY_DEFINED
#else
#define yytext H5LTyytext
#endif

#ifdef yyleng
#define H5LTyyleng_ALREADY_DEFINED
#else
#define yyleng H5LTyyleng
#endif

#ifdef yyin
#define H5LTyyin_ALREADY_DEFINED
#else
#define yyin H5LTyyin
#endif

#ifdef yyout
#define H5LTyyout_ALREADY_DEFINED
#else
#define yyout H5LTyyout
#endif

#ifdef yy_flex_debug
#define H5LTyy_flex_debug_ALREADY_DEFINED
#else
#define yy_flex_debug H5LTyy_flex_debug
#endif

#ifdef yylineno
#define H5LTyylineno_ALREADY_DEFINED
#else
#define yylineno H5LTyylineno
#endif

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#ifndef FLEXINT_H
#define FLEXINT_H

#if defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L

#ifndef __STDC_LIMIT_MACROS
#define __STDC_LIMIT_MACROS 1
#endif

#include <inttypes.h>
typedef int8_t flex_int8_t;
typedef uint8_t flex_uint8_t;
typedef int16_t flex_int16_t;
typedef uint16_t flex_uint16_t;
typedef int32_t flex_int32_t;
typedef uint32_t flex_uint32_t;
#else
typedef signed char flex_int8_t;
typedef short int flex_int16_t;
typedef int flex_int32_t;
typedef unsigned char flex_uint8_t; 
typedef unsigned short int flex_uint16_t;
typedef unsigned int flex_uint32_t;

#ifndef INT8_MIN
#define INT8_MIN               (-128)
#endif
#ifndef INT16_MIN
#define INT16_MIN              (-32767-1)
#endif
#ifndef INT32_MIN
#define INT32_MIN              (-2147483647-1)
#endif
#ifndef INT8_MAX
#define INT8_MAX               (127)
#endif
#ifndef INT16_MAX
#define INT16_MAX              (32767)
#endif
#ifndef INT32_MAX
#define INT32_MAX              (2147483647)
#endif
#ifndef UINT8_MAX
#define UINT8_MAX              (255U)
#endif
#ifndef UINT16_MAX
#define UINT16_MAX             (65535U)
#endif
#ifndef UINT32_MAX
#define UINT32_MAX             (4294967295U)
#endif

#ifndef SIZE_MAX
#define SIZE_MAX               (~(size_t)0)
#endif

#endif 

#endif 

#define yyconst const

#if defined(__GNUC__) && __GNUC__ >= 3
#define yynoreturn __attribute__((__noreturn__))
#else
#define yynoreturn
#endif

#define YY_NULL 0

#define YY_SC_TO_UI(c) ((YY_CHAR) (c))

#define BEGIN (yy_start) = 1 + 2 *

#define YY_START (((yy_start) - 1) / 2)
#define YYSTATE YY_START

#define YY_STATE_EOF(state) (YY_END_OF_BUFFER + state + 1)

#define YY_NEW_FILE yyrestart( yyin  )
#define YY_END_OF_BUFFER_CHAR 0

#ifndef YY_BUF_SIZE
#ifdef __ia64__

#define YY_BUF_SIZE 32768
#else
#define YY_BUF_SIZE 16384
#endif 
#endif

#define YY_STATE_BUF_SIZE   ((YY_BUF_SIZE + 2) * sizeof(yy_state_type))

#ifndef YY_TYPEDEF_YY_BUFFER_STATE
#define YY_TYPEDEF_YY_BUFFER_STATE
typedef struct yy_buffer_state *YY_BUFFER_STATE;
#endif

#ifndef YY_TYPEDEF_YY_SIZE_T
#define YY_TYPEDEF_YY_SIZE_T
typedef size_t yy_size_t;
#endif

extern int yyleng;

extern FILE *yyin, *yyout;

#define EOB_ACT_CONTINUE_SCAN 0
#define EOB_ACT_END_OF_FILE 1
#define EOB_ACT_LAST_MATCH 2
    
    #define YY_LESS_LINENO(n)
    #define YY_LINENO_REWIND_TO(ptr)
    

#define yyless(n) \
	do \
		{ \
		 \
        int yyless_macro_arg = (n); \
        YY_LESS_LINENO(yyless_macro_arg);\
		*yy_cp = (yy_hold_char); \
		YY_RESTORE_YY_MORE_OFFSET \
		(yy_c_buf_p) = yy_cp = yy_bp + yyless_macro_arg - YY_MORE_ADJ; \
		YY_DO_BEFORE_ACTION;  \
		} \
	while ( 0 )
#define unput(c) yyunput( c, (yytext_ptr)  )

#ifndef YY_STRUCT_YY_BUFFER_STATE
#define YY_STRUCT_YY_BUFFER_STATE
struct yy_buffer_state
	{
	FILE *yy_input_file;

	char *yy_ch_buf;		
	char *yy_buf_pos;		

	
	int yy_buf_size;

	
	int yy_n_chars;

	
	int yy_is_our_buffer;

	
	int yy_is_interactive;

	
	int yy_at_bol;

    int yy_bs_lineno; 
    int yy_bs_column; 

	
	int yy_fill_buffer;

	int yy_buffer_status;

#define YY_BUFFER_NEW 0
#define YY_BUFFER_NORMAL 1
	
#define YY_BUFFER_EOF_PENDING 2

	};
#endif 

static size_t yy_buffer_stack_top = 0; 
static size_t yy_buffer_stack_max = 0; 
static YY_BUFFER_STATE * yy_buffer_stack = NULL; 

#define YY_CURRENT_BUFFER ( (yy_buffer_stack) \
                          ? (yy_buffer_stack)[(yy_buffer_stack_top)] \
                          : NULL)

#define YY_CURRENT_BUFFER_LVALUE (yy_buffer_stack)[(yy_buffer_stack_top)]

static char yy_hold_char;
static int yy_n_chars;		
int yyleng;

static char *yy_c_buf_p = NULL;
static int yy_init = 0;		
static int yy_start = 0;	

static int yy_did_buffer_switch_on_eof;

void yyrestart ( FILE *input_file  );
void yy_switch_to_buffer ( YY_BUFFER_STATE new_buffer  );
YY_BUFFER_STATE yy_create_buffer ( FILE *file, int size  );
void yy_delete_buffer ( YY_BUFFER_STATE b  );
void yy_flush_buffer ( YY_BUFFER_STATE b  );
void yypush_buffer_state ( YY_BUFFER_STATE new_buffer  );
void yypop_buffer_state ( void );

static void yyensure_buffer_stack ( void );
static void yy_load_buffer_state ( void );
static void yy_init_buffer ( YY_BUFFER_STATE b, FILE *file  );
#define YY_FLUSH_BUFFER yy_flush_buffer( YY_CURRENT_BUFFER )

YY_BUFFER_STATE yy_scan_buffer ( char *base, yy_size_t size  );
YY_BUFFER_STATE yy_scan_string ( const char *yy_str  );
YY_BUFFER_STATE yy_scan_bytes ( const char *bytes, int len  );

void *yyalloc ( yy_size_t  );
void *yyrealloc ( void *, yy_size_t  );
void yyfree ( void *  );

#define yy_new_buffer yy_create_buffer
#define yy_set_interactive(is_interactive) \
	{ \
	if ( ! YY_CURRENT_BUFFER ){ \
        yyensure_buffer_stack (); \
		YY_CURRENT_BUFFER_LVALUE =    \
            yy_create_buffer( yyin, YY_BUF_SIZE ); \
	} \
	YY_CURRENT_BUFFER_LVALUE->yy_is_interactive = is_interactive; \
	}
#define yy_set_bol(at_bol) \
	{ \
	if ( ! YY_CURRENT_BUFFER ){\
        yyensure_buffer_stack (); \
		YY_CURRENT_BUFFER_LVALUE =    \
            yy_create_buffer( yyin, YY_BUF_SIZE ); \
	} \
	YY_CURRENT_BUFFER_LVALUE->yy_at_bol = at_bol; \
	}
#define YY_AT_BOL() (YY_CURRENT_BUFFER_LVALUE->yy_at_bol)

typedef flex_uint8_t YY_CHAR;

FILE *yyin = NULL, *yyout = NULL;

typedef int yy_state_type;

extern int yylineno;
int yylineno = 1;

extern char *yytext;
#ifdef yytext_ptr
#undef yytext_ptr
#endif
#define yytext_ptr yytext

static yy_state_type yy_get_previous_state ( void );
static yy_state_type yy_try_NUL_trans ( yy_state_type current_state  );
static int yy_get_next_buffer ( void );
static void yy_fatal_error ( const char* msg  );

#define YY_DO_BEFORE_ACTION \
	(yytext_ptr) = yy_bp; \
	yyleng = (int) (yy_cp - yy_bp); \
	(yy_hold_char) = *yy_cp; \
	*yy_cp = '\0'; \
	(yy_c_buf_p) = yy_cp;
#define YY_NUM_RULES 81
#define YY_END_OF_BUFFER 82

struct yy_trans_info
	{
	flex_int32_t yy_verify;
	flex_int32_t yy_nxt;
	};
static const flex_int16_t yy_accept[361] =
    {   0,
       80,   80,   82,   81,   80,   81,   72,   78,   79,   81,
       81,   81,   81,   76,   77,   74,   75,   80,    0,   72,
        0,    0,    0,    0,    0,   73,    0,    0,    0,    0,
        0,   54,    0,    0,    0,    0,    0,   55,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,   53,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,   71,   52,    0,    0,    0,   61,   65,
        0,    0,    0,    0,    0,    0,    0,    0,    0,   67,

       70,   66,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,   69,    0,    0,    0,    0,    0,
        0,    0,    0,   51,    0,    0,    0,   68,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,   64,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    1,    2,    0,    0,    0,    0,
        0,    0,    9,   10,    0,    0,   63,    0,    0,   60,

        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    3,    4,    5,    6,    7,    8,   11,   12,
       13,   14,   15,   16,    0,    0,    0,    0,   59,    0,
        0,    0,   62,   28,   29,   30,   31,   32,   33,    0,
        0,    0,   22,    0,    0,    0,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
       17,    0,    0,    0,    0,   24,    0,    0,    0,   23,
        0,    0,    0,   57,    0,    0,    0,    0,   36,   37,
        0,   39,    0,   26,   18,   20,   19,    0,   25,    0,

       56,   58,    0,    0,   40,    0,    0,    0,   27,   21,
        0,    0,    0,   38,    0,   41,    0,    0,    0,    0,
        0,    0,    0,    0,    0,    0,    0,   34,   35,    0,
        0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
        0,   42,   43,   44,   45,   46,   47,    0,    0,    0,
        0,    0,    0,    0,   48,    0,   49,    0,   50,    0
    } ;

static const YY_CHAR yy_ec[256] =
    {   0,
        1,    1,    1,    1,    1,    1,    1,    1,    2,    2,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    2,    1,    3,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    4,    5,    6,
        7,    8,    9,   10,    4,   11,    4,   12,   13,    1,
        1,    1,    1,    1,   14,   15,   16,   17,   18,   19,
       20,   21,   22,    1,    1,   23,   24,   25,   26,   27,
       28,   29,   30,   31,   32,   33,    1,   34,   35,   36,
       37,    1,   38,    1,   39,    1,    1,    1,    1,    1,

        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,   40,    1,   41,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1
    } ;

static const YY_CHAR yy_meta[42] =
    {   0,
        1,    1,    2,    3,    3,    3,    3,    3,    3,    3,
        3,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1
    } ;

static const flex_int16_t yy_base[363] =
    {   0,
        0,    0,  386,  387,  383,    0,    0,  387,  387,   12,
      375,  356,  351,  387,  387,  387,  387,  379,  377,    0,
      361,  343,  346,  348,  346,  387,  343,  346,  333,  332,
       17,  387,  352,   34,   15,  355,  346,  387,  338,   31,
      341,   28,  347,  350,  336,  331,   35,  339,  346,  342,
      322,  328,  332,  337,  324,  321,  326,  322,  332,  318,
      334,   45,  318,  328,  309,  324,  387,  325,  328,  314,
      309,  334,  314,  323,  305,  317,  312,  305,  293,   33,
      309,  305,  311,  387,  387,  293,   40,  288,  387,  387,
      295,  296,  285,  290,  290,   43,  296,   43,  306,  387,

      387,  387,  301,  286,   55,  278,  302,  296,  296,  295,
       71,   78,  292,  279,  283,  294,  274,  282,  276,  274,
       65,  279,   85,  264,  387,  292,  295,  292,   56,  289,
      292,  289,   71,  387,  273,  281,  271,  254,  275,  275,
      271,  270,  277,  248,  276,  279,  276,   80,   78,   83,
       85,  265,  264,   90,   92,   94,  263,  262,  256,  262,
      259,  254,  387,  253,  263,  250,  254,  241,   96,   99,
      101,  249,  243,  245,  242,  103,  102,  105,  248,  247,
      246,  245,  244,  243,  387,  387,  242,  241,  240,  239,
      238,  237,  387,  387,  103,  236,  387,  235,  230,  387,

      225,  123,  245,  231,  230,  229,  228,  227,  226,  229,
      210,  215,  209,  213,  212,  212,  215,  209,  213,  208,
      110,  211,  387,  387,  387,  387,  387,  387,  387,  387,
      387,  387,  387,  387,  217,  212,  202,  210,  387,  213,
      202,  201,  387,  387,  387,  387,  387,  387,  387,  195,
      208,  208,  387,  189,  195,  199,  204,  188,  202,  184,
      188,  188,  186,  194,  181,  195,  190,  176,  199,  199,
      387,  181,  172,  187,  181,  387,  171,  168,  169,  387,
      172,  176,  166,  387,  170,  176,  153,  186,  387,  387,
      172,   86,  166,  387,  387,  387,  387,  168,  387,  156,

      387,  387,  167,  175,  145,  173,  166,  163,  387,  387,
      132,  123,  164,  387,  153,  139,  167,  170,  167,  156,
      155,  146,  147,  154,  125,  126,  128,  387,  387,  145,
      141,  141,  148,  147,  146,  145,  144,  143,  133,  136,
      134,  387,  387,  387,  387,  387,  387,  134,  138,  128,
      135,  116,  124,  111,  387,  126,  387,   70,  387,  387,
      151,   74
    } ;

static const flex_int16_t yy_def[363] =
    {   0,
      360,    1,  360,  360,  360,  361,  362,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  361,  362,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,

      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,

      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,

      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,    0,
      360,  360
    } ;

static const flex_int16_t yy_nxt[429] =
    {   0,
        4,    5,    6,    7,    7,    7,    7,    7,    7,    7,
        7,    8,    9,    4,    4,   10,    4,    4,    4,    4,
       11,    4,    4,    4,    4,   12,    4,    4,    4,   13,
        4,    4,    4,    4,    4,    4,   14,   15,    4,   16,
       17,   21,   22,   36,   48,   49,   37,   39,   63,   40,
       57,   41,   42,   58,   97,   43,   53,   64,   44,   45,
       54,   79,  103,   46,  111,  104,   47,  114,  119,   55,
      152,   98,  115,   80,  112,  126,   20,  127,  153,  142,
      128,  129,  130,  143,  131,  157,  120,  132,  133,  145,
      306,  146,  179,  158,  147,  172,  173,  181,  174,  183,

      180,  175,  176,  359,  187,  182,  189,  184,  191,  177,
      204,  178,  188,  206,  190,  208,  192,  217,  205,  214,
      219,  207,  218,  209,  307,  215,  220,  221,  216,  235,
      241,  242,  261,  236,  222,  262,  317,  320,  318,  333,
      335,  319,  337,  358,  357,  321,  356,  334,  336,  355,
      338,   19,  354,   19,  353,  352,  351,  350,  349,  348,
      347,  346,  345,  344,  343,  342,  341,  340,  339,  332,
      331,  330,  329,  328,  327,  326,  325,  324,  323,  322,
      316,  315,  314,  313,  312,  311,  310,  309,  308,  305,
      304,  303,  302,  301,  300,  299,  298,  297,  296,  295,

      294,  293,  292,  291,  290,  289,  288,  287,  286,  285,
      284,  283,  282,  281,  280,  279,  278,  277,  276,  275,
      274,  273,  272,  271,  270,  269,  268,  267,  266,  265,
      264,  263,  260,  259,  258,  257,  256,  255,  254,  253,
      252,  251,  250,  249,  248,  247,  246,  245,  244,  243,
      240,  239,  238,  237,  234,  233,  232,  231,  230,  229,
      228,  227,  226,  225,  224,  223,  213,  212,  211,  210,
      203,  202,  201,  200,  199,  198,  197,  196,  195,  194,
      193,  186,  185,  171,  170,  169,  168,  167,  166,  165,
      164,  163,  162,  161,  160,  159,  156,  155,  154,  151,

      150,  149,  148,  144,  141,  140,  139,  138,  137,  136,
      135,  134,  125,  124,  123,  122,  121,  118,  117,  116,
      113,  110,  109,  108,  107,  106,  105,  102,  101,  100,
       99,   96,   95,   94,   93,   92,   91,   90,   89,   88,
       87,   86,   85,   84,   83,   82,   81,   78,   77,   76,
       75,   74,   73,   72,   71,   70,   69,   68,   67,   66,
       65,   62,   61,   60,   59,   56,   52,   51,   50,   38,
       35,   34,   33,   32,   31,   30,   29,   28,   27,   26,
       18,   25,   24,   23,   18,  360,    3,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,

      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360
    } ;

static const flex_int16_t yy_chk[429] =
    {   0,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,   10,   10,   31,   35,   35,   31,   34,   47,   34,
       42,   34,   34,   42,   80,   34,   40,   47,   34,   34,
       40,   62,   87,   34,   96,   87,   34,   98,  105,   40,
      129,   80,   98,   62,   96,  111,  362,  111,  129,  121,
      111,  111,  112,  121,  112,  133,  105,  112,  112,  123,
      292,  123,  149,  133,  123,  148,  148,  150,  148,  151,

      149,  148,  148,  358,  154,  150,  155,  151,  156,  148,
      169,  148,  154,  170,  155,  171,  156,  177,  169,  176,
      178,  170,  177,  171,  292,  176,  178,  178,  176,  195,
      202,  202,  221,  195,  178,  221,  311,  312,  311,  325,
      326,  311,  327,  356,  354,  312,  353,  325,  326,  352,
      327,  361,  351,  361,  350,  349,  348,  341,  340,  339,
      338,  337,  336,  335,  334,  333,  332,  331,  330,  324,
      323,  322,  321,  320,  319,  318,  317,  316,  315,  313,
      308,  307,  306,  305,  304,  303,  300,  298,  293,  291,
      288,  287,  286,  285,  283,  282,  281,  279,  278,  277,

      275,  274,  273,  272,  270,  269,  268,  267,  266,  265,
      264,  263,  262,  261,  260,  259,  258,  257,  256,  255,
      254,  252,  251,  250,  242,  241,  240,  238,  237,  236,
      235,  222,  220,  219,  218,  217,  216,  215,  214,  213,
      212,  211,  210,  209,  208,  207,  206,  205,  204,  203,
      201,  199,  198,  196,  192,  191,  190,  189,  188,  187,
      184,  183,  182,  181,  180,  179,  175,  174,  173,  172,
      168,  167,  166,  165,  164,  162,  161,  160,  159,  158,
      157,  153,  152,  147,  146,  145,  144,  143,  142,  141,
      140,  139,  138,  137,  136,  135,  132,  131,  130,  128,

      127,  126,  124,  122,  120,  119,  118,  117,  116,  115,
      114,  113,  110,  109,  108,  107,  106,  104,  103,   99,
       97,   95,   94,   93,   92,   91,   88,   86,   83,   82,
       81,   79,   78,   77,   76,   75,   74,   73,   72,   71,
       70,   69,   68,   66,   65,   64,   63,   61,   60,   59,
       58,   57,   56,   55,   54,   53,   52,   51,   50,   49,
       48,   46,   45,   44,   43,   41,   39,   37,   36,   33,
       30,   29,   28,   27,   25,   24,   23,   22,   21,   19,
       18,   13,   12,   11,    5,    3,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,

      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360,  360,  360,
      360,  360,  360,  360,  360,  360,  360,  360
    } ;

static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;

extern int yy_flex_debug;
int yy_flex_debug = 0;

#define REJECT reject_used_but_not_detected
#define yymore() yymore_used_but_not_detected
#define YY_MORE_ADJ 0
#define YY_RESTORE_YY_MORE_OFFSET
char *yytext;
#line 1 "hl/src//H5LTanalyze.l"

#line 28 "hl/src//H5LTanalyze.l"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <hdf5.h>

#include "H5private.h"
#include "H5LTparse.h"

static char *trim_quotes(const char *);
static int my_yyinput(char *, int);
#undef YY_INPUT
#define YY_INPUT(b, r, ms) (r=my_yyinput(b, ms))
#define token(x)        (int)x
#define hid(x)          (hid_t)x

#ifdef  YY_BUF_SIZE
#undef  YY_BUF_SIZE
#endif
#define YY_BUF_SIZE        262144    

extern char *myinput;
extern size_t input_len;

#line 958 "hl/src//H5LTanalyze.c"
#line 959 "hl/src//H5LTanalyze.c"

#define INITIAL 0

#ifndef YY_EXTRA_TYPE
#define YY_EXTRA_TYPE void *
#endif

static int yy_init_globals ( void );

int yylex_destroy ( void );

int yyget_debug ( void );

void yyset_debug ( int debug_flag  );

YY_EXTRA_TYPE yyget_extra ( void );

void yyset_extra ( YY_EXTRA_TYPE user_defined  );

FILE *yyget_in ( void );

void yyset_in  ( FILE * _in_str  );

FILE *yyget_out ( void );

void yyset_out  ( FILE * _out_str  );

			int yyget_leng ( void );

char *yyget_text ( void );

int yyget_lineno ( void );

void yyset_lineno ( int _line_number  );

#ifndef YY_SKIP_YYWRAP
#ifdef __cplusplus
extern "C" int yywrap ( void );
#else
extern int yywrap ( void );
#endif
#endif

#ifndef YY_NO_UNPUT
    
    static void yyunput ( int c, char *buf_ptr  );
    
#endif

#ifndef yytext_ptr
static void yy_flex_strncpy ( char *, const char *, int );
#endif

#ifdef YY_NEED_STRLEN
static int yy_flex_strlen ( const char * );
#endif

#ifndef YY_NO_INPUT
#ifdef __cplusplus
static int yyinput ( void );
#else
static int input ( void );
#endif

#endif

#ifndef YY_READ_BUF_SIZE
#ifdef __ia64__

#define YY_READ_BUF_SIZE 16384
#else
#define YY_READ_BUF_SIZE 8192
#endif 
#endif

#ifndef ECHO

#define ECHO do { if (fwrite( yytext, (size_t) yyleng, 1, yyout )) {} } while (0)
#endif

#ifndef YY_INPUT
#define YY_INPUT(buf,result,max_size) \
	if ( YY_CURRENT_BUFFER_LVALUE->yy_is_interactive ) \
		{ \
		int c = '*'; \
		int n; \
		for ( n = 0; n < max_size && \
			     (c = getc( yyin )) != EOF && c != '\n'; ++n ) \
			buf[n] = (char) c; \
		if ( c == '\n' ) \
			buf[n++] = (char) c; \
		if ( c == EOF && ferror( yyin ) ) \
			YY_FATAL_ERROR( "input in flex scanner failed" ); \
		result = n; \
		} \
	else \
		{ \
		errno=0; \
		while ( (result = (int) fread(buf, 1, (yy_size_t) max_size, yyin)) == 0 && ferror(yyin)) \
			{ \
			if( errno != EINTR) \
				{ \
				YY_FATAL_ERROR( "input in flex scanner failed" ); \
				break; \
				} \
			errno=0; \
			clearerr(yyin); \
			} \
		}\
\

#endif

#ifndef yyterminate
#define yyterminate() return YY_NULL
#endif

#ifndef YY_START_STACK_INCR
#define YY_START_STACK_INCR 25
#endif

#ifndef YY_FATAL_ERROR
#define YY_FATAL_ERROR(msg) yy_fatal_error( msg )
#endif

#ifndef YY_DECL
#define YY_DECL_IS_OURS 1

extern int yylex (void);

#define YY_DECL int yylex (void)
#endif 

#ifndef YY_USER_ACTION
#define YY_USER_ACTION
#endif

#ifndef YY_BREAK
#define YY_BREAK break;
#endif

#define YY_RULE_SETUP \
	YY_USER_ACTION

YY_DECL
{
	yy_state_type yy_current_state;
	char *yy_cp, *yy_bp;
	int yy_act;
    
	if ( !(yy_init) )
		{
		(yy_init) = 1;

#ifdef YY_USER_INIT
		YY_USER_INIT;
#endif

		if ( ! (yy_start) )
			(yy_start) = 1;	

		if ( ! yyin )
			yyin = stdin;

		if ( ! yyout )
			yyout = Rstdout;

		if ( ! YY_CURRENT_BUFFER ) {
			yyensure_buffer_stack ();
			YY_CURRENT_BUFFER_LVALUE =
				yy_create_buffer( yyin, YY_BUF_SIZE );
		}

		yy_load_buffer_state(  );
		}

	{
#line 53 "hl/src//H5LTanalyze.l"

#line 1171 "hl/src//H5LTanalyze.c"

	while ( 1 )		
		{
		yy_cp = (yy_c_buf_p);

		
		*yy_cp = (yy_hold_char);

		
		yy_bp = yy_cp;

		yy_current_state = (yy_start);
yy_match:
		do
			{
			YY_CHAR yy_c = yy_ec[YY_SC_TO_UI(*yy_cp)] ;
			if ( yy_accept[yy_current_state] )
				{
				(yy_last_accepting_state) = yy_current_state;
				(yy_last_accepting_cpos) = yy_cp;
				}
			while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
				{
				yy_current_state = (int) yy_def[yy_current_state];
				if ( yy_current_state >= 361 )
					yy_c = yy_meta[yy_c];
				}
			yy_current_state = yy_nxt[yy_base[yy_current_state] + yy_c];
			++yy_cp;
			}
		while ( yy_base[yy_current_state] != 387 );

yy_find_action:
		yy_act = yy_accept[yy_current_state];
		if ( yy_act == 0 )
			{ 
			yy_cp = (yy_last_accepting_cpos);
			yy_current_state = (yy_last_accepting_state);
			yy_act = yy_accept[yy_current_state];
			}

		YY_DO_BEFORE_ACTION;

do_action:	

		switch ( yy_act )
	{ 
			case 0: 
			
			*yy_cp = (yy_hold_char);
			yy_cp = (yy_last_accepting_cpos);
			yy_current_state = (yy_last_accepting_state);
			goto yy_find_action;

case 1:
YY_RULE_SETUP
#line 55 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I8BE_TOKEN);}
	YY_BREAK
case 2:
YY_RULE_SETUP
#line 56 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I8LE_TOKEN);}
	YY_BREAK
case 3:
YY_RULE_SETUP
#line 57 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I16BE_TOKEN);}
	YY_BREAK
case 4:
YY_RULE_SETUP
#line 58 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I16LE_TOKEN);}
	YY_BREAK
case 5:
YY_RULE_SETUP
#line 59 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I32BE_TOKEN);}
	YY_BREAK
case 6:
YY_RULE_SETUP
#line 60 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I32LE_TOKEN);}
	YY_BREAK
case 7:
YY_RULE_SETUP
#line 61 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I64BE_TOKEN);}
	YY_BREAK
case 8:
YY_RULE_SETUP
#line 62 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_I64LE_TOKEN);}
	YY_BREAK
case 9:
YY_RULE_SETUP
#line 64 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U8BE_TOKEN);}
	YY_BREAK
case 10:
YY_RULE_SETUP
#line 65 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U8LE_TOKEN);}
	YY_BREAK
case 11:
YY_RULE_SETUP
#line 66 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U16BE_TOKEN);}
	YY_BREAK
case 12:
YY_RULE_SETUP
#line 67 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U16LE_TOKEN);}
	YY_BREAK
case 13:
YY_RULE_SETUP
#line 68 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U32BE_TOKEN);}
	YY_BREAK
case 14:
YY_RULE_SETUP
#line 69 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U32LE_TOKEN);}
	YY_BREAK
case 15:
YY_RULE_SETUP
#line 70 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U64BE_TOKEN);}
	YY_BREAK
case 16:
YY_RULE_SETUP
#line 71 "hl/src//H5LTanalyze.l"
{return hid(H5T_STD_U64LE_TOKEN);}
	YY_BREAK
case 17:
YY_RULE_SETUP
#line 73 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_CHAR_TOKEN);}
	YY_BREAK
case 18:
YY_RULE_SETUP
#line 74 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_SCHAR_TOKEN);}
	YY_BREAK
case 19:
YY_RULE_SETUP
#line 75 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_UCHAR_TOKEN);}
	YY_BREAK
case 20:
YY_RULE_SETUP
#line 76 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_SHORT_TOKEN);}
	YY_BREAK
case 21:
YY_RULE_SETUP
#line 77 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_USHORT_TOKEN);}
	YY_BREAK
case 22:
YY_RULE_SETUP
#line 78 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_INT_TOKEN);}
	YY_BREAK
case 23:
YY_RULE_SETUP
#line 79 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_UINT_TOKEN);}
	YY_BREAK
case 24:
YY_RULE_SETUP
#line 80 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_LONG_TOKEN);}
	YY_BREAK
case 25:
YY_RULE_SETUP
#line 81 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_ULONG_TOKEN);}
	YY_BREAK
case 26:
YY_RULE_SETUP
#line 82 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_LLONG_TOKEN);}
	YY_BREAK
case 27:
YY_RULE_SETUP
#line 83 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_ULLONG_TOKEN);}
	YY_BREAK
case 28:
YY_RULE_SETUP
#line 85 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F16BE_TOKEN);}
	YY_BREAK
case 29:
YY_RULE_SETUP
#line 86 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F16LE_TOKEN);}
	YY_BREAK
case 30:
YY_RULE_SETUP
#line 87 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F32BE_TOKEN);}
	YY_BREAK
case 31:
YY_RULE_SETUP
#line 88 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F32LE_TOKEN);}
	YY_BREAK
case 32:
YY_RULE_SETUP
#line 89 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F64BE_TOKEN);}
	YY_BREAK
case 33:
YY_RULE_SETUP
#line 90 "hl/src//H5LTanalyze.l"
{return hid(H5T_IEEE_F64LE_TOKEN);}
	YY_BREAK
case 34:
YY_RULE_SETUP
#line 91 "hl/src//H5LTanalyze.l"
{return hid(H5T_FLOAT_BFLOAT16BE_TOKEN);}
	YY_BREAK
case 35:
YY_RULE_SETUP
#line 92 "hl/src//H5LTanalyze.l"
{return hid(H5T_FLOAT_BFLOAT16LE_TOKEN);}
	YY_BREAK
case 36:
YY_RULE_SETUP
#line 93 "hl/src//H5LTanalyze.l"
{return hid(H5T_FLOAT_F8E4M3_TOKEN);}
	YY_BREAK
case 37:
YY_RULE_SETUP
#line 94 "hl/src//H5LTanalyze.l"
{return hid(H5T_FLOAT_F8E5M2_TOKEN);}
	YY_BREAK
case 38:
YY_RULE_SETUP
#line 95 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_FLOAT16_TOKEN);}
	YY_BREAK
case 39:
YY_RULE_SETUP
#line 96 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_FLOAT_TOKEN);}
	YY_BREAK
case 40:
YY_RULE_SETUP
#line 97 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_DOUBLE_TOKEN);}
	YY_BREAK
case 41:
YY_RULE_SETUP
#line 98 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_LDOUBLE_TOKEN);}
	YY_BREAK
case 42:
YY_RULE_SETUP
#line 100 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F16BE_TOKEN);}
	YY_BREAK
case 43:
YY_RULE_SETUP
#line 101 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F16LE_TOKEN);}
	YY_BREAK
case 44:
YY_RULE_SETUP
#line 102 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F32BE_TOKEN);}
	YY_BREAK
case 45:
YY_RULE_SETUP
#line 103 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F32LE_TOKEN);}
	YY_BREAK
case 46:
YY_RULE_SETUP
#line 104 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F64BE_TOKEN);}
	YY_BREAK
case 47:
YY_RULE_SETUP
#line 105 "hl/src//H5LTanalyze.l"
{return hid(H5T_COMPLEX_IEEE_F64LE_TOKEN);}
	YY_BREAK
case 48:
YY_RULE_SETUP
#line 106 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_FLOAT_COMPLEX_TOKEN);}
	YY_BREAK
case 49:
YY_RULE_SETUP
#line 107 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_DOUBLE_COMPLEX_TOKEN);}
	YY_BREAK
case 50:
YY_RULE_SETUP
#line 108 "hl/src//H5LTanalyze.l"
{return hid(H5T_NATIVE_LDOUBLE_COMPLEX_TOKEN);}
	YY_BREAK
case 51:
YY_RULE_SETUP
#line 110 "hl/src//H5LTanalyze.l"
{return token(H5T_STRING_TOKEN);}
	YY_BREAK
case 52:
YY_RULE_SETUP
#line 111 "hl/src//H5LTanalyze.l"
{return token(STRSIZE_TOKEN);}
	YY_BREAK
case 53:
YY_RULE_SETUP
#line 112 "hl/src//H5LTanalyze.l"
{return token(STRPAD_TOKEN);}
	YY_BREAK
case 54:
YY_RULE_SETUP
#line 113 "hl/src//H5LTanalyze.l"
{return token(CSET_TOKEN);}
	YY_BREAK
case 55:
YY_RULE_SETUP
#line 114 "hl/src//H5LTanalyze.l"
{return token(CTYPE_TOKEN);}
	YY_BREAK
case 56:
YY_RULE_SETUP
#line 115 "hl/src//H5LTanalyze.l"
{return token(H5T_STR_NULLTERM_TOKEN);}
	YY_BREAK
case 57:
YY_RULE_SETUP
#line 116 "hl/src//H5LTanalyze.l"
{return token(H5T_STR_NULLPAD_TOKEN);}
	YY_BREAK
case 58:
YY_RULE_SETUP
#line 117 "hl/src//H5LTanalyze.l"
{return token(H5T_STR_SPACEPAD_TOKEN);}
	YY_BREAK
case 59:
YY_RULE_SETUP
#line 118 "hl/src//H5LTanalyze.l"
{return token(H5T_CSET_ASCII_TOKEN);}
	YY_BREAK
case 60:
YY_RULE_SETUP
#line 119 "hl/src//H5LTanalyze.l"
{return token(H5T_CSET_UTF8_TOKEN);}
	YY_BREAK
case 61:
YY_RULE_SETUP
#line 120 "hl/src//H5LTanalyze.l"
{return token(H5T_C_S1_TOKEN);}
	YY_BREAK
case 62:
YY_RULE_SETUP
#line 121 "hl/src//H5LTanalyze.l"
{return token(H5T_FORTRAN_S1_TOKEN);}
	YY_BREAK
case 63:
YY_RULE_SETUP
#line 122 "hl/src//H5LTanalyze.l"
{return token(H5T_VARIABLE_TOKEN);}
	YY_BREAK
case 64:
YY_RULE_SETUP
#line 124 "hl/src//H5LTanalyze.l"
{return token(H5T_COMPOUND_TOKEN);}
	YY_BREAK
case 65:
YY_RULE_SETUP
#line 125 "hl/src//H5LTanalyze.l"
{return token(H5T_ENUM_TOKEN);}
	YY_BREAK
case 66:
YY_RULE_SETUP
#line 126 "hl/src//H5LTanalyze.l"
{return token(H5T_ARRAY_TOKEN);}
	YY_BREAK
case 67:
YY_RULE_SETUP
#line 127 "hl/src//H5LTanalyze.l"
{return token(H5T_VLEN_TOKEN);}
	YY_BREAK
case 68:
YY_RULE_SETUP
#line 128 "hl/src//H5LTanalyze.l"
{return token(H5T_COMPLEX_TOKEN);}
	YY_BREAK
case 69:
YY_RULE_SETUP
#line 130 "hl/src//H5LTanalyze.l"
{return token(H5T_OPAQUE_TOKEN);}
	YY_BREAK
case 70:
YY_RULE_SETUP
#line 131 "hl/src//H5LTanalyze.l"
{return token(OPQ_SIZE_TOKEN);}
	YY_BREAK
case 71:
YY_RULE_SETUP
#line 132 "hl/src//H5LTanalyze.l"
{return token(OPQ_TAG_TOKEN);}
	YY_BREAK
case 72:
YY_RULE_SETUP
#line 134 "hl/src//H5LTanalyze.l"
{
                        H5LTyylval.ival = atoi(yytext);
                        return NUMBER;
                 }
	YY_BREAK
case 73:

YY_RULE_SETUP
#line 139 "hl/src//H5LTanalyze.l"
{
                    H5LTyylval.sval = trim_quotes(yytext);
                    return STRING;
                 }
	YY_BREAK
case 74:
YY_RULE_SETUP
#line 144 "hl/src//H5LTanalyze.l"
{return token('{');}
	YY_BREAK
case 75:
YY_RULE_SETUP
#line 145 "hl/src//H5LTanalyze.l"
{return token('}');}
	YY_BREAK
case 76:
YY_RULE_SETUP
#line 146 "hl/src//H5LTanalyze.l"
{return token('[');}
	YY_BREAK
case 77:
YY_RULE_SETUP
#line 147 "hl/src//H5LTanalyze.l"
{return token(']');}
	YY_BREAK
case 78:
YY_RULE_SETUP
#line 148 "hl/src//H5LTanalyze.l"
{return token(':');}
	YY_BREAK
case 79:
YY_RULE_SETUP
#line 149 "hl/src//H5LTanalyze.l"
{return token(';');}
	YY_BREAK
case 80:

YY_RULE_SETUP
#line 150 "hl/src//H5LTanalyze.l"
;
	YY_BREAK
case 81:
YY_RULE_SETUP
#line 152 "hl/src//H5LTanalyze.l"
ECHO;
	YY_BREAK
#line 1641 "hl/src//H5LTanalyze.c"
case YY_STATE_EOF(INITIAL):
	yyterminate();

	case YY_END_OF_BUFFER:
		{
		
		int yy_amount_of_matched_text = (int) (yy_cp - (yytext_ptr)) - 1;

		
		*yy_cp = (yy_hold_char);
		YY_RESTORE_YY_MORE_OFFSET

		if ( YY_CURRENT_BUFFER_LVALUE->yy_buffer_status == YY_BUFFER_NEW )
			{
			
			(yy_n_chars) = YY_CURRENT_BUFFER_LVALUE->yy_n_chars;
			YY_CURRENT_BUFFER_LVALUE->yy_input_file = yyin;
			YY_CURRENT_BUFFER_LVALUE->yy_buffer_status = YY_BUFFER_NORMAL;
			}

		
		if ( (yy_c_buf_p) <= &YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars)] )
			{ 
			yy_state_type yy_next_state;

			(yy_c_buf_p) = (yytext_ptr) + yy_amount_of_matched_text;

			yy_current_state = yy_get_previous_state(  );

			

			yy_next_state = yy_try_NUL_trans( yy_current_state );

			yy_bp = (yytext_ptr) + YY_MORE_ADJ;

			if ( yy_next_state )
				{
				
				yy_cp = ++(yy_c_buf_p);
				yy_current_state = yy_next_state;
				goto yy_match;
				}

			else
				{
				yy_cp = (yy_c_buf_p);
				goto yy_find_action;
				}
			}

		else switch ( yy_get_next_buffer(  ) )
			{
			case EOB_ACT_END_OF_FILE:
				{
				(yy_did_buffer_switch_on_eof) = 0;

				if ( yywrap(  ) )
					{
					
					(yy_c_buf_p) = (yytext_ptr) + YY_MORE_ADJ;

					yy_act = YY_STATE_EOF(YY_START);
					goto do_action;
					}

				else
					{
					if ( ! (yy_did_buffer_switch_on_eof) )
						YY_NEW_FILE;
					}
				break;
				}

			case EOB_ACT_CONTINUE_SCAN:
				(yy_c_buf_p) =
					(yytext_ptr) + yy_amount_of_matched_text;

				yy_current_state = yy_get_previous_state(  );

				yy_cp = (yy_c_buf_p);
				yy_bp = (yytext_ptr) + YY_MORE_ADJ;
				goto yy_match;

			case EOB_ACT_LAST_MATCH:
				(yy_c_buf_p) =
				&YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars)];

				yy_current_state = yy_get_previous_state(  );

				yy_cp = (yy_c_buf_p);
				yy_bp = (yytext_ptr) + YY_MORE_ADJ;
				goto yy_find_action;
			}
		break;
		}

	default:
		YY_FATAL_ERROR(
			"fatal flex scanner internal error--no action found" );
	} 
		} 
	} 
} 

static int yy_get_next_buffer (void)
{
    	char *dest = YY_CURRENT_BUFFER_LVALUE->yy_ch_buf;
	char *source = (yytext_ptr);
	int number_to_move, i;
	int ret_val;

	if ( (yy_c_buf_p) > &YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars) + 1] )
		YY_FATAL_ERROR(
		"fatal flex scanner internal error--end of buffer missed" );

	if ( YY_CURRENT_BUFFER_LVALUE->yy_fill_buffer == 0 )
		{ 
		if ( (yy_c_buf_p) - (yytext_ptr) - YY_MORE_ADJ == 1 )
			{
			
			return EOB_ACT_END_OF_FILE;
			}

		else
			{
			
			return EOB_ACT_LAST_MATCH;
			}
		}

	

	
	number_to_move = (int) ((yy_c_buf_p) - (yytext_ptr) - 1);

	for ( i = 0; i < number_to_move; ++i )
		*(dest++) = *(source++);

	if ( YY_CURRENT_BUFFER_LVALUE->yy_buffer_status == YY_BUFFER_EOF_PENDING )
		
		YY_CURRENT_BUFFER_LVALUE->yy_n_chars = (yy_n_chars) = 0;

	else
		{
			int num_to_read =
			YY_CURRENT_BUFFER_LVALUE->yy_buf_size - number_to_move - 1;

		while ( num_to_read <= 0 )
			{ 

			
			YY_BUFFER_STATE b = YY_CURRENT_BUFFER_LVALUE;

			int yy_c_buf_p_offset =
				(int) ((yy_c_buf_p) - b->yy_ch_buf);

			if ( b->yy_is_our_buffer )
				{
				int new_size = b->yy_buf_size * 2;

				if ( new_size <= 0 )
					b->yy_buf_size += b->yy_buf_size / 8;
				else
					b->yy_buf_size *= 2;

				b->yy_ch_buf = (char *)
					
					yyrealloc( (void *) b->yy_ch_buf,
							 (yy_size_t) (b->yy_buf_size + 2)  );
				}
			else
				
				b->yy_ch_buf = NULL;

			if ( ! b->yy_ch_buf )
				YY_FATAL_ERROR(
				"fatal error - scanner input buffer overflow" );

			(yy_c_buf_p) = &b->yy_ch_buf[yy_c_buf_p_offset];

			num_to_read = YY_CURRENT_BUFFER_LVALUE->yy_buf_size -
						number_to_move - 1;

			}

		if ( num_to_read > YY_READ_BUF_SIZE )
			num_to_read = YY_READ_BUF_SIZE;

		
		YY_INPUT( (&YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[number_to_move]),
			(yy_n_chars), num_to_read );

		YY_CURRENT_BUFFER_LVALUE->yy_n_chars = (yy_n_chars);
		}

	if ( (yy_n_chars) == 0 )
		{
		if ( number_to_move == YY_MORE_ADJ )
			{
			ret_val = EOB_ACT_END_OF_FILE;
			yyrestart( yyin  );
			}

		else
			{
			ret_val = EOB_ACT_LAST_MATCH;
			YY_CURRENT_BUFFER_LVALUE->yy_buffer_status =
				YY_BUFFER_EOF_PENDING;
			}
		}

	else
		ret_val = EOB_ACT_CONTINUE_SCAN;

	if (((yy_n_chars) + number_to_move) > YY_CURRENT_BUFFER_LVALUE->yy_buf_size) {
		
		int new_size = (yy_n_chars) + number_to_move + ((yy_n_chars) >> 1);
		YY_CURRENT_BUFFER_LVALUE->yy_ch_buf = (char *) yyrealloc(
			(void *) YY_CURRENT_BUFFER_LVALUE->yy_ch_buf, (yy_size_t) new_size  );
		if ( ! YY_CURRENT_BUFFER_LVALUE->yy_ch_buf )
			YY_FATAL_ERROR( "out of dynamic memory in yy_get_next_buffer()" );
		
		YY_CURRENT_BUFFER_LVALUE->yy_buf_size = (int) (new_size - 2);
	}

	(yy_n_chars) += number_to_move;
	YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars)] = YY_END_OF_BUFFER_CHAR;
	YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars) + 1] = YY_END_OF_BUFFER_CHAR;

	(yytext_ptr) = &YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[0];

	return ret_val;
}

    static yy_state_type yy_get_previous_state (void)
{
	yy_state_type yy_current_state;
	char *yy_cp;
    
	yy_current_state = (yy_start);

	for ( yy_cp = (yytext_ptr) + YY_MORE_ADJ; yy_cp < (yy_c_buf_p); ++yy_cp )
		{
		YY_CHAR yy_c = (*yy_cp ? yy_ec[YY_SC_TO_UI(*yy_cp)] : 1);
		if ( yy_accept[yy_current_state] )
			{
			(yy_last_accepting_state) = yy_current_state;
			(yy_last_accepting_cpos) = yy_cp;
			}
		while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
			{
			yy_current_state = (int) yy_def[yy_current_state];
			if ( yy_current_state >= 361 )
				yy_c = yy_meta[yy_c];
			}
		yy_current_state = yy_nxt[yy_base[yy_current_state] + yy_c];
		}

	return yy_current_state;
}

    static yy_state_type yy_try_NUL_trans  (yy_state_type yy_current_state )
{
	int yy_is_jam;
    	char *yy_cp = (yy_c_buf_p);

	YY_CHAR yy_c = 1;
	if ( yy_accept[yy_current_state] )
		{
		(yy_last_accepting_state) = yy_current_state;
		(yy_last_accepting_cpos) = yy_cp;
		}
	while ( yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state )
		{
		yy_current_state = (int) yy_def[yy_current_state];
		if ( yy_current_state >= 361 )
			yy_c = yy_meta[yy_c];
		}
	yy_current_state = yy_nxt[yy_base[yy_current_state] + yy_c];
	yy_is_jam = (yy_current_state == 360);

		return yy_is_jam ? 0 : yy_current_state;
}

#ifndef YY_NO_UNPUT

    static void yyunput (int c, char * yy_bp )
{
	char *yy_cp;
    
    yy_cp = (yy_c_buf_p);

	
	*yy_cp = (yy_hold_char);

	if ( yy_cp < YY_CURRENT_BUFFER_LVALUE->yy_ch_buf + 2 )
		{ 
		
		int number_to_move = (yy_n_chars) + 2;
		char *dest = &YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[
					YY_CURRENT_BUFFER_LVALUE->yy_buf_size + 2];
		char *source =
				&YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[number_to_move];

		while ( source > YY_CURRENT_BUFFER_LVALUE->yy_ch_buf )
			*--dest = *--source;

		yy_cp += (int) (dest - source);
		yy_bp += (int) (dest - source);
		YY_CURRENT_BUFFER_LVALUE->yy_n_chars =
			(yy_n_chars) = (int) YY_CURRENT_BUFFER_LVALUE->yy_buf_size;

		if ( yy_cp < YY_CURRENT_BUFFER_LVALUE->yy_ch_buf + 2 )
			YY_FATAL_ERROR( "flex scanner push-back overflow" );
		}

	*--yy_cp = (char) c;

	(yytext_ptr) = yy_bp;
	(yy_hold_char) = *yy_cp;
	(yy_c_buf_p) = yy_cp;
}

#endif

#ifndef YY_NO_INPUT
#ifdef __cplusplus
    static int yyinput (void)
#else
    static int input  (void)
#endif

{
	int c;
    
	*(yy_c_buf_p) = (yy_hold_char);

	if ( *(yy_c_buf_p) == YY_END_OF_BUFFER_CHAR )
		{
		
		if ( (yy_c_buf_p) < &YY_CURRENT_BUFFER_LVALUE->yy_ch_buf[(yy_n_chars)] )
			
			*(yy_c_buf_p) = '\0';

		else
			{ 
			int offset = (int) ((yy_c_buf_p) - (yytext_ptr));
			++(yy_c_buf_p);

			switch ( yy_get_next_buffer(  ) )
				{
				case EOB_ACT_LAST_MATCH:
					

					
					yyrestart( yyin );

					

				case EOB_ACT_END_OF_FILE:
					{
					if ( yywrap(  ) )
						return 0;

					if ( ! (yy_did_buffer_switch_on_eof) )
						YY_NEW_FILE;
#ifdef __cplusplus
					return yyinput();
#else
					return input();
#endif
					}

				case EOB_ACT_CONTINUE_SCAN:
					(yy_c_buf_p) = (yytext_ptr) + offset;
					break;
				}
			}
		}

	c = *(unsigned char *) (yy_c_buf_p);	
	*(yy_c_buf_p) = '\0';	
	(yy_hold_char) = *++(yy_c_buf_p);

	return c;
}
#endif	

    void yyrestart  (FILE * input_file )
{
    
	if ( ! YY_CURRENT_BUFFER ){
        yyensure_buffer_stack ();
		YY_CURRENT_BUFFER_LVALUE =
            yy_create_buffer( yyin, YY_BUF_SIZE );
	}

	yy_init_buffer( YY_CURRENT_BUFFER, input_file );
	yy_load_buffer_state(  );
}

    void yy_switch_to_buffer  (YY_BUFFER_STATE  new_buffer )
{
    
	
	yyensure_buffer_stack ();
	if ( YY_CURRENT_BUFFER == new_buffer )
		return;

	if ( YY_CURRENT_BUFFER )
		{
		
		*(yy_c_buf_p) = (yy_hold_char);
		YY_CURRENT_BUFFER_LVALUE->yy_buf_pos = (yy_c_buf_p);
		YY_CURRENT_BUFFER_LVALUE->yy_n_chars = (yy_n_chars);
		}

	YY_CURRENT_BUFFER_LVALUE = new_buffer;
	yy_load_buffer_state(  );

	
	(yy_did_buffer_switch_on_eof) = 1;
}

static void yy_load_buffer_state  (void)
{
    	(yy_n_chars) = YY_CURRENT_BUFFER_LVALUE->yy_n_chars;
	(yytext_ptr) = (yy_c_buf_p) = YY_CURRENT_BUFFER_LVALUE->yy_buf_pos;
	yyin = YY_CURRENT_BUFFER_LVALUE->yy_input_file;
	(yy_hold_char) = *(yy_c_buf_p);
}

    YY_BUFFER_STATE yy_create_buffer  (FILE * file, int  size )
{
	YY_BUFFER_STATE b;
    
	b = (YY_BUFFER_STATE) yyalloc( sizeof( struct yy_buffer_state )  );
	if ( ! b )
		YY_FATAL_ERROR( "out of dynamic memory in yy_create_buffer()" );

	b->yy_buf_size = size;

	
	b->yy_ch_buf = (char *) yyalloc( (yy_size_t) (b->yy_buf_size + 2)  );
	if ( ! b->yy_ch_buf )
		YY_FATAL_ERROR( "out of dynamic memory in yy_create_buffer()" );

	b->yy_is_our_buffer = 1;

	yy_init_buffer( b, file );

	return b;
}

    void yy_delete_buffer (YY_BUFFER_STATE  b )
{
    
	if ( ! b )
		return;

	if ( b == YY_CURRENT_BUFFER ) 
		YY_CURRENT_BUFFER_LVALUE = (YY_BUFFER_STATE) 0;

	if ( b->yy_is_our_buffer )
		yyfree( (void *) b->yy_ch_buf  );

	yyfree( (void *) b  );
}

    static void yy_init_buffer  (YY_BUFFER_STATE  b, FILE * file )

{
	int oerrno = errno;
    
	yy_flush_buffer( b );

	b->yy_input_file = file;
	b->yy_fill_buffer = 1;

    
    if (b != YY_CURRENT_BUFFER){
        b->yy_bs_lineno = 1;
        b->yy_bs_column = 0;
    }

        b->yy_is_interactive = file ? (isatty( fileno(file) ) > 0) : 0;
    
	errno = oerrno;
}

    void yy_flush_buffer (YY_BUFFER_STATE  b )
{
    	if ( ! b )
		return;

	b->yy_n_chars = 0;

	
	b->yy_ch_buf[0] = YY_END_OF_BUFFER_CHAR;
	b->yy_ch_buf[1] = YY_END_OF_BUFFER_CHAR;

	b->yy_buf_pos = &b->yy_ch_buf[0];

	b->yy_at_bol = 1;
	b->yy_buffer_status = YY_BUFFER_NEW;

	if ( b == YY_CURRENT_BUFFER )
		yy_load_buffer_state(  );
}

void yypush_buffer_state (YY_BUFFER_STATE new_buffer )
{
    	if (new_buffer == NULL)
		return;

	yyensure_buffer_stack();

	
	if ( YY_CURRENT_BUFFER )
		{
		
		*(yy_c_buf_p) = (yy_hold_char);
		YY_CURRENT_BUFFER_LVALUE->yy_buf_pos = (yy_c_buf_p);
		YY_CURRENT_BUFFER_LVALUE->yy_n_chars = (yy_n_chars);
		}

	
	if (YY_CURRENT_BUFFER)
		(yy_buffer_stack_top)++;
	YY_CURRENT_BUFFER_LVALUE = new_buffer;

	
	yy_load_buffer_state(  );
	(yy_did_buffer_switch_on_eof) = 1;
}

void yypop_buffer_state (void)
{
    	if (!YY_CURRENT_BUFFER)
		return;

	yy_delete_buffer(YY_CURRENT_BUFFER );
	YY_CURRENT_BUFFER_LVALUE = NULL;
	if ((yy_buffer_stack_top) > 0)
		--(yy_buffer_stack_top);

	if (YY_CURRENT_BUFFER) {
		yy_load_buffer_state(  );
		(yy_did_buffer_switch_on_eof) = 1;
	}
}

static void yyensure_buffer_stack (void)
{
	yy_size_t num_to_alloc;
    
	if (!(yy_buffer_stack)) {

		
      num_to_alloc = 1; 
		(yy_buffer_stack) = (struct yy_buffer_state**)yyalloc
								(num_to_alloc * sizeof(struct yy_buffer_state*)
								);
		if ( ! (yy_buffer_stack) )
			YY_FATAL_ERROR( "out of dynamic memory in yyensure_buffer_stack()" );

		memset((yy_buffer_stack), 0, num_to_alloc * sizeof(struct yy_buffer_state*));

		(yy_buffer_stack_max) = num_to_alloc;
		(yy_buffer_stack_top) = 0;
		return;
	}

	if ((yy_buffer_stack_top) >= ((yy_buffer_stack_max)) - 1){

		
		yy_size_t grow_size = 8 ;

		num_to_alloc = (yy_buffer_stack_max) + grow_size;
		(yy_buffer_stack) = (struct yy_buffer_state**)yyrealloc
								((yy_buffer_stack),
								num_to_alloc * sizeof(struct yy_buffer_state*)
								);
		if ( ! (yy_buffer_stack) )
			YY_FATAL_ERROR( "out of dynamic memory in yyensure_buffer_stack()" );

		
		memset((yy_buffer_stack) + (yy_buffer_stack_max), 0, grow_size * sizeof(struct yy_buffer_state*));
		(yy_buffer_stack_max) = num_to_alloc;
	}
}

YY_BUFFER_STATE yy_scan_buffer  (char * base, yy_size_t  size )
{
	YY_BUFFER_STATE b;
    
	if ( size < 2 ||
	     base[size-2] != YY_END_OF_BUFFER_CHAR ||
	     base[size-1] != YY_END_OF_BUFFER_CHAR )
		
		return NULL;

	b = (YY_BUFFER_STATE) yyalloc( sizeof( struct yy_buffer_state )  );
	if ( ! b )
		YY_FATAL_ERROR( "out of dynamic memory in yy_scan_buffer()" );

	b->yy_buf_size = (int) (size - 2);	
	b->yy_buf_pos = b->yy_ch_buf = base;
	b->yy_is_our_buffer = 0;
	b->yy_input_file = NULL;
	b->yy_n_chars = b->yy_buf_size;
	b->yy_is_interactive = 0;
	b->yy_at_bol = 1;
	b->yy_fill_buffer = 0;
	b->yy_buffer_status = YY_BUFFER_NEW;

	yy_switch_to_buffer( b  );

	return b;
}

YY_BUFFER_STATE yy_scan_string (const char * yystr )
{
    
	return yy_scan_bytes( yystr, (int) strlen(yystr) );
}

YY_BUFFER_STATE yy_scan_bytes  (const char * yybytes, int  _yybytes_len )
{
	YY_BUFFER_STATE b;
	char *buf;
	yy_size_t n;
	int i;
    
	
	n = (yy_size_t) (_yybytes_len + 2);
	buf = (char *) yyalloc( n  );
	if ( ! buf )
		YY_FATAL_ERROR( "out of dynamic memory in yy_scan_bytes()" );

	for ( i = 0; i < _yybytes_len; ++i )
		buf[i] = yybytes[i];

	buf[_yybytes_len] = buf[_yybytes_len+1] = YY_END_OF_BUFFER_CHAR;

	b = yy_scan_buffer( buf, n );
	if ( ! b )
		YY_FATAL_ERROR( "bad buffer in yy_scan_bytes()" );

	
	b->yy_is_our_buffer = 1;

	return b;
}

#ifndef YY_EXIT_FAILURE
#define YY_EXIT_FAILURE 2
#endif

static void yy_fatal_error (const char* msg )
{
			Rfprintf( Rstderr, "%s\n", msg );
	Rexit( YY_EXIT_FAILURE );
}

#undef yyless
#define yyless(n) \
	do \
		{ \
		 \
        int yyless_macro_arg = (n); \
        YY_LESS_LINENO(yyless_macro_arg);\
		yytext[yyleng] = (yy_hold_char); \
		(yy_c_buf_p) = yytext + yyless_macro_arg; \
		(yy_hold_char) = *(yy_c_buf_p); \
		*(yy_c_buf_p) = '\0'; \
		yyleng = yyless_macro_arg; \
		} \
	while ( 0 )

int yyget_lineno  (void)
{
    
    return yylineno;
}

FILE *yyget_in  (void)
{
        return yyin;
}

FILE *yyget_out  (void)
{
        return yyout;
}

int yyget_leng  (void)
{
        return yyleng;
}

char *yyget_text  (void)
{
        return yytext;
}

void yyset_lineno (int  _line_number )
{
    
    yylineno = _line_number;
}

void yyset_in (FILE *  _in_str )
{
        yyin = _in_str ;
}

void yyset_out (FILE *  _out_str )
{
        yyout = _out_str ;
}

int yyget_debug  (void)
{
        return yy_flex_debug;
}

void yyset_debug (int  _bdebug )
{
        yy_flex_debug = _bdebug ;
}

static int yy_init_globals (void)
{
        

    (yy_buffer_stack) = NULL;
    (yy_buffer_stack_top) = 0;
    (yy_buffer_stack_max) = 0;
    (yy_c_buf_p) = NULL;
    (yy_init) = 0;
    (yy_start) = 0;

#ifdef YY_STDINIT
    yyin = stdin;
    yyout = Rstdout;
#else
    yyin = NULL;
    yyout = NULL;
#endif

    
    return 0;
}

int yylex_destroy  (void)
{
    
    
	while(YY_CURRENT_BUFFER){
		yy_delete_buffer( YY_CURRENT_BUFFER  );
		YY_CURRENT_BUFFER_LVALUE = NULL;
		yypop_buffer_state();
	}

	
	yyfree((yy_buffer_stack) );
	(yy_buffer_stack) = NULL;

    
    yy_init_globals( );

    return 0;
}

#ifndef yytext_ptr
static void yy_flex_strncpy (char* s1, const char * s2, int n )
{
		
	int i;
	for ( i = 0; i < n; ++i )
		s1[i] = s2[i];
}
#endif

#ifdef YY_NEED_STRLEN
static int yy_flex_strlen (const char * s )
{
	int n;
	for ( n = 0; s[n]; ++n )
		;

	return n;
}
#endif

void *yyalloc (yy_size_t  size )
{
			return malloc(size);
}

void *yyrealloc  (void * ptr, yy_size_t  size )
{
		
	
	return realloc(ptr, size);
}

void yyfree (void * ptr )
{
			free( (char *) ptr );	
}

#define YYTABLES_NAME "yytables"

#line 152 "hl/src//H5LTanalyze.l"

static char *
trim_quotes(const char *quoted)
{
    size_t len = strlen(quoted);
    char *trimmed;

    assert(quoted[0] == '"' && quoted[len - 1] == '"');

    trimmed = strdup(quoted + 1);
    trimmed[len - 2] = '\0';

    return trimmed;
}

static int my_yyinput(char *buf, int max_size)
{
   int ret;

   memcpy(buf, myinput, input_len);
   ret = (int)input_len;
   return ret;
}

int H5LTyyerror(const char *msg)
{
   Rprintf("ERROR: %s before \"%s\".\n", msg, yytext);
   return 0;
}

int yywrap()
{
    return 1;
}

