/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#ifndef PTABLETEST
#define PTABLETEST
#include "h5hltest.h"
#include "H5PacketTable.h"
#include "H5Cpp.h"
static hid_t fileID;
int BasicTest(void);
int TestCompoundDatatype(void);
int TestGetNext(void);
int TestCompress(void);
int TestErrors(void);
int TestGetPacket(void);
int SystemTest(void);
int TestHDFFV_9758(void);
#endif
