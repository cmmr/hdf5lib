/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <stdlib.h>
#include <string.h>
#include "hdf5.h"
#if 1
#define NX 65536
#define NY 65536 
#define CX 256   
#define CY 4096  
#else
#define NX 256
#define NY 256 
#define CX 32  
#define CY 16  
#endif
#define RC (NX / CX)
#define CC (NY / CY)
