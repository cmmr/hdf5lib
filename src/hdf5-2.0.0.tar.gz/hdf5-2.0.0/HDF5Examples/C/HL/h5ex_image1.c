/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "hdf5.h"
#include "hdf5_hl.h"

#define FILENAME    "h5ex_image1.h5"
#define WIDTH       400
#define HEIGHT      200
#define PAL_ENTRIES 9
static unsigned char buf[WIDTH * HEIGHT];

int
main(void)
{
    hid_t         file_id;
    hsize_t       pal_dims[] = {PAL_ENTRIES, 3};
    size_t        i, j;
    int           n, space;
    unsigned char pal[PAL_ENTRIES * 3] = {               
                                          0,   0,   168, 
                                          0,   0,   252, 
                                          0,   168, 252, 
                                          84,  252, 252, 
                                          168, 252, 168, 
                                          0,   252, 168, 
                                          252, 252, 84,  
                                          252, 168, 0,   
                                          252, 0,   0};  

    
    space = WIDTH * HEIGHT / PAL_ENTRIES;
    for (i = 0, j = 0, n = 0; i < WIDTH * HEIGHT; i++, j++) {
        buf[i] = n;
        if (j > space) {
            n++;
            j = 0;
        }
        if (n > PAL_ENTRIES - 1)
            n = 0;
    }

    
    file_id = H5Fcreate(FILENAME, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);

    
    H5IMmake_image_8bit(file_id, "image1", (hsize_t)WIDTH, (hsize_t)HEIGHT, buf);

    
    H5IMmake_palette(file_id, "palette", pal_dims, pal);

    
    H5IMlink_palette(file_id, "image1", "palette");

    
    H5Fclose(file_id);

    return 0;
}
