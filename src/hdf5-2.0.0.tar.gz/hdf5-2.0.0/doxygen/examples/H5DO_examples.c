/* -*- c-file-style: "stroustrup" -*- */

//! <!-- [H5DOwrite] -->

#include <zlib.h>
#include <math.h>
#define DEFLATE_SIZE_ADJUST(s) (ceil(((double)(s)) * 1.001) + 12)
                :
                :
size_t       buf_size = CHUNK_NX*CHUNK_NY*sizeof(int);
                const Bytef *z_src = (const Bytef *)(direct_buf);
                Bytef       *z_dst; 
                uLongf       z_dst_nbytes = (uLongf)DEFLATE_SIZE_ADJUST(buf_size);
                uLong        z_src_nbytes = (uLong)buf_size;
                int          aggression   = 9; 
                uint32_t     filter_mask  = 0;
                size_t       buf_size     = CHUNK_NX * CHUNK_NY * sizeof(int);

                
                if ((dataspace = H5Screate_simple(RANK, dims, maxdims)) < 0)
                    goto error;

                
                if ((file = H5Fcreate(FILE_NAME5, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT)) < 0)
                    goto error;

                
                if ((cparms = H5Pcreate(H5P_DATASET_CREATE)) < 0)
                    goto error;

                if ((status = H5Pset_chunk(cparms, RANK, chunk_dims)) < 0)
                    goto error;

                if ((status = H5Pset_deflate(cparms, aggression)) < 0)
                    goto error;

                
                if ((dset_id = H5Dcreate2(file, DATASETNAME, H5T_NATIVE_INT, dataspace, H5P_DEFAULT, cparms,
                                          H5P_DEFAULT)) < 0)
                    goto error;

                
                for (i = n = 0; i < CHUNK_NX; i++)
                    for (j = 0; j < CHUNK_NY; j++)
                        direct_buf[i][j] = n++;

                
                outbuf = malloc(z_dst_nbytes);
                z_dst  = (Bytef *)outbuf;

                
                ret = compress2(z_dst, &z_dst_nbytes, z_src, z_src_nbytes, aggression);

                
                if (Z_BUF_ERROR == ret) {
                    Rfprintf(Rstderr, "overflow");
                    goto error;
                }
                else if (Z_MEM_ERROR == ret) {
                    Rfprintf(Rstderr, "deflate memory error");
                    goto error;
                }
                else if (Z_OK != ret) {
                    Rfprintf(Rstderr, "other deflate error");
                    goto error;
                }

                
                for (i = 0; i < NX / CHUNK_NX; i++) {
                    for (j = 0; j < NY / CHUNK_NY; j++) {
                        status =
                            H5DOwrite_chunk(dset_id, H5P_DEFAULT, filter_mask, offset, z_dst_nbytes, outbuf);
                        offset[1] += CHUNK_NY;
                    }
                    offset[0] += CHUNK_NX;
                    offset[1] = 0;
                }

                
                filter_mask = 0x00000001;
                offset[0] = offset[1] = 0;
                if (H5DOwrite_chunk(dset_id, H5P_DEFAULT, filter_mask, offset, buf_size, direct_buf) < 0)
                    goto error;

                
                if (H5Dread(dataset, H5T_NATIVE_LONG, H5S_ALL, H5S_ALL, H5P_DEFAULT, outbuf_long) < 0)
                    goto error;

                
            :
            :

            //! <!-- [H5DOwrite] -->

            //! <!-- [H5DOread] -->

#include <zlib.h>
#include <math.h>
#define DEFLATE_SIZE_ADJUST(s) (ceil(((double)(s)) * 1.001) + 12)
                :
                :
size_t       buf_size = CHUNK_NX*CHUNK_NY*sizeof(int);
            const Bytef *z_src = (const Bytef *)(direct_buf);
            Bytef       *z_dst; 
            uLongf       z_dst_nbytes = (uLongf)DEFLATE_SIZE_ADJUST(buf_size);
            uLong        z_src_nbytes = (uLong)buf_size;
            int          aggression   = 9; 
            uint32_t     filter_mask  = 0;
            size_t       buf_size     = CHUNK_NX * CHUNK_NY * sizeof(int);
            
            void        *readbuf = NULL;                   
            const Bytef *pt_readbuf;                       
            hsize_t      read_chunk_nbytes;                
            int          read_dst_buf[CHUNK_NX][CHUNK_NY]; 

            
            if ((dataspace = H5Screate_simple(RANK, dims, maxdims)) < 0)
                goto error;

            
            if ((file = H5Fcreate(FILE_NAME5, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT)) < 0)
                goto error;

            
            if ((cparms = H5Pcreate(H5P_DATASET_CREATE)) < 0)
                goto error;

            if ((status = H5Pset_chunk(cparms, RANK, chunk_dims)) < 0)
                goto error;

            if ((status = H5Pset_deflate(cparms, aggression)) < 0)
                goto error;

            
            if ((dset_id = H5Dcreate2(file, DATASETNAME, H5T_NATIVE_INT, dataspace, H5P_DEFAULT, cparms,
                                      H5P_DEFAULT)) < 0)
                goto error;

            
            for (i = n = 0; i < CHUNK_NX; i++)
                for (j = 0; j < CHUNK_NY; j++)
                    direct_buf[i][j] = n++;

            
            outbuf = malloc(z_dst_nbytes);
            z_dst  = (Bytef *)outbuf;

            
            ret = compress2(z_dst, &z_dst_nbytes, z_src, z_src_nbytes, aggression);

            
            if (Z_BUF_ERROR == ret) {
                Rfprintf(Rstderr, "overflow");
                goto error;
            }
            else if (Z_MEM_ERROR == ret) {
                Rfprintf(Rstderr, "deflate memory error");
                goto error;
            }
            else if (Z_OK != ret) {
                Rfprintf(Rstderr, "other deflate error");
                goto error;
            }

            
            for (i = 0; i < NX / CHUNK_NX; i++) {
                for (j = 0; j < NY / CHUNK_NY; j++) {
                    status = H5DOwrite_chunk(dset_id, H5P_DEFAULT, filter_mask, offset, z_dst_nbytes, outbuf);
                    offset[1] += CHUNK_NY;
                }
                offset[0] += CHUNK_NX;
                offset[1] = 0;
            }

            if (H5Fflush(dataset, H5F_SCOPE_LOCAL) < 0)
                goto error;

            if (H5Dclose(dataset) < 0)
                goto error;

            if ((dataset = H5Dopen2(file, DATASETNAME1, H5P_DEFAULT)) < 0)
                goto error;

            offset[0] = CHUNK_NX;
            offset[1] = CHUNK_NY;

            
            ret = H5Dget_chunk_storage_size(dataset, offset, &read_chunk_nbytes);

            readbuf    = malloc(read_chunk_nbytes);
            pt_readbuf = (const Bytef *)readbuf;

            
            if ((status = H5DOread_chunk(dataset, H5P_DEFAULT, offset, &read_filter_mask, readbuf)) < 0)
                goto error;

            ret =
                uncompress((Bytef *)read_dst_buf, (uLongf *)&buf_size, pt_readbuf, (uLong)read_chunk_nbytes);

            
            if (Z_BUF_ERROR == ret) {
                Rfprintf(Rstderr, "error: not enough room in output buffer");
                goto error;
            }
            else if (Z_MEM_ERROR == ret) {
                Rfprintf(Rstderr, "error: not enough memory");
                goto error;
            }
            else if (Z_OK != ret) {
                Rfprintf(Rstderr, "error: corrupted input data");
                goto error;
            }

            
            :
            :
//! <!-- [H5DOread] -->
