/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5FDmodule.h"

#include "H5private.h"
#include "H5Eprivate.h"
#include "H5FDpkg.h"
#include "H5FDioc_priv.h"

static inline void
H5FD__ioc_calculate_target_ioc(int64_t file_offset, int64_t stripe_size, int num_io_concentrators,
                               int num_subfiles, int64_t *target_ioc, int64_t *ioc_file_offset,
                               int64_t *ioc_subfile_idx)
{
    int64_t stripe_idx;
    int64_t subfile_row;
    int64_t subfile_idx;

    FUNC_ENTER_PACKAGE_NOERR

    assert(stripe_size > 0);
    assert(num_io_concentrators > 0);
    assert(num_subfiles > 0);
    assert(target_ioc);
    assert(ioc_file_offset);
    assert(ioc_subfile_idx);

    stripe_idx  = file_offset / stripe_size;
    subfile_row = stripe_idx / num_subfiles;
    subfile_idx = (stripe_idx % num_subfiles) / num_io_concentrators;

    *target_ioc      = (stripe_idx % num_subfiles) % num_io_concentrators;
    *ioc_file_offset = (subfile_row * stripe_size) + (file_offset % stripe_size);
    *ioc_subfile_idx = subfile_idx;

    FUNC_LEAVE_NOAPI_VOID
}

herr_t
H5FD__ioc_write_independent_async(int64_t context_id, int64_t offset, int64_t elements, const void *data,
                                  io_req_t **io_req)
{
    subfiling_context_t *sf_context       = NULL;
    MPI_Request          ack_request      = MPI_REQUEST_NULL;
    io_req_t            *sf_io_request    = NULL;
    int64_t              ioc_start        = -1;
    int64_t              ioc_offset       = -1;
    int64_t              ioc_subfile_idx  = -1;
    int64_t              msg[3]           = {0};
    int                 *io_concentrators = NULL;
    int                  num_io_concentrators;
    int                  num_subfiles;
    int                  data_tag = 0;
    int                  mpi_code;
    herr_t               ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(io_req);

    if (NULL == (sf_context = H5FD__subfiling_get_object(context_id)))
        HGOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "can't get subfiling context from ID");
    assert(sf_context->topology);
    assert(sf_context->topology->io_concentrators);

    io_concentrators     = sf_context->topology->io_concentrators;
    num_io_concentrators = sf_context->topology->n_io_concentrators;
    num_subfiles         = sf_context->sf_num_subfiles;

    H5FD__ioc_calculate_target_ioc(offset, sf_context->sf_stripe_size, num_io_concentrators, num_subfiles,
                                   &ioc_start, &ioc_offset, &ioc_subfile_idx);

    if (MPI_SUCCESS != (mpi_code = MPI_Irecv(&data_tag, 1, MPI_INT, io_concentrators[ioc_start],
                                             WRITE_INDEP_ACK, sf_context->sf_data_comm, &ack_request)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Irecv failed", mpi_code);

    msg[0] = elements;
    msg[1] = ioc_offset;
    msg[2] = ioc_subfile_idx;
    if (MPI_SUCCESS != (mpi_code = MPI_Send(msg, 1, H5_subfiling_rpc_msg_type, io_concentrators[ioc_start],
                                            WRITE_INDEP, sf_context->sf_msg_comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Send failed", mpi_code);

    if (MPI_SUCCESS != (mpi_code = MPI_Wait(&ack_request, MPI_STATUS_IGNORE)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Wait failed", mpi_code);

    if (data_tag == 0)
        HGOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "received NACK from IOC");

    if (NULL == (sf_io_request = H5MM_malloc(sizeof(io_req_t))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_WRITEERROR, FAIL, "couldn't allocate I/O request");

    H5_CHECK_OVERFLOW(ioc_start, int64_t, int);
    sf_io_request->ioc             = (int)ioc_start;
    sf_io_request->context_id      = context_id;
    sf_io_request->offset          = offset;
    sf_io_request->elements        = elements;
    sf_io_request->data            = H5FD__subfiling_cast_to_void(data);
    sf_io_request->io_transfer_req = MPI_REQUEST_NULL;
    sf_io_request->io_comp_req     = MPI_REQUEST_NULL;
    sf_io_request->io_comp_tag     = -1;

    if (MPI_SUCCESS !=
        (mpi_code = MPI_Irecv(&sf_io_request->io_comp_tag, 1, MPI_INT, io_concentrators[ioc_start],
                              WRITE_DATA_DONE, sf_context->sf_data_comm, &sf_io_request->io_comp_req)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Irecv failed", mpi_code);

    H5_CHECK_OVERFLOW(elements, int64_t, int);
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Isend(data, (int)elements, MPI_BYTE, io_concentrators[ioc_start], data_tag,
                              sf_context->sf_data_comm, &sf_io_request->io_transfer_req)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Isend failed", mpi_code);

    *io_req = sf_io_request;

done:
    if (ret_value < 0) {
        if (ack_request != MPI_REQUEST_NULL)
            if (MPI_SUCCESS != (mpi_code = MPI_Wait(&ack_request, MPI_STATUS_IGNORE)))
                HMPI_DONE_ERROR(FAIL, "MPI_Wait failed", mpi_code);
        if (sf_io_request) {
            if (sf_io_request->io_transfer_req != MPI_REQUEST_NULL)
                if (MPI_SUCCESS != (mpi_code = MPI_Wait(&sf_io_request->io_transfer_req, MPI_STATUS_IGNORE)))
                    HMPI_DONE_ERROR(FAIL, "MPI_Wait failed", mpi_code);
            if (sf_io_request->io_comp_req != MPI_REQUEST_NULL)
                if (MPI_SUCCESS != (mpi_code = MPI_Wait(&sf_io_request->io_comp_req, MPI_STATUS_IGNORE)))
                    HMPI_DONE_ERROR(FAIL, "MPI_Wait failed", mpi_code);
        }

        H5MM_free(sf_io_request);
        *io_req = NULL;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5FD__ioc_read_independent_async(int64_t context_id, int64_t offset, int64_t elements, void *data,
                                 io_req_t **io_req)
{
    subfiling_context_t *sf_context       = NULL;
    MPI_Request          ack_request      = MPI_REQUEST_NULL;
    io_req_t            *sf_io_request    = NULL;
    bool                 need_data_tag    = false;
    int64_t              ioc_start        = -1;
    int64_t              ioc_offset       = -1;
    int64_t              ioc_subfile_idx  = -1;
    int64_t              msg[3]           = {0};
    int                 *io_concentrators = NULL;
    int                  num_io_concentrators;
    int                  num_subfiles;
    int                  data_tag = 0;
    int                  mpi_code;
    herr_t               ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(io_req);

    H5_CHECK_OVERFLOW(elements, int64_t, int);

    if (NULL == (sf_context = H5FD__subfiling_get_object(context_id)))
        HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "can't get subfiling context from ID");
    assert(sf_context->topology);
    assert(sf_context->topology->io_concentrators);

    io_concentrators     = sf_context->topology->io_concentrators;
    num_io_concentrators = sf_context->topology->n_io_concentrators;
    num_subfiles         = sf_context->sf_num_subfiles;

    need_data_tag = (num_subfiles == 1) || (num_subfiles != num_io_concentrators);
    if (!need_data_tag)
        data_tag = READ_INDEP_DATA;

    H5FD__ioc_calculate_target_ioc(offset, sf_context->sf_stripe_size, num_io_concentrators, num_subfiles,
                                   &ioc_start, &ioc_offset, &ioc_subfile_idx);

    if (NULL == (sf_io_request = H5MM_malloc(sizeof(io_req_t))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_READERROR, FAIL, "couldn't allocate I/O request");

    H5_CHECK_OVERFLOW(ioc_start, int64_t, int);
    sf_io_request->ioc             = (int)ioc_start;
    sf_io_request->context_id      = context_id;
    sf_io_request->offset          = offset;
    sf_io_request->elements        = elements;
    sf_io_request->data            = data;
    sf_io_request->io_transfer_req = MPI_REQUEST_NULL;
    sf_io_request->io_comp_req     = MPI_REQUEST_NULL;
    sf_io_request->io_comp_tag     = -1;

    if (need_data_tag) {

        if (MPI_SUCCESS != (mpi_code = MPI_Irecv(&data_tag, 1, MPI_INT, io_concentrators[ioc_start],
                                                 READ_INDEP_ACK, sf_context->sf_data_comm, &ack_request)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Irecv failed", mpi_code);

        msg[0] = elements;
        msg[1] = ioc_offset;
        msg[2] = ioc_subfile_idx;
        if (MPI_SUCCESS !=
            (mpi_code = MPI_Send(msg, 1, H5_subfiling_rpc_msg_type, io_concentrators[ioc_start], READ_INDEP,
                                 sf_context->sf_msg_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Send failed", mpi_code);

        if (MPI_SUCCESS != (mpi_code = MPI_Wait(&ack_request, MPI_STATUS_IGNORE)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Wait failed", mpi_code);

        if (data_tag == 0)
            HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "received NACK from IOC");
    }

    if (MPI_SUCCESS !=
        (mpi_code = MPI_Irecv(data, (int)elements, MPI_BYTE, io_concentrators[ioc_start], data_tag,
                              sf_context->sf_data_comm, &sf_io_request->io_transfer_req)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Irecv failed", mpi_code);

    if (!need_data_tag) {

        msg[0] = elements;
        msg[1] = ioc_offset;
        msg[2] = ioc_subfile_idx;
        if (MPI_SUCCESS !=
            (mpi_code = MPI_Send(msg, 1, H5_subfiling_rpc_msg_type, io_concentrators[ioc_start], READ_INDEP,
                                 sf_context->sf_msg_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Send failed", mpi_code);
    }

    *io_req = sf_io_request;

done:
    if (ret_value < 0) {
        if (ack_request != MPI_REQUEST_NULL)
            if (MPI_SUCCESS != (mpi_code = MPI_Wait(&ack_request, MPI_STATUS_IGNORE)))
                HMPI_DONE_ERROR(FAIL, "MPI_Wait failed", mpi_code);
        if (sf_io_request)
            if (sf_io_request->io_transfer_req != MPI_REQUEST_NULL)
                if (MPI_SUCCESS != (mpi_code = MPI_Wait(&sf_io_request->io_transfer_req, MPI_STATUS_IGNORE)))
                    HMPI_DONE_ERROR(FAIL, "MPI_Wait failed", mpi_code);

        H5MM_free(sf_io_request);
        *io_req = NULL;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5FD__ioc_async_completion(MPI_Request *mpi_reqs, size_t num_reqs)
{
    herr_t ret_value = SUCCEED;
    int    mpi_code;

    FUNC_ENTER_PACKAGE

    assert(mpi_reqs);

    H5_CHECK_OVERFLOW(num_reqs, size_t, int);

    H5_WARN_MPI_STATUSES_IGNORE_OFF
    if (MPI_SUCCESS != (mpi_code = MPI_Waitall((int)num_reqs, mpi_reqs, MPI_STATUSES_IGNORE)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Waitall failed", mpi_code);
    H5_WARN_MPI_STATUSES_IGNORE_ON

done:
    FUNC_LEAVE_NOAPI(ret_value)
}
