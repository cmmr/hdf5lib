/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5FDmodule.h"

#include "H5private.h"
#include "H5CXprivate.h"
#include "H5Eprivate.h"
#include "H5Fprivate.h"
#include "H5FDpkg.h"
#include "H5FDsec2.h"
#include "H5FDsubfiling_priv.h"
#include "H5FLprivate.h"
#include "H5Iprivate.h"
#include "H5MMprivate.h"
#include "H5Pprivate.h"

hid_t H5FD_SUBFILING_id_g = H5I_INVALID_HID;

static bool H5FD_subfiling_init_s = false;

static bool H5FD_mpi_self_initialized_s = false;

typedef struct H5FD_subfiling_t {
    H5FD_t                  pub;
    H5FD_subfiling_config_t fa;

    MPI_Comm comm;
    MPI_Comm ext_comm;
    MPI_Info info;
    int      mpi_rank;
    int      mpi_size;

    H5FD_t *sf_file;
    H5FD_t *stub_file;

    uint64_t file_id;
    int64_t  context_id;

    bool fail_to_encode;

    char *file_dir;
    char *file_path;

    haddr_t        eoa;
    haddr_t        eof;
    haddr_t        last_eoa;
    haddr_t        local_eof;
    haddr_t        pos;
    H5FD_file_op_t op;
    char           filename[H5FD_MAX_FILENAME_LEN];
} H5FD_subfiling_t;

typedef enum H5FD_subfiling_io_type_t {
    IO_TYPE_WRITE,
    IO_TYPE_READ,
} H5FD_subfiling_io_type_t;

#define H5FD_SUBFILING_MAX_DRV_INFO_SIZE 1024

static herr_t  H5FD__subfiling_term(void);
static hsize_t H5FD__subfiling_sb_size(H5FD_t *_file);
static herr_t  H5FD__subfiling_sb_encode(H5FD_t *_file, char *name, unsigned char *buf);
static herr_t  H5FD__subfiling_sb_decode(H5FD_t *_file, const char *name, const unsigned char *buf);
static void   *H5FD__subfiling_fapl_get(H5FD_t *_file);
static void   *H5FD__subfiling_fapl_copy(const void *_old_fa);
static herr_t  H5FD__subfiling_fapl_free(void *_fa);
static H5FD_t *H5FD__subfiling_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t maxaddr);
static herr_t  H5FD__subfiling_close(H5FD_t *_file);
static int     H5FD__subfiling_cmp(const H5FD_t *_f1, const H5FD_t *_f2);
static herr_t  H5FD__subfiling_query(const H5FD_t *_f1, unsigned long *flags);
static haddr_t H5FD__subfiling_get_eoa(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__subfiling_set_eoa(H5FD_t *_file, H5FD_mem_t type, haddr_t addr);
static haddr_t H5FD__subfiling_get_eof(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__subfiling_get_handle(H5FD_t *_file, hid_t fapl, void **file_handle);
static herr_t  H5FD__subfiling_read(H5FD_t *_file, H5FD_mem_t type, hid_t fapl_id, haddr_t addr, size_t size,
                                    void *buf);
static herr_t  H5FD__subfiling_write(H5FD_t *_file, H5FD_mem_t type, hid_t dxpl_id, haddr_t addr, size_t size,
                                     const void *buf);
static herr_t  H5FD__subfiling_read_vector(H5FD_t *file, hid_t dxpl_id, uint32_t count, H5FD_mem_t types[],
                                           haddr_t addrs[], size_t sizes[], void *bufs[]);
static herr_t  H5FD__subfiling_write_vector(H5FD_t *file, hid_t dxpl_id, uint32_t count, H5FD_mem_t types[],
                                            haddr_t addrs[], size_t sizes[], const void *bufs[]);
static herr_t  H5FD__subfiling_truncate(H5FD_t *_file, hid_t dxpl_id, bool closing);
static herr_t  H5FD__subfiling_delete(const char *name, hid_t fapl);
static herr_t  H5FD__subfiling_ctl(H5FD_t *_file, uint64_t op_code, uint64_t flags, const void *input,
                                   void **output);

static herr_t H5FD__subfiling_get_default_config(hid_t fapl_id, H5FD_subfiling_config_t *config_out);
static herr_t H5FD__subfiling_validate_config(const H5FD_subfiling_config_t *fa);
static herr_t H5FD__copy_plist(hid_t fapl_id, hid_t *id_out_ptr);

static herr_t H5FD__subfiling_close_int(H5FD_subfiling_t *file);

static herr_t H5FD__subfiling_io_helper(H5FD_subfiling_t *file, size_t io_count, H5FD_mem_t types[],
                                        haddr_t addrs[], size_t sizes[], H5_flexible_const_ptr_t bufs[],
                                        H5FD_subfiling_io_type_t io_type);
static herr_t H5FD__subfiling_mirror_writes_to_stub(H5FD_subfiling_t *file, uint32_t count,
                                                    H5FD_mem_t types[], haddr_t addrs[], size_t sizes[],
                                                    const void *bufs[]);
static herr_t H5FD__subfiling_generate_io_vectors(subfiling_context_t *sf_context, size_t in_count,
                                                  H5FD_mem_t types[], haddr_t file_offsets[],
                                                  size_t io_sizes[], H5_flexible_const_ptr_t bufs[],
                                                  H5FD_subfiling_io_type_t io_type, size_t *ioreq_count_out,
                                                  uint32_t *iovec_len_out, H5FD_mem_t **io_types_out,
                                                  haddr_t **io_addrs_out, size_t **io_sizes_out,
                                                  H5_flexible_const_ptr_t **io_bufs_out);
static herr_t H5FD__subfiling_get_iovec_sizes(subfiling_context_t *sf_context, size_t in_count,
                                              haddr_t file_offsets[], size_t io_sizes[],
                                              size_t *max_iovec_depth, size_t *max_num_subfiles);
static herr_t H5FD__subfiling_translate_io_req_to_iovec(
    subfiling_context_t *sf_context, size_t iovec_idx, size_t iovec_len, size_t iovec_count, H5FD_mem_t type,
    haddr_t addr, size_t io_size, H5_flexible_const_ptr_t io_buf, H5FD_subfiling_io_type_t io_type,
    H5FD_mem_t *io_types, haddr_t *io_addrs, size_t *io_sizes, H5_flexible_const_ptr_t *io_bufs);
static herr_t H5FD__subfiling_iovec_fill_first(subfiling_context_t *sf_context, size_t iovec_len,
                                               int64_t cur_iovec_depth, int64_t target_datasize,
                                               int64_t start_mem_offset, int64_t start_file_offset,
                                               int64_t first_io_len, H5_flexible_const_ptr_t buf,
                                               H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                               size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr);
static herr_t H5FD__subfiling_iovec_fill_last(subfiling_context_t *sf_context, size_t iovec_len,
                                              int64_t cur_iovec_depth, int64_t target_datasize,
                                              int64_t start_mem_offset, int64_t start_file_offset,
                                              int64_t last_io_len, H5_flexible_const_ptr_t buf,
                                              H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                              size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr);
static herr_t H5FD__subfiling_iovec_fill_first_last(
    subfiling_context_t *sf_context, size_t iovec_len, int64_t cur_iovec_depth, int64_t target_datasize,
    int64_t start_mem_offset, int64_t start_file_offset, int64_t first_io_len, int64_t last_io_len,
    H5_flexible_const_ptr_t buf, H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
    size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr);
static herr_t H5FD__subfiling_iovec_fill_uniform(subfiling_context_t *sf_context, size_t iovec_len,
                                                 int64_t cur_iovec_depth, int64_t target_datasize,
                                                 int64_t start_mem_offset, int64_t start_file_offset,
                                                 H5_flexible_const_ptr_t  buf,
                                                 H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                                 size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr);

#ifdef H5_SUBFILING_DEBUG
static void H5_subfiling_dump_iovecs(subfiling_context_t *sf_context, size_t ioreq_count, size_t iovec_len,
                                     H5FD_subfiling_io_type_t io_type, H5FD_mem_t *io_types,
                                     haddr_t *io_addrs, size_t *io_sizes, H5_flexible_const_ptr_t *io_bufs);
#endif

static const H5FD_class_t H5FD_subfiling_g = {
    H5FD_CLASS_VERSION,
    H5_VFD_SUBFILING,
    H5FD_SUBFILING_NAME,
    H5FD_MAXADDR,
    H5F_CLOSE_WEAK,
    H5FD__subfiling_term,
    H5FD__subfiling_sb_size,
    H5FD__subfiling_sb_encode,
    H5FD__subfiling_sb_decode,
    sizeof(H5FD_subfiling_config_t),
    H5FD__subfiling_fapl_get,
    H5FD__subfiling_fapl_copy,
    H5FD__subfiling_fapl_free,
    0,
    NULL,
    NULL,
    H5FD__subfiling_open,
    H5FD__subfiling_close,
    H5FD__subfiling_cmp,
    H5FD__subfiling_query,
    NULL,
    NULL,
    NULL,
    H5FD__subfiling_get_eoa,
    H5FD__subfiling_set_eoa,
    H5FD__subfiling_get_eof,
    H5FD__subfiling_get_handle,
    H5FD__subfiling_read,
    H5FD__subfiling_write,
    H5FD__subfiling_read_vector,
    H5FD__subfiling_write_vector,
    NULL,
    NULL,
    NULL,
    H5FD__subfiling_truncate,
    NULL,
    NULL,
    H5FD__subfiling_delete,
    H5FD__subfiling_ctl,
    H5FD_FLMAP_DICHOTOMY
};

H5FL_DEFINE_STATIC(H5FD_subfiling_t);

herr_t
H5FD__subfiling_register(void)
{
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (H5I_VFL != H5I_get_type(H5FD_SUBFILING_id_g))
        if ((H5FD_SUBFILING_id_g = H5FD_register(&H5FD_subfiling_g, sizeof(H5FD_class_t), false)) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTREGISTER, FAIL, "can't register subfiling VFD");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5FD__subfiling_unregister(void)
{
    FUNC_ENTER_PACKAGE_NOERR

    H5FD_SUBFILING_id_g = H5I_INVALID_HID;

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static herr_t
H5FD__subfiling_init(void)
{
    int    mpi_initialized = 0;
    int    provided        = 0;
    int    mpi_code;
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (MPI_SUCCESS != (mpi_code = MPI_Initialized(&mpi_initialized)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Initialized failed", mpi_code);
    if (mpi_initialized) {

        if (MPI_SUCCESS != (mpi_code = MPI_Query_thread(&provided)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Query_thread failed", mpi_code);
        if (provided != MPI_THREAD_MULTIPLE)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                        "Subfiling VFD requires the use of MPI_Init_thread with MPI_THREAD_MULTIPLE");
    }
    else {
        if (MPI_SUCCESS != (mpi_code = MPI_Init_thread(NULL, NULL, MPI_THREAD_MULTIPLE, &provided)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Init_thread failed", mpi_code);

        H5FD_mpi_self_initialized_s = true;

        if (provided != MPI_THREAD_MULTIPLE)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                        "MPI doesn't support MPI_Init_thread with MPI_THREAD_MULTIPLE");
    }

    HDcompile_assert(sizeof(((sf_work_request_t *)NULL)->header) == 3 * sizeof(int64_t));
    if (H5_subfiling_rpc_msg_type == MPI_DATATYPE_NULL) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_contiguous(3, MPI_INT64_T, &H5_subfiling_rpc_msg_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code);
        if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(&H5_subfiling_rpc_msg_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code);
    }

    H5FD_subfiling_init_s = true;

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_term(void)
{
    int    mpi_finalized;
    int    mpi_code;
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (MPI_SUCCESS != (mpi_code = MPI_Finalized(&mpi_finalized)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Finalized failed", mpi_code);

    if (!mpi_finalized) {

        if (H5_subfiling_rpc_msg_type != MPI_DATATYPE_NULL)
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&H5_subfiling_rpc_msg_type)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_free failed", mpi_code);

        if (H5FD_mpi_self_initialized_s) {
            if (MPI_SUCCESS != (mpi_code = MPI_Finalize()))
                HMPI_GOTO_ERROR(FAIL, "MPI_Finalize failed", mpi_code);

            H5FD_mpi_self_initialized_s = false;
        }
    }
#ifdef H5_SUBFILING_DEBUG
    else
        Rprintf("** WARNING **: HDF5 is terminating the Subfiling VFD after MPI_Finalize() was called "
               "- an HDF5 ID was probably left unclosed\n");
#endif

    if (H5FD__subfiling_terminate() < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTRELEASE, FAIL, "can't cleanup internal subfiling resources");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5Pset_fapl_subfiling(hid_t fapl_id, const H5FD_subfiling_config_t *vfd_config)
{
    H5FD_subfiling_config_t *subfiling_conf = NULL;
    H5P_genplist_t          *plist          = NULL;
    H5P_genplist_t          *ioc_plist      = NULL;
    MPI_Comm                 comm           = MPI_COMM_NULL;
    MPI_Info                 info           = MPI_INFO_NULL;
    herr_t                   ret_value      = SUCCEED;

    FUNC_ENTER_API(FAIL)

    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, false)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");

    if (!H5FD_subfiling_init_s)
        if (H5FD__subfiling_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");

    if (vfd_config == NULL) {
        if (NULL == (subfiling_conf = H5MM_calloc(sizeof(*subfiling_conf))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate subfiling VFD configuration");

        if (H5FD__subfiling_get_default_config(fapl_id, subfiling_conf) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't get default subfiling VFD configuration");

        vfd_config = subfiling_conf;
    }

    if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI communicator from plist");
    if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI info from plist");
    if (comm == MPI_COMM_NULL)
        comm = MPI_COMM_WORLD;

    if (NULL == (ioc_plist = H5P_object_verify(vfd_config->ioc_fapl_id, H5P_FILE_ACCESS, false)))
        HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, FAIL, "not a file access property list");
    if (H5P_set(ioc_plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI communicator on plist");
    if (H5P_set(ioc_plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI info on plist");

    if (H5FD__subfiling_validate_config(vfd_config) < 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid subfiling VFD configuration");

    if (H5FD__subfiling_set_config_prop(ioc_plist, &vfd_config->shared_cfg) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set subfiling configuration on IOC FAPL");

    ret_value = H5P_set_driver(plist, H5FD_SUBFILING, vfd_config, NULL);

done:
    if (H5_mpi_comm_free(&comm) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free MPI Communicator");
    if (H5_mpi_info_free(&info) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free MPI Info object");

    if (subfiling_conf) {
        if (subfiling_conf->ioc_fapl_id >= 0 && H5I_dec_ref(subfiling_conf->ioc_fapl_id) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTDEC, FAIL, "can't close IOC FAPL");
        H5MM_free(subfiling_conf);
    }

    FUNC_LEAVE_API(ret_value)
}

herr_t
H5Pget_fapl_subfiling(hid_t fapl_id, H5FD_subfiling_config_t *config_out)
{
    const H5FD_subfiling_config_t *config             = NULL;
    H5P_genplist_t                *plist              = NULL;
    bool                           use_default_config = false;
    herr_t                         ret_value          = SUCCEED;

    FUNC_ENTER_API(FAIL)

    if (config_out == NULL)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "config_out is NULL");
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");

    if (!H5FD_subfiling_init_s)
        if (H5FD__subfiling_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");

    if (H5FD_SUBFILING != H5P_peek_driver(plist))
        use_default_config = true;
    else {
        if (NULL == (config = H5P_peek_driver_info(plist)))
            use_default_config = true;
    }

    if (use_default_config) {
        if (H5FD__subfiling_get_default_config(fapl_id, config_out) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get default Subfiling VFD configuration");
    }
    else {

        H5MM_memcpy(config_out, config, sizeof(H5FD_subfiling_config_t));

        if (H5FD__copy_plist(config->ioc_fapl_id, &(config_out->ioc_fapl_id)) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "can't copy IOC FAPL");
    }

done:
    FUNC_LEAVE_API(ret_value)
}

herr_t
H5FDsubfiling_get_file_mapping(hid_t file_id, char ***filenames, size_t *len)
{
    subfiling_context_t *sf_context    = NULL;
    H5FD_t              *driver        = NULL;
    H5F_t               *file_ptr      = NULL;
    char               **filenames_arr = NULL;
    char                *filepath      = NULL;
    char                *subfile_dir   = NULL;
    char                *base          = NULL;
    int                  num_subfiles  = 0;
    int                  num_digits    = 0;
    herr_t               ret_value     = SUCCEED;

    FUNC_ENTER_API(FAIL)

    if (file_id < 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid file ID");
    if (!filenames)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "`filenames` was NULL");
    if (!len)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "`len` was NULL");

    *filenames = NULL;
    *len       = 0;

    if (NULL == (file_ptr = H5VL_object(file_id)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid file ID");

    if (H5FD_SUBFILING != H5F_get_driver_id(file_ptr))
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "file is not using Subfiling VFD");

    if (H5F_shared_get_file_driver(H5F_SHARED(file_ptr), &driver) < 0)
        HGOTO_ERROR(H5E_FILE, H5E_CANTGET, FAIL, "can't get driver structure from file ID");

    if (NULL == (sf_context = H5FD__subfiling_get_object(((H5FD_subfiling_t *)driver)->context_id)))
        HGOTO_ERROR(H5E_FILE, H5E_CANTGET, FAIL, "can't get subfiling context from ID");

    if (!sf_context->topology)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL,
                    "application topology hasn't been initialized yet for this file");

    assert(sf_context->h5_file_id != UINT64_MAX);
    assert(sf_context->h5_filename);
    assert(sf_context->sf_num_subfiles > 0);
    assert(sf_context->topology);

    if (sf_context->topology->rank_is_ioc) {
        assert(sf_context->sf_fids);
        assert(sf_context->sf_num_fids > 0);

        if (H5_basename(sf_context->h5_filename, &base) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't get HDF5 file basename");

        if (sf_context->subfile_prefix) {
            if (NULL == (subfile_dir = H5MM_strdup(sf_context->subfile_prefix)))
                HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "couldn't copy subfile prefix");
        }
        else {
            if (H5_dirname(sf_context->h5_filename, &subfile_dir) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "couldn't get HDF5 file dirname");
        }

        num_subfiles = sf_context->sf_num_subfiles;
        num_digits   = (int)(log10(num_subfiles) + 1);

        if (NULL == (filenames_arr = calloc((size_t)sf_context->sf_num_fids, sizeof(char *))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "couldn't allocate filenames array");

        for (int i = 0; i < sf_context->sf_num_fids; i++) {
            int subfile_idx;

            if (NULL == (filepath = malloc(PATH_MAX)))
                HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "couldn't allocate space for subfile filename");

            subfile_idx = (i * sf_context->topology->n_io_concentrators) + sf_context->topology->ioc_idx + 1;

            snprintf(filepath, PATH_MAX, "%s/" H5FD_SUBFILING_FILENAME_TEMPLATE, subfile_dir, base,
                     sf_context->h5_file_id, num_digits, subfile_idx, num_subfiles);

            filenames_arr[i] = filepath;
            filepath         = NULL;
        }

        *filenames = filenames_arr;
        *len       = (size_t)sf_context->sf_num_fids;
    }

done:
    if (ret_value < 0) {
        if (filenames_arr) {
            for (int i = 0; i < sf_context->sf_num_fids; i++) {
                free(filenames_arr[i]);
            }
        }
        free(filenames_arr);
    }
    H5MM_free(base);
    H5MM_free(subfile_dir);

    FUNC_LEAVE_API(ret_value);
}

static herr_t
H5FD__subfiling_get_default_config(hid_t fapl_id, H5FD_subfiling_config_t *config_out)
{
    H5P_genplist_t *plist;
    MPI_Comm        comm = MPI_COMM_NULL;
    MPI_Info        info = MPI_INFO_NULL;
    char           *h5_require_ioc;
    herr_t          ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(config_out);

    memset(config_out, 0, sizeof(*config_out));

    config_out->magic       = H5FD_SUBFILING_FAPL_MAGIC;
    config_out->version     = H5FD_SUBFILING_CURR_FAPL_VERSION;
    config_out->ioc_fapl_id = H5I_INVALID_HID;
    config_out->require_ioc = true;

    config_out->shared_cfg.ioc_selection = SELECT_IOC_ONE_PER_NODE;
    config_out->shared_cfg.stripe_size   = H5FD_SUBFILING_DEFAULT_STRIPE_SIZE;
    config_out->shared_cfg.stripe_count  = H5FD_SUBFILING_DEFAULT_STRIPE_COUNT;

    if ((h5_require_ioc = getenv("H5_REQUIRE_IOC")) != NULL) {
        int value_check = atoi(h5_require_ioc);
        if (value_check == 0)
            config_out->require_ioc = false;
    }

    if (NULL == (plist = (H5P_genplist_t *)H5I_object(fapl_id)))
        HGOTO_ERROR(H5E_VFL, H5E_BADID, FAIL, "can't find object for ID");
    if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTGET, FAIL, "can't get MPI communicator from plist");
    if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTGET, FAIL, "can't get MPI info from plist");
    if (comm == MPI_COMM_NULL) {
        comm = MPI_COMM_WORLD;

        if (H5P_set(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI communicator");
        if (H5P_set(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI info object");
    }

    if (H5FD__copy_plist(H5P_FILE_ACCESS_DEFAULT, &config_out->ioc_fapl_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTCREATE, FAIL, "can't create default FAPL");
    if (NULL == (plist = (H5P_genplist_t *)H5I_object(config_out->ioc_fapl_id)))
        HGOTO_ERROR(H5E_VFL, H5E_BADID, FAIL, "can't find object for ID");

    if (config_out->require_ioc) {
        H5FD_ioc_config_t ioc_config;

        if (H5P_set(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI communicator");
        if (H5P_set(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set MPI info object");

        if (H5FD__subfiling_get_default_ioc_config(&ioc_config) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get default IOC config");
        if (H5P_set_driver(plist, H5FD_IOC, &ioc_config, NULL) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set IOC VFD on IOC FAPL");
    }
    else {
        if (H5P_set_driver(plist, H5FD_SEC2, NULL, NULL) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set sec2 VFD on IOC FAPL");
    }

done:
    if (H5_mpi_comm_free(&comm) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free MPI Communicator");
    if (H5_mpi_info_free(&info) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free MPI Info object");

    if (ret_value < 0) {
        if (config_out->ioc_fapl_id >= 0 && H5I_dec_ref(config_out->ioc_fapl_id) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTDEC, FAIL, "can't close FAPL");
        config_out->ioc_fapl_id = H5I_INVALID_HID;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_validate_config(const H5FD_subfiling_config_t *fa)
{
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(fa != NULL);

    if (fa->magic != H5FD_SUBFILING_FAPL_MAGIC)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid H5FD_subfiling_config_t magic value");
    if (fa->version != H5FD_SUBFILING_CURR_FAPL_VERSION)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "unknown H5FD_subfiling_config_t version");
    if (fa->ioc_fapl_id < 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid IOC FAPL ID");
    if (!fa->require_ioc)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL,
                    "Subfiling VFD currently always requires IOC VFD to be used");
    if (H5FD__subfiling_validate_config_params(&fa->shared_cfg) < 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "invalid subfiling configuration parameters");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static hsize_t
H5FD__subfiling_sb_size(H5FD_t *_file)
{
    subfiling_context_t *sf_context = NULL;
    H5FD_subfiling_t    *file       = (H5FD_subfiling_t *)_file;
    hsize_t              ret_value  = 0;

    FUNC_ENTER_PACKAGE_NOERR

    assert(file);

    ret_value += sizeof(uint32_t);

    ret_value += sizeof(uint32_t);

    ret_value += sizeof(int32_t);

    ret_value += sizeof(int64_t);

    ret_value += sizeof(int64_t);

    ret_value += sizeof(uint64_t);

    if (NULL == (sf_context = H5FD__subfiling_get_object(file->context_id)))
        file->fail_to_encode = true;
    else {
        if (sf_context->config_file_prefix)
            ret_value += strlen(sf_context->config_file_prefix) + 1;
    }

    if (file->sf_file) {

        ret_value += 9;

        ret_value += H5FD_sb_size(file->sf_file);
    }

    if (ret_value > H5FD_SUBFILING_MAX_DRV_INFO_SIZE)
        file->fail_to_encode = true;

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_sb_encode(H5FD_t *_file, char *name, unsigned char *buf)
{
    subfiling_context_t *sf_context = NULL;
    H5FD_subfiling_t    *file       = (H5FD_subfiling_t *)_file;
    uint8_t             *p          = (uint8_t *)buf;
    uint64_t             tmpu64;
    int64_t              tmp64;
    int32_t              tmp32;
    size_t               prefix_len = 0;
    herr_t               ret_value  = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (file->fail_to_encode)
        HGOTO_ERROR(
            H5E_VFL, H5E_CANTENCODE, FAIL,
            "can't encode subfiling driver info message - message was too large or internal error occurred");

    if (NULL == (sf_context = H5FD__subfiling_get_object(file->context_id)))
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get subfiling context object");

    strncpy(name, "Subfilin", 9);
    name[8] = '\0';

    UINT32ENCODE(p, file->fa.magic);

    UINT32ENCODE(p, file->fa.version);

    tmp32 = (int32_t)file->fa.require_ioc;
    INT32ENCODE(p, tmp32);

    INT64ENCODE(p, sf_context->sf_stripe_size);

    tmp64 = sf_context->sf_num_subfiles;
    INT64ENCODE(p, tmp64);

    if (sf_context->config_file_prefix) {
        prefix_len = strlen(sf_context->config_file_prefix) + 1;
        H5_CHECKED_ASSIGN(tmpu64, uint64_t, prefix_len, size_t);
    }
    else
        tmpu64 = 0;
    UINT64ENCODE(p, tmpu64);

    if (sf_context->config_file_prefix) {
        H5MM_memcpy(p, sf_context->config_file_prefix, prefix_len);
        p += prefix_len;
    }

    if (file->sf_file)
        if (H5FD_sb_encode(file->sf_file, (char *)p, p + 9) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTENCODE, FAIL, "unable to encode IOC VFD's superblock information");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_sb_decode(H5FD_t *_file, const char *name, const unsigned char *buf)
{
    subfiling_context_t *sf_context = NULL;
    H5FD_subfiling_t    *file       = (H5FD_subfiling_t *)_file;
    const uint8_t       *p          = (const uint8_t *)buf;
    uint64_t             tmpu64;
    int64_t              tmp64;
    int32_t              tmp32;
    herr_t               ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (file->fail_to_encode)
        HGOTO_ERROR(
            H5E_VFL, H5E_CANTDECODE, FAIL,
            "can't decode subfiling driver info message - message wasn't encoded (or encoded improperly)");

    if (NULL == (sf_context = H5FD__subfiling_get_object(file->context_id)))
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get subfiling context object");

    if (strncmp(name, "Subfilin", 9))
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "invalid driver name in superblock");

    UINT32DECODE(p, file->fa.magic);

    UINT32DECODE(p, file->fa.version);

    INT32DECODE(p, tmp32);
    file->fa.require_ioc = (bool)tmp32;

    INT64DECODE(p, file->fa.shared_cfg.stripe_size);

    INT64DECODE(p, tmp64);
    H5_CHECK_OVERFLOW(tmp64, int64_t, int32_t);
    file->fa.shared_cfg.stripe_count = (int32_t)tmp64;

    UINT64DECODE(p, tmpu64);

    if (tmpu64 > 0) {
        if (!sf_context->config_file_prefix) {
            if (NULL == (sf_context->config_file_prefix = H5MM_malloc(tmpu64)))
                HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL,
                            "can't allocate space for config file prefix string");

            H5MM_memcpy(sf_context->config_file_prefix, p, tmpu64);

            sf_context->config_file_prefix[tmpu64 - 1] = '\0';
        }

        p += tmpu64;
    }

    if (file->sf_file)
        if (H5FD_sb_load(file->sf_file, (const char *)p, p + 9) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTDECODE, FAIL, "unable to decode IOC VFD's superblock information");

    if (H5FD__subfiling_validate_config(&file->fa) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "decoded subfiling configuration info is invalid");

    if (file->fa.shared_cfg.stripe_size != sf_context->sf_stripe_size)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL,
                    "specified subfiling stripe size (%" PRId64
                    ") doesn't match value stored in file (%" PRId64 ")",
                    sf_context->sf_stripe_size, file->fa.shared_cfg.stripe_size);

    if (file->fa.shared_cfg.stripe_count != sf_context->sf_num_subfiles)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL,
                    "specified subfiling stripe count (%d) doesn't match value stored in file (%" PRId32 ")",
                    sf_context->sf_num_subfiles, file->fa.shared_cfg.stripe_count);

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static void *
H5FD__subfiling_fapl_get(H5FD_t *_file)
{
    H5FD_subfiling_t        *file      = (H5FD_subfiling_t *)_file;
    H5FD_subfiling_config_t *fa        = NULL;
    void                    *ret_value = NULL;

    FUNC_ENTER_PACKAGE

    if (NULL == (fa = H5MM_calloc(sizeof(H5FD_subfiling_config_t))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, NULL, "memory allocation failed");

    H5MM_memcpy(fa, &file->fa, sizeof(H5FD_subfiling_config_t));

    if (H5FD__copy_plist(file->fa.ioc_fapl_id, &fa->ioc_fapl_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "can't copy IOC FAPL");

    ret_value = fa;

done:
    if (ret_value == NULL)
        if (fa != NULL)
            H5MM_xfree(fa);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__copy_plist(hid_t fapl_id, hid_t *id)
{
    H5P_genplist_t *plist     = NULL;
    int             ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(id != NULL);

    if (false == H5P_isa_class(fapl_id, H5P_FILE_ACCESS))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");

    if (NULL == (plist = (H5P_genplist_t *)H5I_object(fapl_id)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "unable to get property list");

    if (H5I_INVALID_HID == (*id = H5P_copy_plist(plist, false)))
        HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, FAIL, "unable to copy file access property list");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static void *
H5FD__subfiling_fapl_copy(const void *_old_fa)
{
    const H5FD_subfiling_config_t *old_fa    = (const H5FD_subfiling_config_t *)_old_fa;
    H5FD_subfiling_config_t       *new_fa    = NULL;
    void                          *ret_value = NULL;

    FUNC_ENTER_PACKAGE

    if (NULL == (new_fa = H5MM_malloc(sizeof(H5FD_subfiling_config_t))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, NULL, "memory allocation failed");

    H5MM_memcpy(new_fa, old_fa, sizeof(H5FD_subfiling_config_t));

    if (H5FD__copy_plist(old_fa->ioc_fapl_id, &new_fa->ioc_fapl_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "can't copy the IOC FAPL");

    ret_value = new_fa;

done:
    if (ret_value == NULL)
        if (new_fa != NULL)
            H5MM_xfree(new_fa);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_fapl_free(void *_fa)
{
    H5FD_subfiling_config_t *fa        = (H5FD_subfiling_config_t *)_fa;
    herr_t                   ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(fa != NULL);

    if (fa->ioc_fapl_id >= 0 && H5I_dec_ref(fa->ioc_fapl_id) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTDEC, FAIL, "can't close IOC FAPL");
    fa->ioc_fapl_id = H5I_INVALID_HID;

    H5MM_xfree(fa);

    FUNC_LEAVE_NOAPI(ret_value)
}

static H5FD_t *
H5FD__subfiling_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t maxaddr)
{
    H5FD_subfiling_t              *file   = NULL;
    const H5FD_subfiling_config_t *config = NULL;
    H5FD_subfiling_config_t        default_config;
    H5FD_class_t                  *driver = NULL;
    H5P_genplist_t                *plist  = NULL;
    H5FD_driver_prop_t             driver_prop;
    bool                           bcasted_eof = false;
    int64_t                        sf_eof      = -1;
    int                            mpi_code;
    H5FD_t                        *ret_value = NULL;

    FUNC_ENTER_PACKAGE

    if (!name || !*name)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "invalid file name");
    if (0 == maxaddr || HADDR_UNDEF == maxaddr)
        HGOTO_ERROR(H5E_ARGS, H5E_BADRANGE, NULL, "bogus maxaddr");
    if (H5FD_ADDR_OVERFLOW(maxaddr))
        HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, NULL, "bogus maxaddr");

    if (!H5FD_subfiling_init_s)
        if (H5FD__subfiling_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, NULL, "can't initialize driver");

    if (NULL == (file = (H5FD_subfiling_t *)H5FL_CALLOC(H5FD_subfiling_t)))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, NULL, "unable to allocate file struct");
    file->comm           = MPI_COMM_NULL;
    file->info           = MPI_INFO_NULL;
    file->file_id        = UINT64_MAX;
    file->context_id     = -1;
    file->fa.ioc_fapl_id = H5I_INVALID_HID;
    file->ext_comm       = MPI_COMM_NULL;
    file->fail_to_encode = false;

    if (NULL == (plist = (H5P_genplist_t *)H5I_object(fapl_id)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "not a file access property list");

    if (H5FD_mpi_self_initialized_s) {
        file->comm = MPI_COMM_WORLD;
        file->info = MPI_INFO_NULL;
    }
    else {

        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &file->comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get MPI communicator");
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &file->info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get MPI info object");

        if (file->comm == MPI_COMM_NULL)
            HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "invalid or unset MPI communicator in FAPL");
    }

    if (MPI_SUCCESS != (mpi_code = MPI_Comm_rank(file->comm, &file->mpi_rank)))
        HMPI_GOTO_ERROR(NULL, "MPI_Comm_rank failed", mpi_code);
    if (MPI_SUCCESS != (mpi_code = MPI_Comm_size(file->comm, &file->mpi_size)))
        HMPI_GOTO_ERROR(NULL, "MPI_Comm_size failed", mpi_code);

    if (file->mpi_size == 1) {
        H5AC_cache_config_t mdc_config;

        if (H5P_get(plist, H5F_ACS_META_CACHE_INIT_CONFIG_NAME, &mdc_config) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get metadata cache initial config");
        mdc_config.metadata_write_strategy = H5AC_METADATA_WRITE_STRATEGY__PROCESS_0_ONLY;
        if (H5P_set(plist, H5F_ACS_META_CACHE_INIT_CONFIG_NAME, &mdc_config) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, NULL, "can't set metadata cache initial config");
    }

    config = H5P_peek_driver_info(plist);
    if (!config || (H5P_FILE_ACCESS_DEFAULT == fapl_id)) {
        if (H5FD__subfiling_get_default_config(fapl_id, &default_config) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get default subfiling VFD configuration");
        config = &default_config;
    }

    H5MM_memcpy(&file->fa, config, sizeof(H5FD_subfiling_config_t));
    if (H5FD__copy_plist(config->ioc_fapl_id, &file->fa.ioc_fapl_id) < 0) {
        file->fa.ioc_fapl_id = H5I_INVALID_HID;
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "can't copy FAPL");
    }

    if (NULL == (plist = H5I_object(file->fa.ioc_fapl_id)))
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "invalid IOC FAPL");

    if (H5P_peek(plist, H5F_ACS_FILE_DRV_NAME, &driver_prop) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get driver ID & info");
    if (NULL == (driver = (H5FD_class_t *)H5I_object(driver_prop.driver_id)))
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, NULL, "invalid driver ID in file access property list");

    if (driver->value != H5_VFD_IOC)
        HGOTO_ERROR(H5E_VFL, H5E_CANTOPENFILE, NULL,
                    "unable to open file '%s' - only IOC VFD is currently supported for subfiles", name);

    if (H5FD__subfiling_resolve_pathname(name, file->comm, &file->file_path) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't resolve filepath");
    if (H5_dirname(file->file_path, &file->file_dir) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get filepath dirname");

    if (H5FD__subfiling_open_stub_file(file->file_path, flags, file->comm, &file->stub_file, &file->file_id) <
        0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTOPENFILE, NULL, "can't open HDF5 stub file");

    if (H5FD__subfiling_set_file_id_prop(plist, file->file_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, NULL, "can't set stub file ID on FAPL");

    if (H5FD_open(false, &file->sf_file, name, flags, file->fa.ioc_fapl_id, HADDR_UNDEF) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTOPENFILE, NULL, "unable to open IOC file");

    if (H5FD__subfile_fid_to_context(file->file_id, &file->context_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "unable to retrieve subfiling context ID for this file");
    file->fa.require_ioc = true;

    if (file->mpi_rank == 0)
        if (H5FD__subfiling__get_real_eof(file->context_id, &sf_eof) < 0)
            sf_eof = -1;
    if (file->mpi_size > 1)
        if (MPI_SUCCESS != (mpi_code = MPI_Bcast(&sf_eof, 1, MPI_INT64_T, 0, file->comm)))
            HMPI_GOTO_ERROR(NULL, "MPI_Bcast", mpi_code);
    bcasted_eof = true;
    if (sf_eof < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "lead MPI process failed to get file EOF");

    file->eof       = (haddr_t)sf_eof;
    file->local_eof = file->eof;

    ret_value = (H5FD_t *)file;

done:
    if (config == &default_config)
        if (H5I_dec_ref(config->ioc_fapl_id) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTCLOSEOBJ, NULL, "can't close IOC FAPL");

    if (NULL == ret_value)
        if (file) {

            if (file->comm != MPI_COMM_NULL)
                if (!bcasted_eof) {
                    sf_eof = -1;

                    if (file->mpi_size > 1)
                        if (MPI_SUCCESS != (mpi_code = MPI_Bcast(&sf_eof, 1, MPI_INT64_T, 0, file->comm)))
                            HMPI_DONE_ERROR(NULL, "MPI_Bcast failed", mpi_code);
                }

            if (H5FD__subfiling_close_int(file) < 0)
                HDONE_ERROR(H5E_VFL, H5E_CLOSEERROR, NULL, "couldn't close file");
        }

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_close_int(H5FD_subfiling_t *file)
{
    int    mpi_finalized;
    int    mpi_code;
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);

    if (file->sf_file && H5FD_close(file->sf_file) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTCLOSEFILE, FAIL, "unable to close subfile");
    if (file->stub_file && H5FD_close(file->stub_file) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTCLOSEFILE, FAIL, "unable to close HDF5 stub file");

    if (file->fa.ioc_fapl_id >= 0 && H5I_dec_ref(file->fa.ioc_fapl_id) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTDEC, FAIL, "can't close IOC FAPL");

    if (MPI_SUCCESS != (mpi_code = MPI_Finalized(&mpi_finalized)))
        HMPI_DONE_ERROR(FAIL, "MPI_Finalized failed", mpi_code);
    if (!mpi_finalized) {
        if (H5_mpi_comm_free(&file->comm) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "unable to free MPI Communicator");
        if (H5_mpi_info_free(&file->info) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "unable to free MPI Info object");
        if (H5_mpi_comm_free(&file->ext_comm) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free MPI communicator");
    }

    H5MM_free(file->file_path);
    H5MM_free(file->file_dir);

    if (file->context_id >= 0 && H5FD__subfiling_free_object(file->context_id) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "can't free subfiling context object");

    H5FL_FREE(H5FD_subfiling_t, file);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_close(H5FD_t *_file)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (H5FD__subfiling_close_int(file) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTCLOSEFILE, FAIL, "unable to close file");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static int
H5FD__subfiling_cmp(const H5FD_t *_f1, const H5FD_t *_f2)
{
    const H5FD_subfiling_t *f1        = (const H5FD_subfiling_t *)_f1;
    const H5FD_subfiling_t *f2        = (const H5FD_subfiling_t *)_f2;
    int                     ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

    assert(f1);
    assert(f2);

    ret_value = H5FD_cmp(f1->sf_file, f2->sf_file);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_query(const H5FD_t H5_ATTR_UNUSED *_file, unsigned long *flags)
{
    FUNC_ENTER_PACKAGE_NOERR

    if (flags) {
        *flags = 0;
        *flags |= H5FD_FEAT_AGGREGATE_METADATA;
        *flags |= H5FD_FEAT_AGGREGATE_SMALLDATA;
        *flags |= H5FD_FEAT_HAS_MPI;
    }

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static haddr_t
H5FD__subfiling_get_eoa(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_subfiling_t *file = (const H5FD_subfiling_t *)_file;

    FUNC_ENTER_PACKAGE_NOERR

    FUNC_LEAVE_NOAPI(file->eoa)
}

static herr_t
H5FD__subfiling_set_eoa(H5FD_t *_file, H5FD_mem_t type, haddr_t addr)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    file->eoa = addr;

    if (file->mpi_rank == 0)
        if (H5FD_set_eoa(file->stub_file, type, addr) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set HDF5 stub file EOA");

    if (H5FD_set_eoa(file->sf_file, type, addr) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set subfile EOA");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static haddr_t
H5FD__subfiling_get_eof(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_subfiling_t *file = (const H5FD_subfiling_t *)_file;

    FUNC_ENTER_PACKAGE_NOERR

    FUNC_LEAVE_NOAPI(file->eof)
}

static herr_t
H5FD__subfiling_get_handle(H5FD_t *_file, hid_t H5_ATTR_UNUSED fapl, void **file_handle)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (!file_handle)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "file handle not valid");

    if (H5FD_get_vfd_handle(file->sf_file, file->fa.ioc_fapl_id, file_handle) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get subfile handle");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_read(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr, size_t size,
                     void *buf)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);
    assert(buf);

    if (H5FD__subfiling_io_helper(file, 1, &type, &addr, &size, (H5_flexible_const_ptr_t *)&buf,
                                  IO_TYPE_READ) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "read from subfiles failed");

    addr += (haddr_t)size;

    file->pos = addr;
    file->op  = OP_READ;

done:
    if (ret_value < 0) {

        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_write(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr, size_t size,
                      const void *buf)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);
    assert(buf);

    if (H5FD__subfiling_io_helper(file, 1, &type, &addr, &size, (H5_flexible_const_ptr_t *)&buf,
                                  IO_TYPE_WRITE) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "write to subfiles failed");

    addr += (haddr_t)size;

    file->pos = addr;
    file->op  = OP_WRITE;

    file->eof = HADDR_UNDEF;

    if (file->pos > file->local_eof)
        file->local_eof = file->pos;

done:
    if (ret_value < 0) {

        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_read_vector(H5FD_t *_file, hid_t dxpl_id, uint32_t count, H5FD_mem_t types[], haddr_t addrs[],
                            size_t sizes[], void *bufs[])
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);
    assert(count == 0 || types);
    assert(count == 0 || addrs);
    assert(count == 0 || sizes);
    assert(count == 0 || bufs);

    assert(count == 0 || sizes[0] != 0);
    assert(count == 0 || types[0] != H5FD_MEM_NOLIST);

    if (H5P_DEFAULT == dxpl_id)
        dxpl_id = H5P_DATASET_XFER_DEFAULT;
    else if (true != H5P_isa_class(dxpl_id, H5P_DATASET_XFER))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a data transfer property list");

    H5CX_set_dxpl(dxpl_id);

    if (H5FD__subfiling_io_helper(file, (size_t)count, types, addrs, sizes, (H5_flexible_const_ptr_t *)bufs,
                                  IO_TYPE_READ) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "couldn't read data");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_write_vector(H5FD_t *_file, hid_t dxpl_id, uint32_t count, H5FD_mem_t types[],
                             haddr_t addrs[], size_t sizes[], const void *bufs[])
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);
    assert(count == 0 || types);
    assert(count == 0 || addrs);
    assert(count == 0 || sizes);
    assert(count == 0 || bufs);

    assert(count == 0 || sizes[0] != 0);
    assert(count == 0 || types[0] != H5FD_MEM_NOLIST);

    if (H5P_DEFAULT == dxpl_id)
        dxpl_id = H5P_DATASET_XFER_DEFAULT;
    else if (true != H5P_isa_class(dxpl_id, H5P_DATASET_XFER))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a data transfer property list");

    H5CX_set_dxpl(dxpl_id);

    if (H5FD__subfiling_io_helper(file, (size_t)count, types, addrs, sizes, (H5_flexible_const_ptr_t *)bufs,
                                  IO_TYPE_WRITE) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "couldn't write data");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_truncate(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, bool H5_ATTR_UNUSED closing)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);

    if (!H5_addr_eq(file->eoa, file->last_eoa)) {
        int64_t sf_eof;
        int64_t eoa;
        int     mpi_code;

        if (!H5CX_get_mpi_file_flushing())
            if (file->mpi_size > 1)
                if (MPI_SUCCESS != (mpi_code = MPI_Barrier(file->comm)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_code);

        if (0 == file->mpi_rank)
            if (H5FD__subfiling__get_real_eof(file->context_id, &sf_eof) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get EOF");

        if (file->mpi_size > 1)
            if (MPI_SUCCESS != (mpi_code = MPI_Bcast(&sf_eof, 1, MPI_INT64_T, 0, file->comm)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_code);

        if (sf_eof < 0)
            HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "invalid EOF");

        H5_CHECKED_ASSIGN(eoa, int64_t, file->eoa, haddr_t);

        if (H5FD__subfiling__truncate_sub_files(file->context_id, eoa, file->comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTUPDATE, FAIL, "subfile truncate request failed");

#if 0

        if (file->mpi_rank == 0)
            if (H5FD_truncate(file->stub_file, closing) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTUPDATE, FAIL, "stub file truncate request failed");
#endif

        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;

        file->last_eoa = file->eoa;
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_delete(const char *name, hid_t fapl)
{
    const H5FD_subfiling_config_t *subfiling_config = NULL;
    H5FD_subfiling_config_t        default_config;
    H5P_genplist_t                *plist     = NULL;
    herr_t                         ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (!H5FD_subfiling_init_s)
        if (H5FD__subfiling_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");

    if (NULL == (plist = H5P_object_verify(fapl, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");

    if (H5FD_SUBFILING != H5P_peek_driver(plist))
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "incorrect driver set on FAPL");

    if (NULL == (subfiling_config = H5P_peek_driver_info(plist))) {
        if (H5FD__subfiling_get_default_config(fapl, &default_config) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get default Subfiling VFD configuration");
        subfiling_config = &default_config;
    }

    if (H5FD_delete(name, subfiling_config->ioc_fapl_id) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTDELETE, FAIL, "unable to delete file");

done:
    if (subfiling_config == &default_config)
        if (H5I_dec_ref(subfiling_config->ioc_fapl_id) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTCLOSEOBJ, FAIL, "unable to close IOC FAPL");

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_ctl(H5FD_t *_file, uint64_t op_code, uint64_t flags, const void H5_ATTR_UNUSED *input,
                    void **output)
{
    H5FD_subfiling_t *file      = (H5FD_subfiling_t *)_file;
    herr_t            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);

    switch (op_code) {
        case H5FD_CTL_GET_MPI_COMMUNICATOR_OPCODE:
            assert(output);
            assert(*output);

            if (file->ext_comm == MPI_COMM_NULL)
                if (H5_mpi_comm_dup(file->comm, &file->ext_comm) < 0)
                    HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't duplicate MPI communicator");

            **((MPI_Comm **)output) = file->ext_comm;
            break;

        case H5FD_CTL_GET_MPI_INFO_OPCODE:
            assert(output);
            assert(*output);
            **((MPI_Info **)output) = file->info;
            break;

        case H5FD_CTL_GET_MPI_RANK_OPCODE:
            assert(output);
            assert(*output);
            **((int **)output) = file->mpi_rank;
            break;

        case H5FD_CTL_GET_MPI_SIZE_OPCODE:
            assert(output);
            assert(*output);
            **((int **)output) = file->mpi_size;
            break;

        default:
            if (flags & H5FD_CTL_FAIL_IF_UNKNOWN_FLAG)
                HGOTO_ERROR(H5E_VFL, H5E_FCNTL, FAIL, "unknown op_code and fail if unknown");
            break;
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_io_helper(H5FD_subfiling_t *file, size_t io_count, H5FD_mem_t types[], haddr_t addrs[],
                          size_t sizes[], H5_flexible_const_ptr_t bufs[], H5FD_subfiling_io_type_t io_type)
{
    H5_flexible_const_ptr_t *io_bufs      = NULL;
    subfiling_context_t     *sf_context   = NULL;
    H5FD_mpio_xfer_t         xfer_mode    = H5FD_MPIO_INDEPENDENT;
    H5FD_mem_t              *io_types     = NULL;
    haddr_t                 *io_addrs     = NULL;
    size_t                  *io_sizes     = NULL;
    haddr_t                  file_eoa     = HADDR_UNDEF;
    size_t                   io_size      = 0;
    bool                     rank0_bcast  = false;
    bool                     extend_sizes = false;
    int                      num_subfiles;
    herr_t                   ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);

    if (HADDR_UNDEF == (file_eoa = H5FD__subfiling_get_eoa((const H5FD_t *)file, H5FD_MEM_DEFAULT)))
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get file EOA");

    extend_sizes = false;
    for (size_t i = 0; i < io_count; i++) {
        if (!extend_sizes) {
            if (i > 0 && sizes[i] == 0)
                extend_sizes = true;
            else
                io_size = sizes[i];
        }

        if (!H5_addr_defined(addrs[i]))
            HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "addr[%zu] undefined, addr = %" PRIuHADDR, i, addrs[i]);
        if (H5FD_REGION_OVERFLOW(addrs[i], io_size))
            HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, FAIL, "addr[%zu] overflow, addr = %" PRIuHADDR ", size = %zu",
                        i, addrs[i], io_size);
        if ((addrs[i] + io_size) > file_eoa)
            HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, FAIL,
                        "addr overflow, addrs[%zu] = %" PRIuHADDR ", sizes[%zu] = %zu, eoa = %" PRIuHADDR, i,
                        addrs[i], i, io_size, file_eoa);
    }

    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't determine I/O collectivity setting");

    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        MPI_Datatype btype, ftype;

        if (H5CX_get_mpi_coll_datatypes(&btype, &ftype) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O datatypes");
        if (MPI_BYTE != btype || MPI_BYTE != ftype)
            HGOTO_ERROR(H5E_VFL, H5E_UNSUPPORTED, FAIL, "collective I/O is currently unsupported");
    }

    H5CX_set_io_xfer_mode(H5FD_MPIO_INDEPENDENT);

    if (io_type == IO_TYPE_READ)
        rank0_bcast = H5CX_get_mpio_rank0_bcast();

    if (NULL == (sf_context = (subfiling_context_t *)H5FD__subfiling_get_object(file->context_id)))
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "invalid or missing subfiling context object");
    assert(sf_context->topology);

    if ((num_subfiles = sf_context->sf_num_subfiles) <= 0)
        HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "invalid number of subfiles (%d)", num_subfiles);

    if (num_subfiles == 1) {
        uint32_t u32_io_count;

        H5_CHECKED_ASSIGN(u32_io_count, uint32_t, io_count, size_t);

        if (io_type == IO_TYPE_WRITE) {

            if (H5FD_write_vector(file->sf_file, u32_io_count, types, addrs, sizes, (const void **)bufs) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "write to subfile failed");

            if (H5FD__subfiling_mirror_writes_to_stub(file, u32_io_count, types, addrs, sizes,
                                                      (const void **)bufs) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "mirrored write to stub file failed");
        }
        else

            if (H5FD_read_vector(file->sf_file, u32_io_count, types, addrs, sizes, (void **)bufs) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "read from subfile failed");
    }
    else {
        uint32_t iovec_len;
        size_t   ioreq_count = 0;
        herr_t   status;

        status = H5FD__subfiling_generate_io_vectors(
            sf_context,
            io_count,
            types,
            addrs,
            sizes,
            bufs,
            io_type,
            &ioreq_count,
            &iovec_len,
            &io_types,
            &io_addrs,
            &io_sizes,
            &io_bufs);

        if (status < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize I/O vectors");

        if (ioreq_count == 0)
            HGOTO_DONE(SUCCEED);

#ifdef H5_SUBFILING_DEBUG
        H5_subfiling_dump_iovecs(sf_context, ioreq_count, iovec_len, io_type, io_types, io_addrs, io_sizes,
                                 io_bufs);
#endif

        for (size_t ioreq_idx = 0; ioreq_idx < ioreq_count; ioreq_idx++) {
            H5_flexible_const_ptr_t *io_bufs_ptr   = NULL;
            H5FD_mem_t              *io_types_ptr  = NULL;
            uint32_t                 final_vec_len = iovec_len;
            haddr_t                 *io_addrs_ptr  = NULL;
            size_t                  *io_sizes_ptr  = NULL;

            io_types_ptr = &io_types[ioreq_idx * iovec_len];
            io_addrs_ptr = &io_addrs[ioreq_idx * iovec_len];
            io_sizes_ptr = &io_sizes[ioreq_idx * iovec_len];
            io_bufs_ptr  = &io_bufs[ioreq_idx * iovec_len];

            for (size_t vec_idx = 0; vec_idx < iovec_len; vec_idx++)
                if (io_sizes_ptr[vec_idx] == 0)
                    final_vec_len--;

            if (io_type == IO_TYPE_WRITE) {

                if (H5FD_write_vector(file->sf_file, final_vec_len, io_types_ptr, io_addrs_ptr, io_sizes_ptr,
                                      (const void **)io_bufs_ptr) < 0)
                    HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "write to subfile failed");

                if (H5FD__subfiling_mirror_writes_to_stub(file, final_vec_len, io_types_ptr, io_addrs_ptr,
                                                          io_sizes_ptr, (const void **)io_bufs_ptr) < 0)
                    HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "mirrored write to stub file failed");
            }
            else {
                if (!rank0_bcast || (file->mpi_rank == 0))

                    if (H5FD_read_vector(file->sf_file, final_vec_len, io_types_ptr, io_addrs_ptr,
                                         io_sizes_ptr, (void **)io_bufs_ptr) < 0)
                        HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "read from subfile failed");
            }
        }

        if (rank0_bcast && (file->mpi_size > 1)) {
            size_t size = 0;

            assert(io_type == IO_TYPE_READ);

            extend_sizes = false;
            for (size_t i = 0; i < io_count; i++) {
                if (!extend_sizes) {
                    if (i > 0 && sizes[i] == 0)
                        extend_sizes = true;
                    else
                        size = sizes[i];
                }

                H5_CHECK_OVERFLOW(size, size_t, int);
                if (MPI_SUCCESS != MPI_Bcast(bufs[i].vp, (int)size, MPI_BYTE, 0, file->comm))
                    HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "can't broadcast data from rank 0");
            }
        }
    }

done:

    if (xfer_mode != H5FD_MPIO_INDEPENDENT)
        if (H5CX_set_io_xfer_mode(xfer_mode) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't set I/O collectivity setting");

    H5MM_free(io_bufs);
    H5MM_free(io_sizes);
    H5MM_free(io_addrs);
    H5MM_free(io_types);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_mirror_writes_to_stub(H5FD_subfiling_t *file, uint32_t count, H5FD_mem_t types[],
                                      haddr_t addrs[], size_t sizes[], const void *bufs[])
{
    const void **copied_bufs       = NULL;
    H5FD_mem_t  *copied_types      = NULL;
    haddr_t     *copied_addrs      = NULL;
    size_t      *copied_sizes      = NULL;
    H5FD_mem_t   type              = H5FD_MEM_DEFAULT;
    size_t       io_size           = 0;
    bool         all_super_writes  = true;
    bool         some_super_writes = false;
    uint32_t     super_count       = 0;
    bool         extend_types      = false;
    bool         extend_sizes      = false;
    herr_t       ret_value         = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(file);

    if (file->mpi_rank != 0)
        HGOTO_DONE(SUCCEED);

    if (count == 0)
        HGOTO_DONE(SUCCEED);

    for (size_t i = 0; i < count; i++) {
        if (!extend_types) {
            if (i > 0 && types[i] == H5FD_MEM_NOLIST)
                extend_types = true;
            else
                type = types[i];
        }

        if (type == H5FD_MEM_SUPER) {
            some_super_writes = true;
            super_count++;
        }
        else
            all_super_writes = false;

        if (extend_types) {
            if (type == H5FD_MEM_SUPER)
                super_count += (count - (uint32_t)i) - 1;
            break;
        }
    }

    if (all_super_writes) {
        if (H5FD_write_vector(file->stub_file, count, types, addrs, sizes, bufs) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "couldn't write superblock information to stub file");
    }
    else if (some_super_writes) {
        uint32_t vec_len = 0;

        if (NULL == (copied_types = H5MM_malloc(super_count * sizeof(*copied_types))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate copy of I/O types array");
        if (NULL == (copied_addrs = H5MM_malloc(super_count * sizeof(*copied_addrs))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate copy of I/O addresses array");
        if (NULL == (copied_sizes = H5MM_malloc(super_count * sizeof(*copied_sizes))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate copy of I/O sizes array");
        if (NULL == (copied_bufs = H5MM_malloc(super_count * sizeof(*copied_bufs))))
            HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate copy of I/O buffers array");

        extend_types = false;
        extend_sizes = false;
        for (size_t i = 0; i < count; i++) {
            if (!extend_types) {
                if (i > 0 && types[i] == H5FD_MEM_NOLIST) {
                    extend_types = true;

                    if (type != H5FD_MEM_SUPER)
                        break;
                }
                else
                    type = types[i];
            }

            if (!extend_sizes) {
                if (i > 0 && sizes[i] == 0)
                    extend_sizes = true;
                else
                    io_size = sizes[i];
            }

            if (type != H5FD_MEM_SUPER)
                continue;

            copied_types[vec_len] = type;
            copied_addrs[vec_len] = addrs[i];
            copied_sizes[vec_len] = io_size;
            copied_bufs[vec_len]  = bufs[i];

            vec_len++;
        }
        assert(vec_len > 0);

        if (H5FD_write_vector(file->stub_file, vec_len, copied_types, copied_addrs, copied_sizes,
                              copied_bufs) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "couldn't write superblock information to stub file");
    }

done:
    H5MM_free(copied_bufs);
    H5MM_free(copied_sizes);
    H5MM_free(copied_addrs);
    H5MM_free(copied_types);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_generate_io_vectors(subfiling_context_t *sf_context, size_t in_count, H5FD_mem_t types[],
                                    haddr_t file_offsets[], size_t io_sizes[], H5_flexible_const_ptr_t bufs[],
                                    H5FD_subfiling_io_type_t io_type, size_t *ioreq_count_out,
                                    uint32_t *iovec_len_out, H5FD_mem_t **io_types_out,
                                    haddr_t **io_addrs_out, size_t **io_sizes_out,
                                    H5_flexible_const_ptr_t **io_bufs_out)
{
    H5_flexible_const_ptr_t *loc_io_bufs              = NULL;
    H5FD_mem_t              *loc_io_types             = NULL;
    H5FD_mem_t               mem_type                 = H5FD_MEM_DEFAULT;
    haddr_t                 *loc_io_addrs             = NULL;
    size_t                  *loc_io_sizes             = NULL;
    size_t                   max_iovec_depth          = 0;
    size_t                   max_num_subfiles_touched = 0;
    size_t                   tot_iovec_len            = 0;
    size_t                   io_size                  = 0;
    bool                     extend_sizes             = false;
    bool                     extend_types             = false;
    herr_t                   ret_value                = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(sf_context->sf_stripe_size > 0);
    assert(sf_context->sf_blocksize_per_stripe > 0);
    assert(sf_context->sf_num_subfiles > 0);
    assert(sf_context->topology);
    assert(types || in_count == 0);
    assert(file_offsets || in_count == 0);
    assert(io_sizes || in_count == 0);
    assert(bufs || in_count == 0);
    assert(ioreq_count_out);
    assert(iovec_len_out);
    assert(io_types_out);
    assert(io_addrs_out);
    assert(io_sizes_out);
    assert(io_bufs_out);

    *ioreq_count_out = 0;
    *iovec_len_out   = 0;

    if (in_count == 0)
        HGOTO_DONE(SUCCEED);

    if (H5FD__subfiling_get_iovec_sizes(sf_context, in_count, file_offsets, io_sizes, &max_iovec_depth,
                                        &max_num_subfiles_touched) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't determine maximum I/O request size");

    tot_iovec_len = in_count * max_iovec_depth * max_num_subfiles_touched;

    if (tot_iovec_len == 0)
        HGOTO_DONE(SUCCEED);

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(
        sf_context->sf_context_id,
        "%s: I/O count: %zu, max_iovec_depth = %zu, max_num_subfiles_touched = %zu, iovec_len = %zu",
        __func__, in_count, max_iovec_depth, max_num_subfiles_touched, tot_iovec_len);
#endif

    if (NULL == (loc_io_types = H5MM_calloc(tot_iovec_len * sizeof(*loc_io_types))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate subfile I/O types vector");
    if (NULL == (loc_io_addrs = H5MM_calloc(tot_iovec_len * sizeof(*loc_io_addrs))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate subfile I/O addresses vector");
    if (NULL == (loc_io_sizes = H5MM_calloc(tot_iovec_len * sizeof(*loc_io_sizes))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate subfile I/O sizes vector");
    if (NULL == (loc_io_bufs = H5MM_calloc(tot_iovec_len * sizeof(*loc_io_bufs))))
        HGOTO_ERROR(H5E_VFL, H5E_CANTALLOC, FAIL, "can't allocate subfile I/O buffers vector");

    for (size_t io_idx = 0; io_idx < in_count; io_idx++) {
        size_t iovec_idx;

        iovec_idx = (io_idx * max_iovec_depth * max_num_subfiles_touched);
        assert(iovec_idx < tot_iovec_len);

        if (!extend_types) {
            if (io_idx > 0 && types[io_idx] == H5FD_MEM_NOLIST)
                extend_types = true;
            else
                mem_type = types[io_idx];
        }

        if (!extend_sizes) {
            if (io_idx > 0 && io_sizes[io_idx] == 0)
                extend_sizes = true;
            else
                io_size = io_sizes[io_idx];
        }

        if (H5FD__subfiling_translate_io_req_to_iovec(sf_context, iovec_idx, max_num_subfiles_touched,
                                                      max_iovec_depth, mem_type, file_offsets[io_idx],
                                                      io_size, bufs[io_idx], io_type, loc_io_types,
                                                      loc_io_addrs, loc_io_sizes, loc_io_bufs) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't translate I/O request to I/O vectors");
    }

    *ioreq_count_out = in_count * max_iovec_depth;
    H5_CHECK_OVERFLOW(max_num_subfiles_touched, size_t, uint32_t);
    *iovec_len_out = (uint32_t)max_num_subfiles_touched;
    *io_types_out  = loc_io_types;
    *io_addrs_out  = loc_io_addrs;
    *io_sizes_out  = loc_io_sizes;
    *io_bufs_out   = loc_io_bufs;

done:
    if (ret_value < 0) {
        H5MM_free(loc_io_bufs);
        H5MM_free(loc_io_sizes);
        H5MM_free(loc_io_addrs);
        H5MM_free(loc_io_types);
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_get_iovec_sizes(subfiling_context_t *sf_context, size_t in_count, haddr_t file_offsets[],
                                size_t io_sizes[], size_t *max_iovec_depth, size_t *max_num_subfiles)
{
    int64_t stripe_size          = 0;
    int64_t block_size           = 0;
    size_t  loc_max_iovec_depth  = 0;
    size_t  loc_max_num_subfiles = 0;
    size_t  io_size              = 0;
    bool    extend_sizes         = false;
    int     num_subfiles         = 0;
    herr_t  ret_value            = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(file_offsets);
    assert(io_sizes);
    assert(max_iovec_depth);
    assert(max_num_subfiles);

    stripe_size  = sf_context->sf_stripe_size;
    block_size   = sf_context->sf_blocksize_per_stripe;
    num_subfiles = sf_context->sf_num_subfiles;

    for (size_t io_idx = 0; io_idx < in_count; io_idx++) {
        int64_t stripe_idx;
        int64_t final_stripe_idx;
        int64_t cur_file_offset;
        int64_t final_offset;
        int64_t data_size;
        int64_t first_subfile;
        int64_t last_subfile;
        int64_t row_stripe_idx_start;
        int64_t row_stripe_idx_final;
        int64_t cur_max_num_subfiles;
        size_t  cur_iovec_depth;

        H5_CHECKED_ASSIGN(cur_file_offset, int64_t, file_offsets[io_idx], haddr_t);

        if (!extend_sizes) {
            if (io_idx > 0 && io_sizes[io_idx] == 0)
                extend_sizes = true;
            else
                io_size = io_sizes[io_idx];
        }

        H5_CHECKED_ASSIGN(data_size, int64_t, io_size, size_t);

        if (cur_file_offset < 0)
            HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL,
                        "file offset of %" PRIuHADDR " at index %zu too large; wrapped around",
                        file_offsets[io_idx], io_idx);
        if (data_size < 0)
            HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "I/O size of %zu at index %zu too large; wrapped around",
                        io_size, io_idx);

        stripe_idx   = cur_file_offset / stripe_size;
        final_offset = cur_file_offset + data_size;

        first_subfile = stripe_idx % num_subfiles;

        final_stripe_idx = final_offset / stripe_size;
        last_subfile     = final_stripe_idx % num_subfiles;

        row_stripe_idx_start = stripe_idx - first_subfile;
        row_stripe_idx_final = final_stripe_idx - last_subfile;
        cur_iovec_depth      = (size_t)((row_stripe_idx_final - row_stripe_idx_start) / num_subfiles) + 1;

        if (last_subfile < first_subfile)
            cur_iovec_depth--;

        loc_max_iovec_depth = MAX(cur_iovec_depth, loc_max_iovec_depth);

        if (data_size >= block_size) {

            cur_max_num_subfiles = (int64_t)num_subfiles;
        }
        else if (data_size < stripe_size) {

            cur_max_num_subfiles = 2;
        }
        else {

            cur_max_num_subfiles = (((cur_file_offset % stripe_size) + data_size - 1) / stripe_size) + 1;
        }

        loc_max_num_subfiles = MAX((size_t)cur_max_num_subfiles, loc_max_num_subfiles);
    }

    *max_iovec_depth  = loc_max_iovec_depth;
    *max_num_subfiles = loc_max_num_subfiles;

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_translate_io_req_to_iovec(subfiling_context_t *sf_context, size_t iovec_idx, size_t iovec_len,
                                          size_t iovec_count, H5FD_mem_t type, haddr_t addr, size_t io_size,
                                          H5_flexible_const_ptr_t io_buf, H5FD_subfiling_io_type_t io_type,
                                          H5FD_mem_t *io_types, haddr_t *io_addrs, size_t *io_sizes,
                                          H5_flexible_const_ptr_t *io_bufs)
{
    int64_t stripe_idx           = 0;
    int64_t final_stripe_idx     = 0;
    int64_t stripe_size          = 0;
    int64_t block_size           = 0;
    int64_t file_offset          = 0;
    int64_t offset_in_stripe     = 0;
    int64_t offset_in_block      = 0;
    int64_t final_offset         = 0;
    int64_t start_length         = 0;
    int64_t final_length         = 0;
    int64_t first_subfile_idx    = 0;
    int64_t last_subfile_idx     = 0;
    int64_t start_row            = 0;
    int64_t row_offset           = 0;
    int64_t row_stripe_idx_start = 0;
    int64_t row_stripe_idx_final = 0;
    int64_t max_iovec_depth      = 0;
    int64_t mem_offset           = 0;
    size_t  total_bytes          = 0;
    int     num_subfiles         = 0;
    herr_t  ret_value            = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(io_types);
    assert(io_addrs);
    assert(io_sizes);
    assert(io_bufs);

    stripe_size  = sf_context->sf_stripe_size;
    block_size   = sf_context->sf_blocksize_per_stripe;
    num_subfiles = sf_context->sf_num_subfiles;

    H5_CHECKED_ASSIGN(file_offset, int64_t, addr, haddr_t);
    H5_CHECK_OVERFLOW(io_size, size_t, int64_t);

    stripe_idx       = file_offset / stripe_size;
    offset_in_stripe = file_offset % stripe_size;
    offset_in_block  = file_offset % block_size;
    final_offset     = file_offset + (int64_t)(io_size > 0 ? io_size - 1 : 0);

    start_length = MIN((int64_t)io_size, (stripe_size - offset_in_stripe));
    if (start_length == (int64_t)io_size)
        final_length = 0;
    else if (((final_offset + 1) % stripe_size) == 0)
        final_length = stripe_size;
    else
        final_length = (final_offset + 1) % stripe_size;
    assert(start_length <= stripe_size);
    assert(final_length <= stripe_size);

    start_row         = stripe_idx / num_subfiles;
    first_subfile_idx = stripe_idx % num_subfiles;
    H5_CHECK_OVERFLOW(first_subfile_idx, int64_t, int);

    row_offset = start_row * block_size;

    final_stripe_idx = final_offset / stripe_size;
    last_subfile_idx = final_stripe_idx % num_subfiles;

    row_stripe_idx_start = stripe_idx - first_subfile_idx;
    row_stripe_idx_final = final_stripe_idx - last_subfile_idx;
    max_iovec_depth      = ((row_stripe_idx_final - row_stripe_idx_start) / num_subfiles) + 1;

    if (last_subfile_idx < first_subfile_idx)
        max_iovec_depth--;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(
        sf_context->sf_context_id,
        "%s: TRANSLATING I/O REQUEST (MEMORY TYPE: %d, ADDR: %" PRIuHADDR ", I/O SIZE: %zu, BUF: %p)\n"
        "STRIPE SIZE: %" PRId64 ", BLOCK SIZE: %" PRId64 ", NUM SUBFILES: %d\n"
        "STRIPE IDX: %" PRId64 ", LAST STRIPE IDX: %" PRId64 ", FIRST SUBFILE IDX: %" PRId64
        ", LAST SUBFILE IDX: %" PRId64 "\n"
        "START SEGMENT LENGTH: %" PRId64 ", LAST SEGMENT LENGTH: %" PRId64 ", MAX IOVEC DEPTH: %" PRId64,
        __func__, type, addr, io_size,
        (io_type == IO_TYPE_WRITE) ? (const void *)io_buf.cvp : (void *)io_buf.vp, stripe_size, block_size,
        num_subfiles, stripe_idx, final_stripe_idx, first_subfile_idx, last_subfile_idx, start_length,
        final_length, max_iovec_depth);
#endif

    for (int i = 0, subfile_idx = (int)first_subfile_idx; i < num_subfiles; i++) {
        H5_flexible_const_ptr_t *_io_bufs_ptr;
        H5FD_mem_t              *_io_types_ptr;
        haddr_t                 *_io_addrs_ptr;
        size_t                  *_io_sizes_ptr;
        int64_t                  iovec_depth;
        int64_t                  num_full_stripes;
        int64_t                  subfile_bytes = 0;
        bool                     is_first      = false;
        bool                     is_last       = false;

        if (total_bytes >= io_size)
            break;

        iovec_depth      = max_iovec_depth;
        num_full_stripes = iovec_depth;

        if (subfile_idx == first_subfile_idx) {
            is_first = true;

            if (start_length < stripe_size) {
                subfile_bytes += start_length;
                num_full_stripes--;
            }
        }

        if (subfile_idx == last_subfile_idx) {
            is_last = true;

            if (final_length < stripe_size) {
                subfile_bytes += final_length;
                if (num_full_stripes)
                    num_full_stripes--;
            }
        }

        if (!is_first && !is_last) {
            bool thin_uniform_section = false;

            if (last_subfile_idx >= first_subfile_idx) {

                thin_uniform_section = (subfile_idx > last_subfile_idx) || (subfile_idx < first_subfile_idx);
            }
            else {

                thin_uniform_section =
                    ((last_subfile_idx < subfile_idx) && (subfile_idx < first_subfile_idx));
            }

            if (thin_uniform_section) {
                assert(iovec_depth > 1);
                assert(num_full_stripes > 1);

                iovec_depth--;
                num_full_stripes--;
            }
        }

        subfile_bytes += num_full_stripes * stripe_size;
        total_bytes += (size_t)subfile_bytes;

        _io_types_ptr = &io_types[iovec_idx + (size_t)i];
        _io_addrs_ptr = &io_addrs[iovec_idx + (size_t)i];
        _io_sizes_ptr = &io_sizes[iovec_idx + (size_t)i];
        _io_bufs_ptr  = &io_bufs[iovec_idx + (size_t)i];

        for (size_t vec_idx = 0; vec_idx < iovec_count; vec_idx++)
            *(_io_types_ptr + (vec_idx * iovec_len)) = type;
        *_io_addrs_ptr = (haddr_t)(row_offset + offset_in_block);
        *_io_sizes_ptr = (size_t)subfile_bytes;

        if (io_type == IO_TYPE_WRITE)
            _io_bufs_ptr->cvp = (const char *)(io_buf.cvp) + mem_offset;
        else
            _io_bufs_ptr->vp = (char *)(io_buf.vp) + mem_offset;

        if (num_subfiles > 1) {
            int64_t cur_file_offset = row_offset + offset_in_block;

            assert(iovec_depth <= max_iovec_depth);

            if (is_first) {
                if (is_last) {

                    if (H5FD__subfiling_iovec_fill_first_last(sf_context, iovec_len, iovec_depth,
                                                              subfile_bytes, mem_offset, cur_file_offset,
                                                              start_length, final_length, io_buf, io_type,
                                                              _io_addrs_ptr, _io_sizes_ptr, _io_bufs_ptr) < 0)
                        HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't fill I/O vectors");
                }
                else {

                    if (H5FD__subfiling_iovec_fill_first(
                            sf_context, iovec_len, iovec_depth, subfile_bytes, mem_offset, cur_file_offset,
                            start_length, io_buf, io_type, _io_addrs_ptr, _io_sizes_ptr, _io_bufs_ptr) < 0)
                        HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't fill I/O vectors");
                }

                mem_offset += start_length;
            }
            else if (is_last) {

                if (H5FD__subfiling_iovec_fill_last(sf_context, iovec_len, iovec_depth, subfile_bytes,
                                                    mem_offset, cur_file_offset, final_length, io_buf,
                                                    io_type, _io_addrs_ptr, _io_sizes_ptr, _io_bufs_ptr) < 0)
                    HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't fill I/O vectors");

                mem_offset += stripe_size;
            }
            else {

                if (H5FD__subfiling_iovec_fill_uniform(sf_context, iovec_len, iovec_depth, subfile_bytes,
                                                       mem_offset, cur_file_offset, io_buf, io_type,
                                                       _io_addrs_ptr, _io_sizes_ptr, _io_bufs_ptr) < 0)
                    HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't fill I/O vectors");

                mem_offset += stripe_size;
            }
        }

        offset_in_block += (int64_t)*_io_sizes_ptr;

        subfile_idx++;

        if (subfile_idx == num_subfiles) {
            subfile_idx     = 0;
            offset_in_block = 0;

            row_offset += block_size;
        }

        assert(offset_in_block <= block_size);
    }

    if (total_bytes != io_size)
        HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "total bytes (%zu) didn't match data size (%zu)!",
                    total_bytes, io_size);

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_iovec_fill_first(subfiling_context_t *sf_context, size_t iovec_len, int64_t cur_iovec_depth,
                                 int64_t target_datasize, int64_t start_mem_offset, int64_t start_file_offset,
                                 int64_t first_io_len, H5_flexible_const_ptr_t buf,
                                 H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                 size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr)
{
    int64_t stripe_size;
    int64_t block_size;
    int64_t total_bytes = 0;
    herr_t  ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(cur_iovec_depth > 0);
    assert(io_addrs_ptr);
    assert(io_sizes_ptr);
    assert(io_bufs_ptr);

    stripe_size = sf_context->sf_stripe_size;
    block_size  = sf_context->sf_blocksize_per_stripe;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: start_mem_offset = %" PRId64 ", start_file_offset = %" PRId64
                        ", first_io_len = %" PRId64,
                        __func__, start_mem_offset, start_file_offset, first_io_len);
#endif

    *io_addrs_ptr = (haddr_t)start_file_offset;
    *io_sizes_ptr = (size_t)first_io_len;

    if (io_type == IO_TYPE_WRITE)
        io_bufs_ptr->cvp = (const char *)(buf.cvp) + start_mem_offset;
    else
        io_bufs_ptr->vp = (char *)(buf.vp) + start_mem_offset;

    if (first_io_len == target_datasize)
        HGOTO_DONE(SUCCEED);

    if (first_io_len > 0) {
        int64_t offset_in_stripe = start_file_offset % stripe_size;
        int64_t next_mem_offset  = block_size - offset_in_stripe;
        int64_t next_file_offset = start_file_offset + (block_size - offset_in_stripe);

        total_bytes = first_io_len;

        for (size_t i = 1; i < (size_t)cur_iovec_depth; i++) {
            *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
            *(io_sizes_ptr + (i * iovec_len)) = (size_t)stripe_size;

            if (io_type == IO_TYPE_WRITE)
                (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
            else
                (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
            H5FD__subfiling_log(sf_context->sf_context_id,
                                "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                                ", io_block_len[%zu] = %" PRId64,
                                __func__, i, next_mem_offset, i, next_file_offset, i, stripe_size);
#endif

            next_mem_offset += block_size;
            next_file_offset += block_size;
            total_bytes += stripe_size;
        }

        if (total_bytes != target_datasize)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                        "total bytes (%" PRId64 ") didn't match target data size (%" PRId64 ")!", total_bytes,
                        target_datasize);
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_iovec_fill_last(subfiling_context_t *sf_context, size_t iovec_len, int64_t cur_iovec_depth,
                                int64_t target_datasize, int64_t start_mem_offset, int64_t start_file_offset,
                                int64_t last_io_len, H5_flexible_const_ptr_t buf,
                                H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr, size_t *io_sizes_ptr,
                                H5_flexible_const_ptr_t *io_bufs_ptr)
{
    int64_t stripe_size;
    int64_t block_size;
    int64_t total_bytes = 0;
    int64_t next_mem_offset;
    int64_t next_file_offset;
    size_t  i;
    herr_t  ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(cur_iovec_depth > 0);
    assert(io_addrs_ptr);
    assert(io_sizes_ptr);
    assert(io_bufs_ptr);

    stripe_size = sf_context->sf_stripe_size;
    block_size  = sf_context->sf_blocksize_per_stripe;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: start_mem_offset = %" PRId64 ", start_file_offset = %" PRId64
                        ", last_io_len = %" PRId64,
                        __func__, start_mem_offset, start_file_offset, last_io_len);
#endif

    *io_addrs_ptr = (haddr_t)start_file_offset;
    *io_sizes_ptr = (size_t)last_io_len;

    if (io_type == IO_TYPE_WRITE)
        io_bufs_ptr->cvp = (const char *)(buf.cvp) + start_mem_offset;
    else
        io_bufs_ptr->vp = (char *)(buf.vp) + start_mem_offset;

    if (last_io_len == target_datasize)
        HGOTO_DONE(SUCCEED);

    *io_sizes_ptr = (size_t)stripe_size;

    next_mem_offset  = start_mem_offset + block_size;
    next_file_offset = start_file_offset + block_size;
    total_bytes      = stripe_size;
    for (i = 1; i < (size_t)cur_iovec_depth - 1; i++) {
        *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
        *(io_sizes_ptr + (i * iovec_len)) = (size_t)stripe_size;

        if (io_type == IO_TYPE_WRITE)
            (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
        else
            (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
        H5FD__subfiling_log(sf_context->sf_context_id,
                            "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                            ", io_block_len[%zu] = %" PRId64,
                            __func__, i, next_mem_offset, i, next_file_offset, i, stripe_size);
#endif

        next_mem_offset += block_size;
        next_file_offset += block_size;
        total_bytes += stripe_size;
    }

    *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
    *(io_sizes_ptr + (i * iovec_len)) = (size_t)last_io_len;

    if (io_type == IO_TYPE_WRITE)
        (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
    else
        (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                        ", io_block_len[%zu] = %" PRId64,
                        __func__, i, next_mem_offset, i, next_file_offset, i, last_io_len);
#endif

    total_bytes += last_io_len;

    if (total_bytes != target_datasize)
        HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                    "total bytes (%" PRId64 ") didn't match target data size (%" PRId64 ")!", total_bytes,
                    target_datasize);

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_iovec_fill_first_last(subfiling_context_t *sf_context, size_t iovec_len,
                                      int64_t cur_iovec_depth, int64_t target_datasize,
                                      int64_t start_mem_offset, int64_t start_file_offset,
                                      int64_t first_io_len, int64_t last_io_len, H5_flexible_const_ptr_t buf,
                                      H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                      size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr)
{
    int64_t stripe_size;
    int64_t block_size;
    int64_t total_bytes = 0;
    herr_t  ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(cur_iovec_depth > 0);
    assert(io_addrs_ptr);
    assert(io_sizes_ptr);
    assert(io_bufs_ptr);

    stripe_size = sf_context->sf_stripe_size;
    block_size  = sf_context->sf_blocksize_per_stripe;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: start_mem_offset = %" PRId64 ", start_file_offset = %" PRId64
                        ", first_io_len = %" PRId64 ", last_io_len = %" PRId64,
                        __func__, start_mem_offset, start_file_offset, first_io_len, last_io_len);
#endif

    *io_addrs_ptr = (haddr_t)start_file_offset;
    *io_sizes_ptr = (size_t)first_io_len;

    if (io_type == IO_TYPE_WRITE)
        io_bufs_ptr->cvp = (const char *)(buf.cvp) + start_mem_offset;
    else
        io_bufs_ptr->vp = (char *)(buf.vp) + start_mem_offset;

    if (first_io_len == target_datasize)
        HGOTO_DONE(SUCCEED);

    if (first_io_len > 0) {
        int64_t offset_in_stripe = start_file_offset % stripe_size;
        int64_t next_mem_offset  = block_size - offset_in_stripe;
        int64_t next_file_offset = start_file_offset + (block_size - offset_in_stripe);
        size_t  i;

        total_bytes = first_io_len;

        for (i = 1; i < (size_t)cur_iovec_depth - 1; i++) {
            *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
            *(io_sizes_ptr + (i * iovec_len)) = (size_t)stripe_size;

            if (io_type == IO_TYPE_WRITE)
                (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
            else
                (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
            H5FD__subfiling_log(sf_context->sf_context_id,
                                "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                                ", io_block_len[%zu] = %" PRId64,
                                __func__, i, next_mem_offset, i, next_file_offset, i, stripe_size);
#endif

            next_mem_offset += block_size;
            next_file_offset += block_size;
            total_bytes += stripe_size;
        }

        *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
        *(io_sizes_ptr + (i * iovec_len)) = (size_t)last_io_len;

        if (io_type == IO_TYPE_WRITE)
            (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
        else
            (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
        H5FD__subfiling_log(sf_context->sf_context_id,
                            "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                            ", io_block_len[%zu] = %" PRId64,
                            __func__, i, next_mem_offset, i, next_file_offset, i, last_io_len);
#endif

        total_bytes += last_io_len;

        if (total_bytes != target_datasize)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                        "total bytes (%" PRId64 ") didn't match target data size (%" PRId64 ")!", total_bytes,
                        target_datasize);
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__subfiling_iovec_fill_uniform(subfiling_context_t *sf_context, size_t iovec_len, int64_t cur_iovec_depth,
                                   int64_t target_datasize, int64_t start_mem_offset,
                                   int64_t start_file_offset, H5_flexible_const_ptr_t buf,
                                   H5FD_subfiling_io_type_t io_type, haddr_t *io_addrs_ptr,
                                   size_t *io_sizes_ptr, H5_flexible_const_ptr_t *io_bufs_ptr)
{
    int64_t stripe_size;
    int64_t block_size;
    int64_t total_bytes = 0;
    herr_t  ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(sf_context);
    assert(cur_iovec_depth > 0 || target_datasize == 0);
    assert(io_addrs_ptr);
    assert(io_sizes_ptr);
    assert(io_bufs_ptr);

    stripe_size = sf_context->sf_stripe_size;
    block_size  = sf_context->sf_blocksize_per_stripe;

#ifdef H5_SUBFILING_DEBUG
    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: start_mem_offset = %" PRId64 ", start_file_offset = %" PRId64
                        ", segment size = %" PRId64,
                        __func__, start_mem_offset, start_file_offset, stripe_size);
#endif

    *io_addrs_ptr = (haddr_t)start_file_offset;
    *io_sizes_ptr = (size_t)stripe_size;

    if (io_type == IO_TYPE_WRITE)
        io_bufs_ptr->cvp = (const char *)(buf.cvp) + start_mem_offset;
    else
        io_bufs_ptr->vp = (char *)(buf.vp) + start_mem_offset;

    if (target_datasize == 0) {
#ifdef H5_SUBFILING_DEBUG
        H5FD__subfiling_log(sf_context->sf_context_id, "%s: target_datasize = 0", __func__);
#endif

        *io_sizes_ptr = (size_t)0;
        HGOTO_DONE(SUCCEED);
    }

    if (target_datasize > stripe_size) {
        int64_t next_mem_offset  = start_mem_offset + block_size;
        int64_t next_file_offset = start_file_offset + block_size;

        total_bytes = stripe_size;

        for (size_t i = 1; i < (size_t)cur_iovec_depth; i++) {
            *(io_addrs_ptr + (i * iovec_len)) = (haddr_t)next_file_offset;
            *(io_sizes_ptr + (i * iovec_len)) = (size_t)stripe_size;

            if (io_type == IO_TYPE_WRITE)
                (io_bufs_ptr + (i * iovec_len))->cvp = (const char *)(buf.cvp) + next_mem_offset;
            else
                (io_bufs_ptr + (i * iovec_len))->vp = (char *)(buf.vp) + next_mem_offset;

#ifdef H5_SUBFILING_DEBUG
            H5FD__subfiling_log(sf_context->sf_context_id,
                                "%s: mem_offset[%zu] = %" PRId64 ", file_offset[%zu] = %" PRId64
                                ", io_block_len[%zu] = %" PRId64,
                                __func__, i, next_mem_offset, i, next_file_offset, i, stripe_size);
#endif

            next_mem_offset += block_size;
            next_file_offset += block_size;
            total_bytes += stripe_size;
        }

        if (total_bytes != target_datasize)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL,
                        "total bytes (%" PRId64 ") didn't match target data size (%" PRId64 ")!", total_bytes,
                        target_datasize);
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

#ifdef H5_SUBFILING_DEBUG
static void
H5_subfiling_dump_iovecs(subfiling_context_t *sf_context, size_t ioreq_count, size_t iovec_len,
                         H5FD_subfiling_io_type_t io_type, H5FD_mem_t *io_types, haddr_t *io_addrs,
                         size_t *io_sizes, H5_flexible_const_ptr_t *io_bufs)
{
    FUNC_ENTER_PACKAGE_NOERR

    assert(sf_context);
    assert(io_types);
    assert(io_addrs);
    assert(io_sizes);
    assert(io_bufs);

    H5FD__subfiling_log(sf_context->sf_context_id,
                        "%s: I/O REQUEST VECTORS (mem type, addr, size, buf):", __func__);

    for (size_t ioreq_idx = 0; ioreq_idx < ioreq_count; ioreq_idx++) {
        H5FD__subfiling_log_nonewline(sf_context->sf_context_id, "  -> I/O REQUEST %zu: ", ioreq_idx);

        H5FD__subfiling_log_nonewline(sf_context->sf_context_id, "[");
        for (size_t i = 0; i < iovec_len; i++) {
            if (i > 0)
                H5FD__subfiling_log_nonewline(sf_context->sf_context_id, ", ");

            H5FD__subfiling_log_nonewline(
                sf_context->sf_context_id, "(%d, %" PRIuHADDR ", %zu, %p)",
                *(io_types + (ioreq_idx * iovec_len) + i), *(io_addrs + (ioreq_idx * iovec_len) + i),
                *(io_sizes + (ioreq_idx * iovec_len) + i),
                (io_type == IO_TYPE_WRITE) ? (const void *)(io_bufs + (ioreq_idx * iovec_len) + i)->cvp
                                           : (void *)(io_bufs + (ioreq_idx * iovec_len) + i)->vp);
        }
        H5FD__subfiling_log_nonewline(sf_context->sf_context_id, "]\n");
    }

    FUNC_LEAVE_NOAPI_VOID
}
#endif
