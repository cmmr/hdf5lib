/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5FDmodule.h" 

#include "H5private.h"   
#include "H5Eprivate.h"  
#include "H5Fprivate.h"  
#include "H5FDdirect.h"  
#include "H5FDpkg.h"     
#include "H5FLprivate.h" 
#include "H5Iprivate.h"  
#include "H5MMprivate.h" 
#include "H5Pprivate.h"  

#ifdef H5_HAVE_DIRECT

hid_t H5FD_DIRECT_id_g = H5I_INVALID_HID;

#define OP_UNKNOWN 0
#define OP_READ    1
#define OP_WRITE   2

typedef struct H5FD_direct_fapl_t {
    size_t mboundary;  
    size_t fbsize;     
    size_t cbsize;     
    bool   must_align; 
} H5FD_direct_fapl_t;

typedef struct H5FD_direct_t {
    H5FD_t             pub; 
    int                fd;  
    haddr_t            eoa; 
    haddr_t            eof; 
    haddr_t            pos; 
    int                op;  
    H5FD_direct_fapl_t fa;  
    bool               ignore_disabled_file_locks;
#ifndef H5_HAVE_WIN32_API
    
    dev_t device; 
    ino_t inode;  
#else
    
    DWORD fileindexlo;
    DWORD fileindexhi;
#endif

} H5FD_direct_t;

static herr_t  H5FD__direct_populate_config(size_t boundary, size_t block_size, size_t cbuf_size,
                                            H5FD_direct_fapl_t *fa_out);
static void   *H5FD__direct_fapl_get(H5FD_t *file);
static void   *H5FD__direct_fapl_copy(const void *_old_fa);
static H5FD_t *H5FD__direct_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t maxaddr);
static herr_t  H5FD__direct_close(H5FD_t *_file);
static int     H5FD__direct_cmp(const H5FD_t *_f1, const H5FD_t *_f2);
static herr_t  H5FD__direct_query(const H5FD_t *_f1, unsigned long *flags);
static haddr_t H5FD__direct_get_eoa(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__direct_set_eoa(H5FD_t *_file, H5FD_mem_t type, haddr_t addr);
static haddr_t H5FD__direct_get_eof(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__direct_get_handle(H5FD_t *_file, hid_t fapl, void **file_handle);
static herr_t  H5FD__direct_read(H5FD_t *_file, H5FD_mem_t type, hid_t fapl_id, haddr_t addr, size_t size,
                                 void *buf);
static herr_t  H5FD__direct_write(H5FD_t *_file, H5FD_mem_t type, hid_t fapl_id, haddr_t addr, size_t size,
                                  const void *buf);
static herr_t  H5FD__direct_truncate(H5FD_t *_file, hid_t dxpl_id, bool closing);
static herr_t  H5FD__direct_lock(H5FD_t *_file, bool rw);
static herr_t  H5FD__direct_unlock(H5FD_t *_file);
static herr_t  H5FD__direct_delete(const char *filename, hid_t fapl_id);

static const H5FD_class_t H5FD_direct_g = {
    H5FD_CLASS_VERSION,         
    H5FD_DIRECT_VALUE,          
    "direct",                   
    H5FD_MAXADDR,               
    H5F_CLOSE_WEAK,             
    NULL,                       
    NULL,                       
    NULL,                       
    NULL,                       
    sizeof(H5FD_direct_fapl_t), 
    H5FD__direct_fapl_get,      
    H5FD__direct_fapl_copy,     
    NULL,                       
    0,                          
    NULL,                       
    NULL,                       
    H5FD__direct_open,          
    H5FD__direct_close,         
    H5FD__direct_cmp,           
    H5FD__direct_query,         
    NULL,                       
    NULL,                       
    NULL,                       
    H5FD__direct_get_eoa,       
    H5FD__direct_set_eoa,       
    H5FD__direct_get_eof,       
    H5FD__direct_get_handle,    
    H5FD__direct_read,          
    H5FD__direct_write,         
    NULL,                       
    NULL,                       
    NULL,                       
    NULL,                       
    NULL,                       
    H5FD__direct_truncate,      
    H5FD__direct_lock,          
    H5FD__direct_unlock,        
    H5FD__direct_delete,        
    NULL,                       
    H5FD_FLMAP_DICHOTOMY        
};

H5FL_DEFINE_STATIC(H5FD_direct_t);

herr_t
H5FD__direct_register(void)
{
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    if (H5I_VFL != H5I_get_type(H5FD_DIRECT_id_g))
        if ((H5FD_DIRECT_id_g = H5FD_register(&H5FD_direct_g, sizeof(H5FD_class_t), false)) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTREGISTER, FAIL, "unable to register direct driver");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5FD__direct_unregister(void)
{
    FUNC_ENTER_PACKAGE_NOERR

    
    H5FD_DIRECT_id_g = H5I_INVALID_HID;

    FUNC_LEAVE_NOAPI(SUCCEED)
} 

herr_t
H5Pset_fapl_direct(hid_t fapl_id, size_t boundary, size_t block_size, size_t cbuf_size)
{
    H5P_genplist_t    *plist; 
    H5FD_direct_fapl_t fa;
    herr_t             ret_value;

    FUNC_ENTER_API(FAIL)

    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, false)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");

    if (H5FD__direct_populate_config(boundary, block_size, cbuf_size, &fa) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTSET, FAIL, "can't initialize driver configuration info");

    ret_value = H5P_set_driver(plist, H5FD_DIRECT, &fa, NULL);

done:
    FUNC_LEAVE_API(ret_value)
}

herr_t
H5Pget_fapl_direct(hid_t fapl_id, size_t *boundary , size_t *block_size ,
                   size_t *cbuf_size )
{
    H5P_genplist_t           *plist; 
    const H5FD_direct_fapl_t *fa;
    herr_t                    ret_value = SUCCEED; 

    FUNC_ENTER_API(FAIL)

    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access list");
    if (H5FD_DIRECT != H5P_peek_driver(plist))
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "incorrect VFL driver");
    if (NULL == (fa = H5P_peek_driver_info(plist)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "bad VFL driver info");
    if (boundary)
        *boundary = fa->mboundary;
    if (block_size)
        *block_size = fa->fbsize;
    if (cbuf_size)
        *cbuf_size = fa->cbsize;

done:
    FUNC_LEAVE_API(ret_value)
} 

static herr_t
H5FD__direct_populate_config(size_t boundary, size_t block_size, size_t cbuf_size, H5FD_direct_fapl_t *fa_out)
{
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(fa_out);

    memset(fa_out, 0, sizeof(H5FD_direct_fapl_t));

    if (boundary != 0)
        fa_out->mboundary = boundary;
    else
        fa_out->mboundary = MBOUNDARY_DEF;

    if (block_size != 0)
        fa_out->fbsize = block_size;
    else
        fa_out->fbsize = FBSIZE_DEF;

    if (cbuf_size != 0)
        fa_out->cbsize = cbuf_size;
    else
        fa_out->cbsize = CBSIZE_DEF;

    
    fa_out->must_align = true;

    
    if (fa_out->cbsize % fa_out->fbsize != 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "copy buffer size must be a multiple of block size");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static void *
H5FD__direct_fapl_get(H5FD_t *_file)
{
    H5FD_direct_t *file      = (H5FD_direct_t *)_file;
    void          *ret_value = NULL; 

    FUNC_ENTER_PACKAGE_NOERR

    
    ret_value = H5FD__direct_fapl_copy(&(file->fa));

    FUNC_LEAVE_NOAPI(ret_value)
} 

static void *
H5FD__direct_fapl_copy(const void *_old_fa)
{
    const H5FD_direct_fapl_t *old_fa = (const H5FD_direct_fapl_t *)_old_fa;
    H5FD_direct_fapl_t       *new_fa = H5MM_calloc(sizeof(H5FD_direct_fapl_t));

    FUNC_ENTER_PACKAGE_NOERR

    assert(new_fa);

    
    H5MM_memcpy(new_fa, old_fa, sizeof(H5FD_direct_fapl_t));

    FUNC_LEAVE_NOAPI(new_fa)
} 

static H5FD_t *
H5FD__direct_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t maxaddr)
{
    int                       o_flags;
    int                       fd   = (-1);
    H5FD_direct_t            *file = NULL;
    const H5FD_direct_fapl_t *fa;
    H5FD_direct_fapl_t        default_fa = {0};
#ifdef H5_HAVE_WIN32_API
    HFILE                              filehandle;
    struct _BY_HANDLE_FILE_INFORMATION fileinfo;
#endif
    h5_stat_t       sb;
    H5P_genplist_t *plist; 
    void           *buf1, *buf2;
    H5FD_t         *ret_value = NULL;

    FUNC_ENTER_PACKAGE

    
    assert(sizeof(HDoff_t) >= sizeof(size_t));

    
    if (!name || !*name)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "invalid file name");
    if (0 == maxaddr || HADDR_UNDEF == maxaddr)
        HGOTO_ERROR(H5E_ARGS, H5E_BADRANGE, NULL, "bogus maxaddr");
    if (H5FD_ADDR_OVERFLOW(maxaddr))
        HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, NULL, "bogus maxaddr");

    
    o_flags = (H5F_ACC_RDWR & flags) ? O_RDWR : O_RDONLY;
    if (H5F_ACC_TRUNC & flags)
        o_flags |= O_TRUNC;
    if (H5F_ACC_CREAT & flags)
        o_flags |= O_CREAT;
    if (H5F_ACC_EXCL & flags)
        o_flags |= O_EXCL;

    
    o_flags |= O_DIRECT;

    
    if ((fd = HDopen(name, o_flags, H5_POSIX_CREATE_MODE_RW)) < 0)
        HSYS_GOTO_ERROR(H5E_FILE, H5E_CANTOPENFILE, NULL, "unable to open file");

    memset(&sb, 0, sizeof(h5_stat_t));
    if (HDfstat(fd, &sb) < 0)
        HSYS_GOTO_ERROR(H5E_FILE, H5E_BADFILE, NULL, "unable to fstat file");

    
    if (NULL == (file = H5FL_CALLOC(H5FD_direct_t)))
        HGOTO_ERROR(H5E_RESOURCE, H5E_NOSPACE, NULL, "unable to allocate file struct");

    
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "not a file access property list");
    if (NULL == (fa = (const H5FD_direct_fapl_t *)H5P_peek_driver_info(plist))) {
        if (H5FD__direct_populate_config(0, 0, 0, &default_fa) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, NULL, "can't initialize driver configuration info");
        fa = &default_fa;
    }

    file->fd = fd;
    H5_CHECKED_ASSIGN(file->eof, haddr_t, sb.st_size, h5_stat_size_t);
    file->pos = HADDR_UNDEF;
    file->op  = OP_UNKNOWN;
#ifdef H5_HAVE_WIN32_API
    filehandle = _get_osfhandle(fd);
    (void)GetFileInformationByHandle((HANDLE)filehandle, &fileinfo);
    file->fileindexhi = fileinfo.nFileIndexHigh;
    file->fileindexlo = fileinfo.nFileIndexLow;
#else
    file->device = sb.st_dev;
    file->inode  = sb.st_ino;
#endif 
    file->fa.mboundary = fa->mboundary;
    file->fa.fbsize    = fa->fbsize;
    file->fa.cbsize    = fa->cbsize;

    
    if (H5FD_ignore_disabled_file_locks_p != FAIL)
        
        file->ignore_disabled_file_locks = H5FD_ignore_disabled_file_locks_p;
    else {
        
        if (H5P_get(plist, H5F_ACS_IGNORE_DISABLED_FILE_LOCKS_NAME, &file->ignore_disabled_file_locks) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get ignore disabled file locks property");
    }

    
    
    buf1 = malloc(sizeof(int));
    if (posix_memalign(&buf2, file->fa.mboundary, file->fa.fbsize) != 0)
        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "posix_memalign failed");

    if (o_flags & O_CREAT) {
        if (HDwrite(file->fd, buf1, sizeof(int)) < 0) {
            if (HDwrite(file->fd, buf2, file->fa.fbsize) < 0)
                HGOTO_ERROR(H5E_FILE, H5E_WRITEERROR, NULL, "file system may not support Direct I/O");
            else
                file->fa.must_align = true;
        }
        else {
            file->fa.must_align = false;
            if (-1 == HDftruncate(file->fd, 0))
                HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, NULL, "unable to truncate file");
        }
    }
    else {
        if (HDread(file->fd, buf1, sizeof(int)) < 0) {
            if (HDread(file->fd, buf2, file->fa.fbsize) < 0)
                HGOTO_ERROR(H5E_FILE, H5E_READERROR, NULL, "file system may not support Direct I/O");
            else
                file->fa.must_align = true;
        }
        else {
            if (o_flags & O_RDWR) {
                if (HDlseek(file->fd, 0, SEEK_SET) < 0)
                    HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, NULL, "unable to seek to proper position");
                if (HDwrite(file->fd, buf1, sizeof(int)) < 0)
                    file->fa.must_align = true;
                else
                    file->fa.must_align = false;
            }
            else
                file->fa.must_align = false;
        }
    }

    if (buf1)
        free(buf1);
    if (buf2)
        free(buf2);

    
    ret_value = (H5FD_t *)file;

done:
    if (ret_value == NULL) {
        if (fd >= 0)
            HDclose(fd);
    } 

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__direct_close(H5FD_t *_file)
{
    H5FD_direct_t *file      = (H5FD_direct_t *)_file;
    herr_t         ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    if (HDclose(file->fd) < 0)
        HSYS_GOTO_ERROR(H5E_IO, H5E_CANTCLOSEFILE, FAIL, "unable to close file");

    H5FL_FREE(H5FD_direct_t, file);

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static int
H5FD__direct_cmp(const H5FD_t *_f1, const H5FD_t *_f2)
{
    const H5FD_direct_t *f1        = (const H5FD_direct_t *)_f1;
    const H5FD_direct_t *f2        = (const H5FD_direct_t *)_f2;
    int                  ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

#ifdef H5_HAVE_WIN32_API
    if (f1->fileindexhi < f2->fileindexhi)
        HGOTO_DONE(-1);
    if (f1->fileindexhi > f2->fileindexhi)
        HGOTO_DONE(1);

    if (f1->fileindexlo < f2->fileindexlo)
        HGOTO_DONE(-1);
    if (f1->fileindexlo > f2->fileindexlo)
        HGOTO_DONE(1);

#else
    if (f1->device < f2->device)
        HGOTO_DONE(-1);
    if (f1->device > f2->device)
        HGOTO_DONE(1);

    if (f1->inode < f2->inode)
        HGOTO_DONE(-1);
    if (f1->inode > f2->inode)
        HGOTO_DONE(1);

#endif

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__direct_query(const H5FD_t H5_ATTR_UNUSED *_f, unsigned long *flags )
{
    FUNC_ENTER_PACKAGE_NOERR

    
    if (flags) {
        *flags = 0;
        *flags |= H5FD_FEAT_AGGREGATE_METADATA;  
        *flags |= H5FD_FEAT_ACCUMULATE_METADATA; 
        *flags |= H5FD_FEAT_DATA_SIEVE; 
        *flags |= H5FD_FEAT_AGGREGATE_SMALLDATA;    
        *flags |= H5FD_FEAT_DEFAULT_VFD_COMPATIBLE; 
    }

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static haddr_t
H5FD__direct_get_eoa(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_direct_t *file = (const H5FD_direct_t *)_file;

    FUNC_ENTER_PACKAGE_NOERR

    FUNC_LEAVE_NOAPI(file->eoa)
}

static herr_t
H5FD__direct_set_eoa(H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type, haddr_t addr)
{
    H5FD_direct_t *file = (H5FD_direct_t *)_file;

    FUNC_ENTER_PACKAGE_NOERR

    file->eoa = addr;

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static haddr_t
H5FD__direct_get_eof(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_direct_t *file = (const H5FD_direct_t *)_file;

    FUNC_ENTER_PACKAGE_NOERR

    FUNC_LEAVE_NOAPI(file->eof)
}

static herr_t
H5FD__direct_get_handle(H5FD_t *_file, hid_t H5_ATTR_UNUSED fapl, void **file_handle)
{
    H5FD_direct_t *file      = (H5FD_direct_t *)_file;
    herr_t         ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    if (!file_handle)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "file handle not valid");
    *file_handle = &(file->fd);

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__direct_read(H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr,
                  size_t size, void *buf )
{
    H5FD_direct_t *file = (H5FD_direct_t *)_file;
    ssize_t        nbytes;
    bool           _must_align = true;
    herr_t         ret_value   = SUCCEED; 
    size_t         alloc_size;
    void          *copy_buf = NULL, *p2;
    size_t         _boundary;
    size_t         _fbsize;
    size_t         _cbsize;
    haddr_t        read_size;        
    size_t         copy_size = size; 
    size_t         copy_offset;      

    FUNC_ENTER_PACKAGE

    assert(file && file->pub.cls);
    assert(buf);

    
    if (HADDR_UNDEF == addr)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "addr undefined");
    if (H5FD_REGION_OVERFLOW(addr, size))
        HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, FAIL, "addr overflow");

    
    _must_align = file->fa.must_align;

    
    _boundary = file->fa.mboundary;
    _fbsize   = file->fa.fbsize;
    _cbsize   = file->fa.cbsize;

    
    if (!_must_align || ((addr % _fbsize == 0) && (size % _fbsize == 0) && ((size_t)buf % _boundary == 0))) {
        
        if ((addr != file->pos || OP_READ != file->op) && HDlseek(file->fd, (HDoff_t)addr, SEEK_SET) < 0)
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");
        
        while (size > 0) {
            do {
                nbytes = HDread(file->fd, buf, size);
            } while (-1 == nbytes && EINTR == errno);
            if (-1 == nbytes) 
                HSYS_GOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
            if (0 == nbytes) {
                
                memset(buf, 0, size);
                break;
            }
            assert(nbytes >= 0);
            assert((size_t)nbytes <= size);
            H5_CHECK_OVERFLOW(nbytes, ssize_t, size_t);
            size -= (size_t)nbytes;
            H5_CHECK_OVERFLOW(nbytes, ssize_t, haddr_t);
            addr += (haddr_t)nbytes;
            buf = (char *)buf + nbytes;
        }
    }
    else {
        
        copy_offset = (size_t)(addr % _fbsize);

        
        alloc_size = ((copy_offset + size - 1) / _fbsize + 1) * _fbsize;
        if (alloc_size > _cbsize)
            alloc_size = _cbsize;
        assert(!(alloc_size % _fbsize));
        if (posix_memalign(&copy_buf, _boundary, alloc_size) != 0)
            HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "posix_memalign failed");

        
        assert(!(((addr / _fbsize) * _fbsize) % _fbsize));
        if (HDlseek(file->fd, (HDoff_t)((addr / _fbsize) * _fbsize), SEEK_SET) < 0)
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");

        
        do {
            
            memset(copy_buf, 0, alloc_size);

            
            if ((copy_size + copy_offset) < alloc_size)
                read_size = ((copy_size + copy_offset - 1) / _fbsize + 1) * _fbsize;
            else
                read_size = alloc_size;

            assert(!(read_size % _fbsize));
            do {
                nbytes = HDread(file->fd, copy_buf, read_size);
            } while (-1 == nbytes && EINTR == errno);

            if (-1 == nbytes) 
                HSYS_GOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");

            
            p2 = (unsigned char *)copy_buf + copy_offset;
            if ((copy_size + copy_offset) <= alloc_size) {
                H5MM_memcpy(buf, p2, copy_size);
                buf       = (unsigned char *)buf + copy_size;
                copy_size = 0;
            } 
            else {
                H5MM_memcpy(buf, p2, alloc_size - copy_offset);
                buf = (unsigned char *)buf + alloc_size - copy_offset;
                copy_size -= alloc_size - copy_offset;
                copy_offset = 0;
            } 
        } while (copy_size > 0);

        
        addr = (haddr_t)(((addr + size - 1) / _fbsize + 1) * _fbsize);

        if (copy_buf) {
            
            free(copy_buf);
            copy_buf = NULL;
        } 
    }

    
    file->pos = addr;
    file->op  = OP_READ;

done:
    if (ret_value < 0) {
        
        if (copy_buf)
            free(copy_buf);

        
        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;
    } 

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__direct_write(H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr,
                   size_t size, const void *buf)
{
    H5FD_direct_t *file = (H5FD_direct_t *)_file;
    ssize_t        nbytes;
    bool           _must_align = true;
    herr_t         ret_value   = SUCCEED; 
    size_t         alloc_size;
    void          *copy_buf = NULL, *p1;
    const void    *p3;
    size_t         _boundary;
    size_t         _fbsize;
    size_t         _cbsize;
    haddr_t        write_addr;       
    haddr_t        write_size;       
    haddr_t        read_size;        
    size_t         copy_size = size; 
    size_t         copy_offset;      

    FUNC_ENTER_PACKAGE

    assert(file && file->pub.cls);
    assert(buf);

    
    if (HADDR_UNDEF == addr)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "addr undefined");
    if (H5FD_REGION_OVERFLOW(addr, size))
        HGOTO_ERROR(H5E_ARGS, H5E_OVERFLOW, FAIL, "addr overflow");

    
    _must_align = file->fa.must_align;

    
    _boundary = file->fa.mboundary;
    _fbsize   = file->fa.fbsize;
    _cbsize   = file->fa.cbsize;

    
    if (!_must_align || ((addr % _fbsize == 0) && (size % _fbsize == 0) && ((size_t)buf % _boundary == 0))) {
        
        if ((addr != file->pos || OP_WRITE != file->op) && HDlseek(file->fd, (HDoff_t)addr, SEEK_SET) < 0)
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");

        while (size > 0) {
            do {
                nbytes = HDwrite(file->fd, buf, size);
            } while (-1 == nbytes && EINTR == errno);
            if (-1 == nbytes) 
                HSYS_GOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "file write failed");
            assert(nbytes > 0);
            assert((size_t)nbytes <= size);
            H5_CHECK_OVERFLOW(nbytes, ssize_t, size_t);
            size -= (size_t)nbytes;
            H5_CHECK_OVERFLOW(nbytes, ssize_t, haddr_t);
            addr += (haddr_t)nbytes;
            buf = (const char *)buf + nbytes;
        }
    }
    else {
        
        write_addr  = (addr / _fbsize) * _fbsize;
        copy_offset = (size_t)(addr % _fbsize);

        
        alloc_size = ((copy_offset + size - 1) / _fbsize + 1) * _fbsize;
        if (alloc_size > _cbsize)
            alloc_size = _cbsize;
        assert(!(alloc_size % _fbsize));

        if (posix_memalign(&copy_buf, _boundary, alloc_size) != 0)
            HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "posix_memalign failed");

        
        if (HDlseek(file->fd, (HDoff_t)write_addr, SEEK_SET) < 0)
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");

        p3 = buf;
        do {
            
            if ((copy_size + copy_offset) < alloc_size)
                write_size = ((copy_size + copy_offset - 1) / _fbsize + 1) * _fbsize;
            else
                write_size = alloc_size;

            
            memset(copy_buf, 0, _fbsize);

            if (copy_offset > 0) {
                if ((write_addr + write_size) > (addr + size)) {
                    assert((write_addr + write_size) - (addr + size) < _fbsize);
                    read_size = write_size;
                    p1        = copy_buf;
                } 
                else {
                    read_size = _fbsize;
                    p1        = copy_buf;
                } 
            }     
            else if ((write_addr + write_size) > (addr + size)) {
                assert((write_addr + write_size) - (addr + size) < _fbsize);
                read_size = _fbsize;
                p1        = (unsigned char *)copy_buf + write_size - _fbsize;

                
                assert(!((write_addr + write_size - _fbsize) % _fbsize));
                if (HDlseek(file->fd, (HDoff_t)(write_addr + write_size - _fbsize), SEEK_SET) < 0)
                    HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");
            } 
            else
                p1 = NULL;

            if (p1) {
                assert(!(read_size % _fbsize));
                do {
                    nbytes = HDread(file->fd, p1, read_size);
                } while (-1 == nbytes && EINTR == errno);

                if (-1 == nbytes) 
                    HSYS_GOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
            } 

            
            p1 = (unsigned char *)copy_buf + copy_offset;
            if ((copy_size + copy_offset) <= alloc_size) {
                H5MM_memcpy(p1, p3, copy_size);
                copy_size = 0;
            } 
            else {
                H5MM_memcpy(p1, p3, alloc_size - copy_offset);
                p3 = (const unsigned char *)p3 + (alloc_size - copy_offset);
                copy_size -= alloc_size - copy_offset;
                copy_offset = 0;
            } 

            
            assert(!(write_addr % _fbsize));
            if (HDlseek(file->fd, (HDoff_t)write_addr, SEEK_SET) < 0)
                HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to seek to proper position");

            
            assert(!(write_size % _fbsize));
            do {
                nbytes = HDwrite(file->fd, copy_buf, write_size);
            } while (-1 == nbytes && EINTR == errno);

            if (-1 == nbytes) 
                HSYS_GOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "file write failed");

            
            write_addr += write_size;
        } while (copy_size > 0);

        
        addr = write_addr;
        buf  = (const char *)buf + size;

        if (copy_buf) {
            
            free(copy_buf);
            copy_buf = NULL;
        } 
    }

    
    file->pos = addr;
    file->op  = OP_WRITE;
    if (file->pos > file->eof)
        file->eof = file->pos;

done:
    if (ret_value < 0) {
        
        if (copy_buf)
            free(copy_buf);

        
        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;
    } 

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5FD__direct_truncate(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, bool H5_ATTR_UNUSED closing)
{
    H5FD_direct_t *file      = (H5FD_direct_t *)_file;
    herr_t         ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    assert(file);

    
    if (file->eoa != file->eof) {
#ifdef H5_HAVE_WIN32_API
        HFILE         filehandle; 
        LARGE_INTEGER li;         

        
        filehandle = _get_osfhandle(file->fd);

        
        
        li.QuadPart = (LONGLONG)file->eoa;
        (void)SetFilePointer((HANDLE)filehandle, li.LowPart, &li.HighPart, FILE_BEGIN);
        if (SetEndOfFile((HANDLE)filehandle) == 0)
            HGOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to extend file properly");
#else  
        if (-1 == HDftruncate(file->fd, (HDoff_t)file->eoa))
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to extend file properly");
#endif 

        
        file->eof = file->eoa;

        
        file->pos = HADDR_UNDEF;
        file->op  = OP_UNKNOWN;
    }
    else if (file->fa.must_align) {
        
        if (-1 == HDftruncate(file->fd, (HDoff_t)file->eof))
            HSYS_GOTO_ERROR(H5E_IO, H5E_SEEKERROR, FAIL, "unable to extend file properly");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5FD__direct_lock(H5FD_t *_file, bool rw)
{
    H5FD_direct_t *file = (H5FD_direct_t *)_file; 
    int            lock_flags;                    
    herr_t         ret_value = SUCCEED;           

    FUNC_ENTER_PACKAGE

    assert(file);

    
    lock_flags = rw ? LOCK_EX : LOCK_SH;

    
    if (HDflock(file->fd, lock_flags | LOCK_NB) < 0) {
        if (file->ignore_disabled_file_locks && ENOSYS == errno) {
            
            errno = 0;
        }
        else
            HSYS_GOTO_ERROR(H5E_VFL, H5E_CANTLOCKFILE, FAIL, "unable to lock file");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5FD__direct_unlock(H5FD_t *_file)
{
    H5FD_direct_t *file      = (H5FD_direct_t *)_file; 
    herr_t         ret_value = SUCCEED;                

    FUNC_ENTER_PACKAGE

    assert(file);

    if (HDflock(file->fd, LOCK_UN) < 0) {
        if (file->ignore_disabled_file_locks && ENOSYS == errno) {
            
            errno = 0;
        }
        else
            HSYS_GOTO_ERROR(H5E_VFL, H5E_CANTUNLOCKFILE, FAIL, "unable to unlock file");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5FD__direct_delete(const char *filename, hid_t H5_ATTR_UNUSED fapl_id)
{
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    assert(filename);

    if (HDremove(filename) < 0)
        HSYS_GOTO_ERROR(H5E_VFL, H5E_CANTDELETEFILE, FAIL, "unable to delete file");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

#endif 
