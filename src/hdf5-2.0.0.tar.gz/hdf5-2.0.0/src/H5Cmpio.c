/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Cmodule.h"
#define H5F_FRIEND

#include "H5private.h"
#include "H5ACprivate.h"
#include "H5Cpkg.h"
#include "H5CXprivate.h"
#include "H5Eprivate.h"
#include "H5Fpkg.h"
#include "H5FDprivate.h"
#include "H5MMprivate.h"
#include "H5SLprivate.h"

#ifdef H5_HAVE_PARALLEL

#define H5C_APPLY_CANDIDATE_LIST__DEBUG 0

static herr_t H5C__collective_write(H5F_t *f);
static herr_t H5C__flush_candidate_entries(H5F_t *f, unsigned entries_to_flush[H5C_RING_NTYPES],
                                           unsigned entries_to_clear[H5C_RING_NTYPES]);
static herr_t H5C__flush_candidates_in_ring(H5F_t *f, H5C_ring_t ring, unsigned entries_to_flush,
                                            unsigned entries_to_clear);

herr_t
H5C_apply_candidate_list(H5F_t *f, H5C_t *cache_ptr, unsigned num_candidates, haddr_t *candidates_list_ptr,
                         int mpi_rank, int mpi_size)
{
    H5FD_mpio_xfer_t orig_xfer_mode;
    unsigned         first_entry_to_flush;
    unsigned         last_entry_to_flush;
#ifndef NDEBUG
    unsigned total_entries_to_clear = 0;
    unsigned total_entries_to_flush = 0;
#endif
    unsigned          *candidate_assignment_table = NULL;
    unsigned           entries_to_flush[H5C_RING_NTYPES];
    unsigned           entries_to_clear[H5C_RING_NTYPES];
    haddr_t            addr;
    H5C_cache_entry_t *entry_ptr = NULL;
#ifdef H5C_DO_SANITY_CHECKS
    haddr_t last_addr;
#endif
#if H5C_APPLY_CANDIDATE_LIST__DEBUG
    char *tbl_buf = NULL;
#endif
    unsigned m, n;
    unsigned u;
    bool     restore_io_mode = false;
    herr_t   ret_value       = SUCCEED;

    FUNC_ENTER_NOAPI(FAIL)

    assert(cache_ptr != NULL);
    assert(num_candidates > 0);
    assert((!cache_ptr->slist_enabled) || (num_candidates <= cache_ptr->slist_len));
    assert(candidates_list_ptr != NULL);
    assert(0 <= mpi_rank);
    assert(mpi_rank < mpi_size);

    if (H5CX_get_io_xfer_mode(&orig_xfer_mode) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");

    memset(entries_to_flush, 0, sizeof(entries_to_flush));
    memset(entries_to_clear, 0, sizeof(entries_to_clear));

#if H5C_APPLY_CANDIDATE_LIST__DEBUG
    {
        const char *const table_header = "candidate list = ";
        size_t            tbl_buf_size;
        size_t            tbl_buf_left;
        size_t            entry_nchars;
        int               bytes_printed;

        Rfprintf(Rstdout, "%s:%d: setting up candidate assignment table.\n", __func__, mpi_rank);

        entry_nchars = (sizeof(long long) * CHAR_BIT / 4) + 3;

        tbl_buf_size = strlen(table_header) + (num_candidates * entry_nchars) + 1;
        if (NULL == (tbl_buf = H5MM_malloc(tbl_buf_size)))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "can't allocate debug buffer");
        tbl_buf_left = tbl_buf_size;

        if ((bytes_printed = snprintf(tbl_buf, tbl_buf_left, table_header)) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
        assert((size_t)bytes_printed < tbl_buf_left);
        tbl_buf_left -= (size_t)bytes_printed;

        for (u = 0; u < num_candidates; u++) {
            if ((bytes_printed = snprintf(&(tbl_buf[tbl_buf_size - tbl_buf_left]), tbl_buf_left, " 0x%llx",
                                          (long long)(*(candidates_list_ptr + u)))) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
            assert((size_t)bytes_printed < tbl_buf_left);
            tbl_buf_left -= (size_t)bytes_printed;
        }

        if ((bytes_printed = snprintf(&(tbl_buf[tbl_buf_size - tbl_buf_left]), tbl_buf_left, "\n")) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
        assert((size_t)bytes_printed < tbl_buf_left);
        tbl_buf_left -= (size_t)bytes_printed + 1;

        Rfprintf(Rstdout, "%s", tbl_buf);

        H5MM_free(tbl_buf);
        tbl_buf = NULL;
    }
#endif

    if (f->shared->coll_md_write) {

        assert(NULL == cache_ptr->coll_write_list);

        if (NULL == (cache_ptr->coll_write_list = H5SL_create(H5SL_TYPE_HADDR, NULL)))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTCREATE, FAIL, "can't create skip list for entries");
    }

    n = num_candidates / (unsigned)mpi_size;
    m = num_candidates % (unsigned)mpi_size;

    if (NULL ==
        (candidate_assignment_table = (unsigned *)H5MM_malloc(sizeof(unsigned) * (size_t)(mpi_size + 1))))
        HGOTO_ERROR(H5E_CACHE, H5E_NOSPACE, FAIL, "memory allocation failed for candidate assignment table");

    candidate_assignment_table[0]        = 0;
    candidate_assignment_table[mpi_size] = num_candidates;

    if (m == 0) {
        for (u = 1; u < (unsigned)mpi_size; u++)
            candidate_assignment_table[u] = candidate_assignment_table[u - 1] + n;
    }
    else {
        for (u = 1; u <= m; u++)
            candidate_assignment_table[u] = candidate_assignment_table[u - 1] + n + 1;

        if (num_candidates < (unsigned)mpi_size) {
            for (u = m + 1; u < (unsigned)mpi_size; u++)
                candidate_assignment_table[u] = num_candidates;
        }
        else {
            for (u = m + 1; u < (unsigned)mpi_size; u++)
                candidate_assignment_table[u] = candidate_assignment_table[u - 1] + n;
        }
    }
    assert((candidate_assignment_table[mpi_size - 1] + n) == num_candidates);

#ifdef H5C_DO_SANITY_CHECKS

    for (u = 1; u < (unsigned)(mpi_size - 1); u++) {
        unsigned a, b;

        a = candidate_assignment_table[u] - candidate_assignment_table[u - 1];
        b = candidate_assignment_table[u + 1] - candidate_assignment_table[u];

        assert(n + 1 >= a);
        assert(a >= b);
        assert(b >= n);
    }
#endif

    first_entry_to_flush = candidate_assignment_table[mpi_rank];
    last_entry_to_flush  = candidate_assignment_table[mpi_rank + 1] - 1;

#if H5C_APPLY_CANDIDATE_LIST__DEBUG
    {
        const char *const table_header = "candidate assignment table = ";
        unsigned          umax         = UINT_MAX;
        size_t            tbl_buf_size;
        size_t            tbl_buf_left;
        size_t            entry_nchars;
        int               bytes_printed;

        entry_nchars = (size_t)(log10(umax) + 1) + 1;

        tbl_buf_size = strlen(table_header) + ((size_t)mpi_size * entry_nchars) + 1;
        if (NULL == (tbl_buf = H5MM_malloc(tbl_buf_size)))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "can't allocate debug buffer");
        tbl_buf_left = tbl_buf_size;

        if ((bytes_printed = snprintf(tbl_buf, tbl_buf_left, table_header)) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
        assert((size_t)bytes_printed < tbl_buf_left);
        tbl_buf_left -= (size_t)bytes_printed;

        for (u = 0; u <= (unsigned)mpi_size; u++) {
            if ((bytes_printed = snprintf(&(tbl_buf[tbl_buf_size - tbl_buf_left]), tbl_buf_left, " %u",
                                          candidate_assignment_table[u])) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
            assert((size_t)bytes_printed < tbl_buf_left);
            tbl_buf_left -= (size_t)bytes_printed;
        }

        if ((bytes_printed = snprintf(&(tbl_buf[tbl_buf_size - tbl_buf_left]), tbl_buf_left, "\n")) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSERRSTR, FAIL, "can't add to candidate list");
        assert((size_t)bytes_printed < tbl_buf_left);
        tbl_buf_left -= (size_t)bytes_printed + 1;

        Rfprintf(Rstdout, "%s", tbl_buf);

        H5MM_free(tbl_buf);
        tbl_buf = NULL;

        Rfprintf(Rstdout, "%s:%d: flush entries [%u, %u].\n", __func__, mpi_rank, first_entry_to_flush,
                last_entry_to_flush);

        Rfprintf(Rstdout, "%s:%d: marking entries.\n", __func__, mpi_rank);
    }
#endif

    for (u = 0; u < num_candidates; u++) {
        addr = candidates_list_ptr[u];
        assert(H5_addr_defined(addr));

#ifdef H5C_DO_SANITY_CHECKS
        if (u > 0) {
            if (last_addr == addr)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "duplicate entry in cleaned list");
            else if (last_addr > addr)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "candidate list not sorted");
        }

        last_addr = addr;
#endif

        H5C__SEARCH_INDEX(cache_ptr, addr, entry_ptr, FAIL);
        if (entry_ptr == NULL)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "listed candidate entry not in cache?!?!?");
        if (!entry_ptr->is_dirty)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Listed entry not dirty?!?!?");
        if (entry_ptr->is_protected)

            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Listed entry is protected?!?!?");

        assert(entry_ptr->ring >= H5C_RING_USER);
        assert(entry_ptr->ring <= H5C_RING_SB);
        assert(!entry_ptr->flush_immediately);
        assert(!entry_ptr->clear_on_unprotect);

        if (u >= first_entry_to_flush && u <= last_entry_to_flush) {
#ifndef NDEBUG
            total_entries_to_flush++;
#endif
            entries_to_flush[entry_ptr->ring]++;
            entry_ptr->flush_immediately = true;
        }
        else {
#ifndef NDEBUG
            total_entries_to_clear++;
#endif
            entries_to_clear[entry_ptr->ring]++;
            entry_ptr->clear_on_unprotect = true;
        }

        if (entry_ptr->coll_access) {
            entry_ptr->coll_access = false;
            H5C__REMOVE_FROM_COLL_LIST(cache_ptr, entry_ptr, FAIL);
        }
    }

#ifdef H5C_DO_SANITY_CHECKS
    m = 0;
    n = 0;
    for (u = 0; u < H5C_RING_NTYPES; u++) {
        m += entries_to_flush[u];
        n += entries_to_clear[u];
    }

    assert((unsigned)m == total_entries_to_flush);
    assert(n == total_entries_to_clear);
#endif

#if H5C_APPLY_CANDIDATE_LIST__DEBUG
    Rfprintf(Rstdout, "%s:%d: num candidates/to clear/to flush = %u/%u/%u.\n", __func__, mpi_rank,
            num_candidates, total_entries_to_clear, total_entries_to_flush);
#endif

    if ((orig_xfer_mode == H5FD_MPIO_COLLECTIVE) && !f->shared->coll_md_write) {
        if (H5CX_set_io_xfer_mode(H5FD_MPIO_INDEPENDENT) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O transfer mode");
        restore_io_mode = true;
    }

    if (H5C__flush_candidate_entries(f, entries_to_flush, entries_to_clear) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "flush candidates failed");

    if (restore_io_mode) {
        if (H5CX_set_io_xfer_mode(orig_xfer_mode) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O transfer mode");
        restore_io_mode = false;
    }

    if (f->shared->coll_md_write) {

        assert(cache_ptr->coll_write_list);

        if (H5C__collective_write(f) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_WRITEERROR, FAIL, "can't write metadata collectively");
    }

done:

    if (restore_io_mode && (H5CX_set_io_xfer_mode(orig_xfer_mode) < 0))
        HDONE_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O transfer mode");

    if (candidate_assignment_table != NULL)
        candidate_assignment_table = (unsigned *)H5MM_xfree((void *)candidate_assignment_table);
    if (cache_ptr->coll_write_list) {
        if (H5SL_close(cache_ptr->coll_write_list) < 0)
            HDONE_ERROR(H5E_CACHE, H5E_CANTFREE, FAIL, "failed to destroy skip list");
        cache_ptr->coll_write_list = NULL;
    }

    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5C_construct_candidate_list__clean_cache(H5C_t *cache_ptr)
{
    size_t space_needed;
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_NOAPI(FAIL)

    assert(cache_ptr != NULL);

    space_needed = cache_ptr->dirty_index_size;

    assert((!cache_ptr->slist_enabled) || (space_needed == cache_ptr->slist_size));

    assert(cache_ptr->dirty_index_size <= (cache_ptr->dLRU_list_size + cache_ptr->pel_size));
    assert((!cache_ptr->slist_enabled) ||
           (cache_ptr->slist_len <= (cache_ptr->dLRU_list_len + cache_ptr->pel_len)));

    if (space_needed > 0) {
        H5C_cache_entry_t *entry_ptr;
        unsigned           nominated_entries_count = 0;
        size_t             nominated_entries_size  = 0;
        haddr_t            nominated_addr;

        assert((!cache_ptr->slist_enabled) || (cache_ptr->slist_len > 0));

        entry_ptr = cache_ptr->dLRU_tail_ptr;
        while ((nominated_entries_size < space_needed) &&
               ((!cache_ptr->slist_enabled) || (nominated_entries_count < cache_ptr->slist_len)) &&
               (entry_ptr != NULL)) {
            assert(!(entry_ptr->is_protected));
            assert(!(entry_ptr->is_read_only));
            assert(entry_ptr->ro_ref_count == 0);
            assert(entry_ptr->is_dirty);
            assert((!cache_ptr->slist_enabled) || (entry_ptr->in_slist));

            nominated_addr = entry_ptr->addr;
            if (H5AC_add_candidate((H5AC_t *)cache_ptr, nominated_addr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "H5AC_add_candidate() failed");

            nominated_entries_size += entry_ptr->size;
            nominated_entries_count++;

            entry_ptr = entry_ptr->aux_prev;
        }

        assert(entry_ptr == NULL);

        entry_ptr = cache_ptr->pel_head_ptr;
        while ((nominated_entries_size < space_needed) &&
               ((!cache_ptr->slist_enabled) || (nominated_entries_count < cache_ptr->slist_len)) &&
               (entry_ptr != NULL)) {
            if (entry_ptr->is_dirty) {
                assert(!(entry_ptr->is_protected));
                assert(!(entry_ptr->is_read_only));
                assert(entry_ptr->ro_ref_count == 0);
                assert(entry_ptr->is_dirty);
                assert(entry_ptr->in_slist);

                nominated_addr = entry_ptr->addr;
                if (H5AC_add_candidate((H5AC_t *)cache_ptr, nominated_addr) < 0)
                    HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "H5AC_add_candidate() failed");

                nominated_entries_size += entry_ptr->size;
                nominated_entries_count++;
            }

            entry_ptr = entry_ptr->next;
        }

        assert((!cache_ptr->slist_enabled) || (nominated_entries_count == cache_ptr->slist_len));
        assert(nominated_entries_size == space_needed);
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5C_construct_candidate_list__min_clean(H5C_t *cache_ptr)
{
    size_t space_needed = 0;
    herr_t ret_value    = SUCCEED;

    FUNC_ENTER_NOAPI(FAIL)

    assert(cache_ptr != NULL);

    if (cache_ptr->max_cache_size > cache_ptr->index_size) {

        if (((cache_ptr->max_cache_size - cache_ptr->index_size) + cache_ptr->cLRU_list_size) >=
            cache_ptr->min_clean_size)
            space_needed = 0;
        else
            space_needed = cache_ptr->min_clean_size -
                           ((cache_ptr->max_cache_size - cache_ptr->index_size) + cache_ptr->cLRU_list_size);
    }
    else {
        if (cache_ptr->min_clean_size <= cache_ptr->cLRU_list_size)
            space_needed = 0;
        else
            space_needed = cache_ptr->min_clean_size - cache_ptr->cLRU_list_size;
    }

    if (space_needed > 0) {
        H5C_cache_entry_t *entry_ptr;
        unsigned           nominated_entries_count = 0;
        size_t             nominated_entries_size  = 0;

        assert((!cache_ptr->slist_enabled) || (cache_ptr->slist_len > 0));

        entry_ptr = cache_ptr->dLRU_tail_ptr;
        while ((nominated_entries_size < space_needed) &&
               ((!cache_ptr->slist_enabled) || (nominated_entries_count < cache_ptr->slist_len)) &&
               (entry_ptr != NULL) && (!entry_ptr->flush_me_last)) {
            haddr_t nominated_addr;

            assert(!(entry_ptr->is_protected));
            assert(!(entry_ptr->is_read_only));
            assert(entry_ptr->ro_ref_count == 0);
            assert(entry_ptr->is_dirty);
            assert((!cache_ptr->slist_enabled) || (entry_ptr->in_slist));

            nominated_addr = entry_ptr->addr;
            if (H5AC_add_candidate((H5AC_t *)cache_ptr, nominated_addr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "H5AC_add_candidate() failed");

            nominated_entries_size += entry_ptr->size;
            nominated_entries_count++;

            entry_ptr = entry_ptr->aux_prev;
        }

        assert((!cache_ptr->slist_enabled) || (nominated_entries_count <= cache_ptr->slist_len));
        assert(nominated_entries_size <= cache_ptr->dirty_index_size);
        assert(nominated_entries_size >= space_needed);
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5C_mark_entries_as_clean(H5F_t *f, unsigned ce_array_len, haddr_t *ce_array_ptr)
{
    H5C_t   *cache_ptr;
    unsigned entries_cleared;
    unsigned pinned_entries_cleared;
    bool     progress;
    unsigned entries_examined;
    unsigned initial_list_len;
    haddr_t  addr;
    unsigned pinned_entries_marked = 0;
#ifdef H5C_DO_SANITY_CHECKS
    unsigned protected_entries_marked = 0;
    unsigned other_entries_marked     = 0;
    haddr_t  last_addr;
#endif
    H5C_cache_entry_t *clear_ptr = NULL;
    H5C_cache_entry_t *entry_ptr = NULL;
    unsigned           u;
    herr_t             ret_value = SUCCEED;

    FUNC_ENTER_NOAPI(FAIL)

    assert(f);
    assert(f->shared);
    cache_ptr = f->shared->cache;
    assert(cache_ptr);

    assert(ce_array_len > 0);
    assert(ce_array_ptr != NULL);

#ifdef H5C_DO_EXTREME_SANITY_CHECKS
    if (H5C__validate_protected_entry_list(cache_ptr) < 0 || H5C__validate_pinned_entry_list(cache_ptr) < 0 ||
        H5C__validate_lru_list(cache_ptr) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "an extreme sanity check failed on entry");
#endif

    for (u = 0; u < ce_array_len; u++) {
        addr = ce_array_ptr[u];

#ifdef H5C_DO_SANITY_CHECKS
        if (u == 0)
            last_addr = addr;
        else {
            if (last_addr == addr)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Duplicate entry in cleaned list");
            if (last_addr > addr)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "cleaned list not sorted");
        }

#ifdef H5C_DO_EXTREME_SANITY_CHECKS
        if (H5C__validate_protected_entry_list(cache_ptr) < 0 ||
            H5C__validate_pinned_entry_list(cache_ptr) < 0 || H5C__validate_lru_list(cache_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "an extreme sanity check failed in for loop");
#endif
#endif

        assert(H5_addr_defined(addr));

        H5C__SEARCH_INDEX(cache_ptr, addr, entry_ptr, FAIL);

        if (entry_ptr == NULL) {
#ifdef H5C_DO_SANITY_CHECKS
            Rfprintf(Rstdout, "H5C_mark_entries_as_clean: entry[%u] = %" PRIuHADDR " not in cache.\n", u, addr);
#endif
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Listed entry not in cache?!?!?");
        }
        else if (!entry_ptr->is_dirty) {
#ifdef H5C_DO_SANITY_CHECKS
            Rfprintf(Rstdout, "H5C_mark_entries_as_clean: entry %" PRIuHADDR " is not dirty!?!\n", addr);
#endif
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Listed entry not dirty?!?!?");
        }
        else {

            if (true == entry_ptr->coll_access) {
                entry_ptr->coll_access = false;
                H5C__REMOVE_FROM_COLL_LIST(cache_ptr, entry_ptr, FAIL);
            }

            entry_ptr->clear_on_unprotect = true;
            if (entry_ptr->is_pinned)
                pinned_entries_marked++;
#ifdef H5C_DO_SANITY_CHECKS
            else if (entry_ptr->is_protected)
                protected_entries_marked++;
            else
                other_entries_marked++;
#endif
        }
    }

    entries_cleared  = 0;
    entries_examined = 0;
    initial_list_len = cache_ptr->LRU_list_len;
    entry_ptr        = cache_ptr->LRU_tail_ptr;
    while (entry_ptr != NULL && entries_examined <= initial_list_len && entries_cleared < ce_array_len) {
        if (entry_ptr->clear_on_unprotect) {
            entry_ptr->clear_on_unprotect = false;
            clear_ptr                     = entry_ptr;
            entry_ptr                     = entry_ptr->prev;
            entries_cleared++;

            if (H5C__flush_single_entry(f, clear_ptr,
                                        (H5C__FLUSH_CLEAR_ONLY_FLAG | H5C__GENERATE_IMAGE_FLAG |
                                         H5C__UPDATE_PAGE_BUFFER_FLAG)) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "can't clear entry");
        }
        else
            entry_ptr = entry_ptr->prev;
        entries_examined++;
    }

#ifdef H5C_DO_SANITY_CHECKS
    assert(entries_cleared == other_entries_marked);
#endif

    pinned_entries_cleared = 0;
    progress               = true;
    while ((pinned_entries_cleared < pinned_entries_marked) && progress) {
        progress  = false;
        entry_ptr = cache_ptr->pel_head_ptr;
        while (entry_ptr != NULL) {
            if (entry_ptr->clear_on_unprotect && entry_ptr->flush_dep_ndirty_children == 0) {
                entry_ptr->clear_on_unprotect = false;
                clear_ptr                     = entry_ptr;
                entry_ptr                     = entry_ptr->next;
                entries_cleared++;
                pinned_entries_cleared++;
                progress = true;

                if (H5C__flush_single_entry(f, clear_ptr,
                                            (H5C__FLUSH_CLEAR_ONLY_FLAG | H5C__GENERATE_IMAGE_FLAG |
                                             H5C__UPDATE_PAGE_BUFFER_FLAG)) < 0)
                    HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "can't clear entry");
            }
            else
                entry_ptr = entry_ptr->next;
        }
    }

#ifdef H5C_DO_SANITY_CHECKS
    assert(entries_cleared == pinned_entries_marked + other_entries_marked);
    assert(entries_cleared + protected_entries_marked == ce_array_len);
#endif

    assert((entries_cleared == ce_array_len) || ((ce_array_len - entries_cleared) <= cache_ptr->pl_len));

#ifdef H5C_DO_SANITY_CHECKS
    u         = 0;
    entry_ptr = cache_ptr->pl_head_ptr;
    while (entry_ptr != NULL) {
        if (entry_ptr->clear_on_unprotect)
            u++;
        entry_ptr = entry_ptr->next;
    }
    assert((entries_cleared + u) == ce_array_len);
#endif

done:
#ifdef H5C_DO_EXTREME_SANITY_CHECKS
    if (H5C__validate_protected_entry_list(cache_ptr) < 0 || H5C__validate_pinned_entry_list(cache_ptr) < 0 ||
        H5C__validate_lru_list(cache_ptr) < 0)
        HDONE_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "an extreme sanity check failed on Rexit");
#endif

    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5C_clear_coll_entries(H5C_t *cache_ptr, bool partial)
{
    uint32_t           clear_cnt;
    H5C_cache_entry_t *entry_ptr = NULL;
    herr_t             ret_value = SUCCEED;

#ifdef H5C_DO_SANITY_CHECKS
    FUNC_ENTER_NOAPI_NOINIT
#else
    FUNC_ENTER_NOAPI_NOINIT_NOERR
#endif

    entry_ptr = cache_ptr->coll_tail_ptr;
    clear_cnt = (partial ? cache_ptr->coll_list_len / 2 : cache_ptr->coll_list_len);
    while (entry_ptr && clear_cnt > 0) {
        H5C_cache_entry_t *prev_ptr = entry_ptr->coll_prev;

        assert(entry_ptr->coll_access);

        entry_ptr->coll_access = false;
        H5C__REMOVE_FROM_COLL_LIST(cache_ptr, entry_ptr, FAIL);

        clear_cnt--;

        entry_ptr = prev_ptr;
    }

#ifdef H5C_DO_SANITY_CHECKS
done:
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5C__collective_write(H5F_t *f)
{
    H5AC_t          *cache_ptr;
    H5FD_mpio_xfer_t orig_xfer_mode = H5FD_MPIO_COLLECTIVE;
    const void     **bufs           = NULL;
    H5FD_mem_t      *types          = NULL;
    haddr_t         *addrs          = NULL;
    size_t          *sizes          = NULL;
    uint32_t         count32;
    size_t           count;
    herr_t           ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    assert(cache_ptr->coll_write_list != NULL);

    if (H5CX_get_io_xfer_mode(&orig_xfer_mode) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");

    if (H5CX_set_io_xfer_mode(H5FD_MPIO_COLLECTIVE) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O transfer mode");

    count = H5SL_count(cache_ptr->coll_write_list);
    H5_CHECKED_ASSIGN(count32, uint32_t, count, size_t);

    if (count > 0) {
        H5SL_node_t       *node;
        H5C_cache_entry_t *entry_ptr;
        void              *base_buf;
        int                i;

        if (NULL == (addrs = H5MM_malloc(count * sizeof(*addrs))))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "couldn't allocate address array");
        if (NULL == (sizes = H5MM_malloc(count * sizeof(*sizes))))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "couldn't allocate sizes array");
        if (NULL == (bufs = H5MM_malloc(count * sizeof(*bufs))))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "couldn't allocate buffers array");
        if (NULL == (types = H5MM_malloc(count * sizeof(*types))))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "couldn't allocate types array");

        node = H5SL_first(cache_ptr->coll_write_list);
        assert(node);
        if (NULL == (entry_ptr = (H5C_cache_entry_t *)H5SL_item(node)))
            HGOTO_ERROR(H5E_CACHE, H5E_NOTFOUND, FAIL, "can't retrieve skip list item");

        assert(entry_ptr->type);
        base_buf = entry_ptr->image_ptr;
        addrs[0] = entry_ptr->addr;
        sizes[0] = entry_ptr->size;
        bufs[0]  = base_buf;
        types[0] = entry_ptr->type->mem_type;

        if (types[0] == H5FD_MEM_GHEAP)
            types[0] = H5FD_MEM_DRAW;

        node = H5SL_next(node);
        i    = 1;
        while (node) {
            if (NULL == (entry_ptr = (H5C_cache_entry_t *)H5SL_item(node)))
                HGOTO_ERROR(H5E_CACHE, H5E_NOTFOUND, FAIL, "can't retrieve skip list item");

            assert(entry_ptr->type);
            addrs[i] = entry_ptr->addr;
            sizes[i] = entry_ptr->size;
            bufs[i]  = entry_ptr->image_ptr;
            types[i] = entry_ptr->type->mem_type;

            if (types[i] == H5FD_MEM_GHEAP)
                types[i] = H5FD_MEM_DRAW;

            node = H5SL_next(node);
            i++;
        }
    }

    if (H5CX_set_mpi_coll_datatypes(MPI_BYTE, MPI_BYTE) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O properties");

    if (H5F_shared_vector_write(H5F_SHARED(f), count32, types, addrs, sizes, bufs) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_WRITEERROR, FAIL, "unable to write entries");

done:
    H5MM_xfree(types);
    H5MM_xfree(bufs);
    H5MM_xfree(sizes);
    H5MM_xfree(addrs);

    if (orig_xfer_mode != H5FD_MPIO_COLLECTIVE)
        if (H5CX_set_io_xfer_mode(orig_xfer_mode) < 0)
            HDONE_ERROR(H5E_CACHE, H5E_CANTSET, FAIL, "can't set MPI-I/O transfer mode");

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5C__flush_candidate_entries(H5F_t *f, unsigned entries_to_flush[H5C_RING_NTYPES],
                             unsigned entries_to_clear[H5C_RING_NTYPES])
{
#ifdef H5C_DO_SANITY_CHECKS
    int      i;
    uint32_t index_len        = 0;
    size_t   index_size       = (size_t)0;
    size_t   clean_index_size = (size_t)0;
    size_t   dirty_index_size = (size_t)0;
    size_t   slist_size       = (size_t)0;
    uint32_t slist_len        = 0;
#endif
    H5C_ring_t ring;
    H5C_t     *cache_ptr;
    herr_t     ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f);
    assert(f->shared);
    cache_ptr = f->shared->cache;
    assert(cache_ptr);
    assert(cache_ptr->slist_ptr);

    assert(entries_to_flush[H5C_RING_UNDEFINED] == 0);
    assert(entries_to_clear[H5C_RING_UNDEFINED] == 0);

#ifdef H5C_DO_SANITY_CHECKS
    assert(cache_ptr->index_ring_len[H5C_RING_UNDEFINED] == 0);
    assert(cache_ptr->index_ring_size[H5C_RING_UNDEFINED] == (size_t)0);
    assert(cache_ptr->clean_index_ring_size[H5C_RING_UNDEFINED] == (size_t)0);
    assert(cache_ptr->dirty_index_ring_size[H5C_RING_UNDEFINED] == (size_t)0);
    assert(cache_ptr->slist_ring_len[H5C_RING_UNDEFINED] == 0);
    assert(cache_ptr->slist_ring_size[H5C_RING_UNDEFINED] == (size_t)0);

    for (i = H5C_RING_USER; i < H5C_RING_NTYPES; i++) {
        index_len += cache_ptr->index_ring_len[i];
        index_size += cache_ptr->index_ring_size[i];
        clean_index_size += cache_ptr->clean_index_ring_size[i];
        dirty_index_size += cache_ptr->dirty_index_ring_size[i];

        slist_len += cache_ptr->slist_ring_len[i];
        slist_size += cache_ptr->slist_ring_size[i];
    }

    assert(cache_ptr->index_len == index_len);
    assert(cache_ptr->index_size == index_size);
    assert(cache_ptr->clean_index_size == clean_index_size);
    assert(cache_ptr->dirty_index_size == dirty_index_size);
    assert(cache_ptr->slist_len == slist_len);
    assert(cache_ptr->slist_size == slist_size);
#endif

#ifdef H5C_DO_EXTREME_SANITY_CHECKS
    if (H5C__validate_protected_entry_list(cache_ptr) < 0 || H5C__validate_pinned_entry_list(cache_ptr) < 0 ||
        H5C__validate_lru_list(cache_ptr) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "an extreme sanity check failed on entry");
#endif

    cache_ptr->flush_in_progress = true;

    ring = H5C_RING_USER;
    while (ring < H5C_RING_NTYPES) {
        if (H5C__flush_candidates_in_ring(f, ring, entries_to_flush[ring], entries_to_clear[ring]) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "flush candidates in ring failed");

        ring++;
    }

done:
    cache_ptr->flush_in_progress = false;

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5C__flush_candidates_in_ring(H5F_t *f, H5C_ring_t ring, unsigned entries_to_flush, unsigned entries_to_clear)
{
    H5C_t   *cache_ptr;
    bool     progress;
    bool     restart_scan    = false;
    unsigned entries_flushed = 0;
    unsigned entries_cleared = 0;
#ifdef H5C_DO_SANITY_CHECKS
    unsigned init_index_len;
#endif
    unsigned clear_flags =
        H5C__FLUSH_CLEAR_ONLY_FLAG | H5C__GENERATE_IMAGE_FLAG | H5C__UPDATE_PAGE_BUFFER_FLAG;
    unsigned           flush_flags = H5C__NO_FLAGS_SET;
    unsigned           op_flags;
    H5C_cache_entry_t *op_ptr;
    H5C_cache_entry_t *entry_ptr;
    herr_t             ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f);
    assert(f->shared);
    cache_ptr = f->shared->cache;
    assert(cache_ptr);
    assert(cache_ptr->slist_ptr);
    assert(ring > H5C_RING_UNDEFINED);
    assert(ring < H5C_RING_NTYPES);

#ifdef H5C_DO_EXTREME_SANITY_CHECKS
    if ((H5C__validate_protected_entry_list(cache_ptr) < 0) ||
        (H5C__validate_pinned_entry_list(cache_ptr) < 0) || (H5C__validate_lru_list(cache_ptr) < 0))
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "an extreme sanity check failed on entry");
#endif

#ifdef H5C_DO_SANITY_CHECKS

    init_index_len = cache_ptr->index_len;
#endif

    restart_scan = false;
    entry_ptr    = cache_ptr->LRU_tail_ptr;
    while (((entries_flushed < entries_to_flush) || (entries_cleared < entries_to_clear)) &&
           (entry_ptr != NULL)) {
        bool               prev_is_dirty = false;
        H5C_cache_entry_t *next_ptr;

        assert(entry_ptr->flush_dep_nchildren == 0);

        if (entry_ptr->prev != NULL)
            prev_is_dirty = entry_ptr->prev->is_dirty;

        if (entry_ptr->ring == ring) {

            if (entry_ptr->clear_on_unprotect) {
                assert(entry_ptr->is_dirty);

                op_ptr   = entry_ptr;
                op_flags = clear_flags;

                next_ptr = entry_ptr->next;

                entry_ptr->clear_on_unprotect = false;
                entries_cleared++;
            }
            else if (entry_ptr->flush_immediately) {
                assert(entry_ptr->is_dirty);

                op_ptr   = entry_ptr;
                op_flags = flush_flags;

                next_ptr = entry_ptr->next;

                entry_ptr->flush_immediately = false;
                entries_flushed++;
            }
            else {

                op_ptr = NULL;

                next_ptr = entry_ptr;
            }

            entry_ptr = entry_ptr->prev;

            if (op_ptr) {

                cache_ptr->entries_removed_counter = 0;
                cache_ptr->last_entry_removed_ptr  = NULL;

                if (H5C__flush_single_entry(f, op_ptr, op_flags) < 0)
                    HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "can't flush entry");

                if (cache_ptr->entries_removed_counter != 0 || cache_ptr->last_entry_removed_ptr != NULL)
                    restart_scan = true;
            }
        }
        else {

            next_ptr = entry_ptr;

            entry_ptr = entry_ptr->prev;
        }

        if ((entry_ptr != NULL) &&
            (restart_scan || (entry_ptr->is_dirty != prev_is_dirty) || (entry_ptr->next != next_ptr) ||
             entry_ptr->is_protected || entry_ptr->is_pinned)) {

            assert(!restart_scan);
            assert(entry_ptr->is_dirty == prev_is_dirty);
            assert(entry_ptr->next == next_ptr);
            assert(!entry_ptr->is_protected);
            assert(!entry_ptr->is_pinned);

            assert(false);

            restart_scan = false;
            entry_ptr    = cache_ptr->LRU_tail_ptr;

            H5C__UPDATE_STATS_FOR_LRU_SCAN_RESTART(cache_ptr);
        }
    }

    progress = true;
    while (progress && ((entries_flushed < entries_to_flush) || (entries_cleared < entries_to_clear))) {
        progress  = false;
        entry_ptr = cache_ptr->pel_head_ptr;
        while ((entry_ptr != NULL) &&
               ((entries_flushed < entries_to_flush) || (entries_cleared < entries_to_clear))) {
            H5C_cache_entry_t *prev_ptr;
            bool               next_is_dirty = false;

            assert(entry_ptr->is_pinned);

            if (entry_ptr->next != NULL)
                next_is_dirty = entry_ptr->next->is_dirty;

            if (entry_ptr->ring == ring && entry_ptr->flush_dep_ndirty_children == 0) {
                if (entry_ptr->clear_on_unprotect) {
                    assert(entry_ptr->is_dirty);

                    op_ptr   = entry_ptr;
                    op_flags = clear_flags;

                    entry_ptr->clear_on_unprotect = false;
                    entries_cleared++;
                    progress = true;
                }
                else if (entry_ptr->flush_immediately) {
                    assert(entry_ptr->is_dirty);

                    op_ptr   = entry_ptr;
                    op_flags = flush_flags;

                    entry_ptr->flush_immediately = false;
                    entries_flushed++;
                    progress = true;
                }
                else

                    op_ptr = NULL;

                if (op_ptr) {

                    cache_ptr->entries_removed_counter = 0;
                    cache_ptr->last_entry_removed_ptr  = NULL;

                    if (H5C__flush_single_entry(f, op_ptr, op_flags) < 0)
                        HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "can't flush entry");

                    if (cache_ptr->entries_removed_counter != 0 || cache_ptr->last_entry_removed_ptr != NULL)
                        restart_scan = true;
                }
            }

            prev_ptr = entry_ptr;

            entry_ptr = entry_ptr->next;

            if ((entry_ptr != NULL) &&
                (restart_scan || (entry_ptr->is_dirty != next_is_dirty) || (entry_ptr->prev != prev_ptr) ||
                 entry_ptr->is_protected || !entry_ptr->is_pinned)) {

                assert(!restart_scan);
                assert(entry_ptr->is_dirty == next_is_dirty);
                assert(entry_ptr->prev == prev_ptr);
                assert(!entry_ptr->is_protected);
                assert(entry_ptr->is_pinned);

                assert(false);

                restart_scan = false;

                entry_ptr = cache_ptr->pel_head_ptr;

            }
        }
    }

#ifdef H5C_DO_SANITY_CHECKS
    assert(init_index_len == cache_ptr->index_len);
#endif

    if (entries_flushed != entries_to_flush || entries_cleared != entries_to_clear) {
        entry_ptr = cache_ptr->il_head;
        while (entry_ptr != NULL) {
            assert(!entry_ptr->clear_on_unprotect || (entry_ptr->ring > ring));
            assert(!entry_ptr->flush_immediately || (entry_ptr->ring > ring));
            entry_ptr = entry_ptr->il_next;
        }

        HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "can't flush/clear all entries");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}
#endif
