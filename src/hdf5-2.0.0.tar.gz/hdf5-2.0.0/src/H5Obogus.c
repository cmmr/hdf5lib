/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Omodule.h" 

#include "H5private.h"   
#include "H5Eprivate.h"  
#include "H5MMprivate.h" 
#include "H5Opkg.h"      

#ifdef H5O_ENABLE_BOGUS

static void  *H5O__bogus_decode(H5F_t *f, H5O_t *open_oh, unsigned mesg_flags, unsigned *ioflags,
                                size_t p_size, const uint8_t *p);
static herr_t H5O__bogus_encode(H5F_t *f, bool disable_shared, size_t H5_ATTR_UNUSED p_size, uint8_t *p,
                                const void *_mesg);
static size_t H5O__bogus_size(const H5F_t *f, bool disable_shared, const void *_mesg);
static herr_t H5O__bogus_debug(H5F_t *f, const void *_mesg, FILE *stream, int indent, int fwidth);

const H5O_msg_class_t H5O_MSG_BOGUS_VALID[1] = {{
    H5O_BOGUS_VALID_ID,    
    "bogus valid",         
    0,                     
    H5O_SHARE_IS_SHARABLE, 
    H5O__bogus_decode,     
    H5O__bogus_encode,     
    NULL,                  
    H5O__bogus_size,       
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    H5O__bogus_debug       
}};

const H5O_msg_class_t H5O_MSG_BOGUS_INVALID[1] = {{
    H5O_BOGUS_INVALID_ID,  
    "bogus invalid",       
    0,                     
    H5O_SHARE_IS_SHARABLE, 
    H5O__bogus_decode,     
    H5O__bogus_encode,     
    NULL,                  
    H5O__bogus_size,       
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    NULL,                  
    H5O__bogus_debug       
}};

static void *
H5O__bogus_decode(H5F_t *f, H5O_t H5_ATTR_NDEBUG_UNUSED *open_oh, unsigned H5_ATTR_UNUSED mesg_flags,
                  unsigned H5_ATTR_UNUSED *ioflags, size_t p_size, const uint8_t *p)
{
    const uint8_t *p_end = p + p_size - 1;
    H5O_bogus_t   *mesg  = NULL;
    void          *ret_value;

    FUNC_ENTER_PACKAGE

    assert(f);
    assert(p);

    
    if (NULL == (mesg = (H5O_bogus_t *)H5MM_calloc(sizeof(H5O_bogus_t))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_NOSPACE, NULL, "memory allocation failed");

    if (H5_IS_BUFFER_OVERFLOW(p, 4, p_end))
        HGOTO_ERROR(H5E_OHDR, H5E_OVERFLOW, NULL, "ran off end of input buffer while decoding");
    UINT32DECODE(p, mesg->u);

    
    if (mesg->u != H5O_BOGUS_VALUE)
        HGOTO_ERROR(H5E_OHDR, H5E_BADVALUE, NULL, "invalid bogus value :-)");

    
    ret_value = mesg;

done:
    if (ret_value == NULL && mesg != NULL)
        H5MM_xfree(mesg);

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5O__bogus_encode(H5F_t H5_ATTR_UNUSED *f, bool H5_ATTR_UNUSED disable_shared, size_t H5_ATTR_UNUSED p_size,
                  uint8_t *p, const void H5_ATTR_UNUSED *mesg)
{
    FUNC_ENTER_PACKAGE_NOERR

    
    assert(f);
    assert(p);
    assert(mesg);

    
    UINT32ENCODE(p, H5O_BOGUS_VALUE);

    FUNC_LEAVE_NOAPI(SUCCEED)
} 

static size_t
H5O__bogus_size(const H5F_t H5_ATTR_UNUSED *f, bool H5_ATTR_UNUSED disable_shared,
                const void H5_ATTR_UNUSED *mesg)
{
    FUNC_ENTER_PACKAGE_NOERR

    FUNC_LEAVE_NOAPI(4)
} 

static herr_t
H5O__bogus_debug(H5F_t H5_ATTR_UNUSED *f, const void *_mesg, FILE *stream, int indent, int fwidth)
{
    const H5O_bogus_t *mesg = (const H5O_bogus_t *)_mesg;

    FUNC_ENTER_PACKAGE_NOERR

    
    assert(f);
    assert(mesg);
    assert(stream);
    assert(indent >= 0);
    assert(fwidth >= 0);

    Rfprintf(stream, "%*s%-*s `%u'\n", indent, "", fwidth, "Bogus Value:", mesg->u);

    FUNC_LEAVE_NOAPI(SUCCEED)
} 
#endif 
