/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5FDsec2_H
#define H5FDsec2_H

#include "H5FDpublic.h"

#define H5FD_SEC2 (H5OPEN H5FD_SEC2_id_g)

#define H5FD_SEC2_VALUE H5_VFD_SEC2

#ifdef __cplusplus
extern "C" {
#endif

H5_DLLVAR hid_t H5FD_SEC2_id_g;

H5_DLL herr_t H5Pset_fapl_sec2(hid_t fapl_id);

#ifdef __cplusplus
}
#endif

#endif
