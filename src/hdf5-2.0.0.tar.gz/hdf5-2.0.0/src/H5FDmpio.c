/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#include "H5FDmodule.h"
#include "H5private.h"
#ifdef H5_HAVE_PARALLEL
#include "H5CXprivate.h"
#include "H5Dprivate.h"
#include "H5Eprivate.h"
#include "H5Fprivate.h"
#include "H5FDmpi.h"
#include "H5FDpkg.h"
#include "H5Iprivate.h"
#include "H5MMprivate.h"
#include "H5Pprivate.h"
hid_t H5FD_MPIO_id_g = H5I_INVALID_HID;
static bool H5FD_mpio_init_s = false;
bool H5FD_mpi_opt_types_g = true;
static bool H5FD_mpi_self_initialized_s = false;
static char H5FD_mpi_native_g[] = "native";
typedef struct H5FD_mpio_t {
    H5FD_t   pub;
    MPI_File f;
    MPI_Comm comm;
    MPI_Info info;
    int      mpi_rank;
    int      mpi_size;
    haddr_t  eof;
    haddr_t  eoa;
    haddr_t  last_eoa;
    haddr_t  local_eof;
    bool     mpi_file_sync_required;
} H5FD_mpio_t;
static herr_t  H5FD__mpio_term(void);
static H5FD_t *H5FD__mpio_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t maxaddr);
static herr_t  H5FD__mpio_close(H5FD_t *_file);
static herr_t  H5FD__mpio_query(const H5FD_t *_f1, unsigned long *flags);
static haddr_t H5FD__mpio_get_eoa(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__mpio_set_eoa(H5FD_t *_file, H5FD_mem_t type, haddr_t addr);
static haddr_t H5FD__mpio_get_eof(const H5FD_t *_file, H5FD_mem_t type);
static herr_t  H5FD__mpio_get_handle(H5FD_t *_file, hid_t fapl, void **file_handle);
static herr_t  H5FD__mpio_read(H5FD_t *_file, H5FD_mem_t type, hid_t dxpl_id, haddr_t addr, size_t size,
                               void *buf);
static herr_t  H5FD__mpio_write(H5FD_t *_file, H5FD_mem_t type, hid_t dxpl_id, haddr_t addr, size_t size,
                                const void *buf);
static herr_t  H5FD__mpio_read_vector(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, uint32_t count,
                                      H5FD_mem_t types[], haddr_t addrs[], size_t sizes[], void *bufs[]);
static herr_t  H5FD__mpio_write_vector(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, uint32_t count,
                                       H5FD_mem_t types[], haddr_t addrs[], size_t sizes[],
                                       const void *bufs[]);
static herr_t H5FD__mpio_read_selection(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id,
                                        size_t count, hid_t mem_space_ids[], hid_t file_space_ids[],
                                        haddr_t offsets[], size_t element_sizes[], void *bufs[]);
static herr_t H5FD__mpio_write_selection(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id,
                                         size_t count, hid_t mem_space_ids[], hid_t file_space_ids[],
                                         haddr_t offsets[], size_t element_sizes[], const void *bufs[]);
static herr_t H5FD__mpio_flush(H5FD_t *_file, hid_t dxpl_id, bool closing);
static herr_t H5FD__mpio_truncate(H5FD_t *_file, hid_t dxpl_id, bool closing);
static herr_t H5FD__mpio_delete(const char *filename, hid_t fapl_id);
static herr_t H5FD__mpio_ctl(H5FD_t *_file, uint64_t op_code, uint64_t flags, const void *input,
                             void **output);
static herr_t H5FD__mpio_vector_build_types(uint32_t count, H5FD_mem_t types[], haddr_t addrs[],
                                            size_t sizes[], H5_flexible_const_ptr_t bufs[],
                                            haddr_t *s_addrs[], size_t *s_sizes[], uint32_t *s_sizes_len,
                                            H5_flexible_const_ptr_t *s_bufs[], bool *vector_was_sorted,
                                            MPI_Offset *mpi_off, H5_flexible_const_ptr_t *mpi_bufs_base,
                                            int *size_i, MPI_Datatype *buf_type, bool *buf_type_created,
                                            MPI_Datatype *file_type, bool *file_type_created, char *unused);
static herr_t H5FD__selection_build_types(bool io_op_write, size_t num_pieces, H5_flexible_const_ptr_t mbb,
                                          H5S_t **file_spaces, H5S_t **mem_spaces, haddr_t offsets[],
                                          H5_flexible_const_ptr_t bufs[], size_t src_element_sizes[],
                                          size_t dst_element_sizes[], MPI_Datatype *final_ftype,
                                          bool *final_ftype_is_derived, MPI_Datatype *final_mtype,
                                          bool *final_mtype_is_derived);
static const H5FD_class_t H5FD_mpio_g = {
    H5FD_CLASS_VERSION,
    H5_VFD_MPIO,
    "mpio",
    HADDR_MAX,
    H5F_CLOSE_SEMI,
    H5FD__mpio_term,
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    H5FD__mpio_open,
    H5FD__mpio_close,
    NULL,
    H5FD__mpio_query,
    NULL,
    NULL,
    NULL,
    H5FD__mpio_get_eoa,
    H5FD__mpio_set_eoa,
    H5FD__mpio_get_eof,
    H5FD__mpio_get_handle,
    H5FD__mpio_read,
    H5FD__mpio_write,
    H5FD__mpio_read_vector,
    H5FD__mpio_write_vector,
    H5FD__mpio_read_selection,
    H5FD__mpio_write_selection,
    H5FD__mpio_flush,
    H5FD__mpio_truncate,
    NULL,
    NULL,
    H5FD__mpio_delete,
    H5FD__mpio_ctl,
    H5FD_FLMAP_DICHOTOMY
};
#ifdef H5FDmpio_DEBUG
static int H5FD_mpio_debug_flags_s[256];
static int H5FD_mpio_debug_rank_s = -1;
#define H5FD_MPIO_TRACE_THIS_RANK(file)                                                                      \
    (H5FD_mpio_debug_rank_s < 0 || H5FD_mpio_debug_rank_s == (file)->mpi_rank)
#endif
#ifdef H5FDmpio_DEBUG
static void
H5FD__mpio_parse_debug_str(const char *s)
{
    FUNC_ENTER_PACKAGE_NOERR
    assert(s);
    while (*s) {
        if ((int)(*s) >= (int)'0' && (int)(*s) <= (int)'9')
            H5FD_mpio_debug_rank_s = ((int)*s) - (int)'0';
        else
            H5FD_mpio_debug_flags_s[(int)*s]++;
        s++;
    }
    FUNC_LEAVE_NOAPI_VOID
}
static const char *
H5FD__mem_t_to_str(H5FD_mem_t mem_type)
{
    switch (mem_type) {
        case H5FD_MEM_NOLIST:
            return "H5FD_MEM_NOLIST";
        case H5FD_MEM_DEFAULT:
            return "H5FD_MEM_DEFAULT";
        case H5FD_MEM_SUPER:
            return "H5FD_MEM_SUPER";
        case H5FD_MEM_BTREE:
            return "H5FD_MEM_BTREE";
        case H5FD_MEM_DRAW:
            return "H5FD_MEM_DRAW";
        case H5FD_MEM_GHEAP:
            return "H5FD_MEM_GHEAP";
        case H5FD_MEM_LHEAP:
            return "H5FD_MEM_LHEAP";
        case H5FD_MEM_OHDR:
            return "H5FD_MEM_OHDR";
        case H5FD_MEM_NTYPES:
            return "H5FD_MEM_NTYPES";
        default:
            return "(Unknown)";
    }
}
#endif
herr_t
H5FD__mpio_register(void)
{
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    if (H5I_VFL != H5I_get_type(H5FD_MPIO_id_g))
        if ((H5FD_MPIO_id_g = H5FD_register(&H5FD_mpio_g, sizeof(H5FD_class_t), false)) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTREGISTER, FAIL, "unable to register mpio driver");
done:
    FUNC_LEAVE_NOAPI(ret_value)
}
herr_t
H5FD__mpio_unregister(void)
{
    FUNC_ENTER_PACKAGE_NOERR
    H5FD_MPIO_id_g = H5I_INVALID_HID;
    FUNC_LEAVE_NOAPI(SUCCEED)
}
static herr_t
H5FD__mpio_init(void)
{
    char  *env       = NULL;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    env = getenv(HDF5_DRIVER);
    if (env && !strcmp(env, "mpio")) {
        int mpi_initialized = 0;
        if (MPI_SUCCESS != MPI_Initialized(&mpi_initialized))
            HGOTO_ERROR(H5E_VFL, H5E_UNINITIALIZED, FAIL, "can't check if MPI is initialized");
        if (!mpi_initialized) {
            if (MPI_SUCCESS != MPI_Init(NULL, NULL))
                HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize MPI");
            H5FD_mpi_self_initialized_s = true;
        }
    }
    env = getenv("HDF5_MPI_OPT_TYPES");
    if (env && isdigit(*env))
        H5FD_mpi_opt_types_g = (0 == strtol(env, NULL, 0)) ? false : true;
#ifdef H5FDmpio_DEBUG
    memset(H5FD_mpio_debug_flags_s, 0, sizeof(H5FD_mpio_debug_flags_s));
    env = getenv("H5FD_mpio_Debug");
    if (env)
        H5FD__mpio_parse_debug_str(env);
#endif
    H5FD_mpio_init_s = true;
done:
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_term(void)
{
    FUNC_ENTER_PACKAGE_NOERR
    if (H5FD_mpi_self_initialized_s) {
        int mpi_finalized = 0;
        MPI_Finalized(&mpi_finalized);
        if (!mpi_finalized)
            MPI_Finalize();
        H5FD_mpi_self_initialized_s = false;
    }
    FUNC_LEAVE_NOAPI(SUCCEED)
}
herr_t
H5Pset_fapl_mpio(hid_t fapl_id, MPI_Comm comm, MPI_Info info)
{
    H5P_genplist_t *plist;
    herr_t          ret_value;
    FUNC_ENTER_API(FAIL)
    if (fapl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a file access list");
    if (MPI_COMM_NULL == comm)
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "MPI_COMM_NULL is not a valid communicator");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "can't set MPI communicator");
    if (H5P_set(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "can't set MPI info object");
    ret_value = H5P_set_driver(plist, H5FD_MPIO, NULL, NULL);
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pget_fapl_mpio(hid_t fapl_id, MPI_Comm *comm, MPI_Info *info)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (comm)
        *comm = MPI_COMM_NULL;
    if (info)
        *info = MPI_INFO_NULL;
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a file access list");
    if (H5FD_MPIO != H5P_peek_driver(plist))
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "VFL driver is not MPI-I/O");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (comm)
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, comm) < 0)
            HGOTO_ERROR(H5E_PLIST, H5E_CANTGET, FAIL, "can't get MPI communicator");
    if (info)
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, info) < 0)
            HGOTO_ERROR(H5E_PLIST, H5E_CANTGET, FAIL, "can't get MPI info object");
done:
    if (ret_value != SUCCEED) {
        if (comm)
            if (H5_mpi_comm_free(comm) < 0)
                HDONE_ERROR(H5E_PLIST, H5E_CANTFREE, FAIL, "unable to free MPI communicator");
        if (info)
            if (H5_mpi_info_free(info) < 0)
                HDONE_ERROR(H5E_PLIST, H5E_CANTFREE, FAIL, "unable to free MPI info object");
    }
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pset_dxpl_mpio(hid_t dxpl_id, H5FD_mpio_xfer_t xfer_mode)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (dxpl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (H5FD_MPIO_INDEPENDENT != xfer_mode && H5FD_MPIO_COLLECTIVE != xfer_mode)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "incorrect xfer_mode");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5D_XFER_IO_XFER_MODE_NAME, &xfer_mode) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to set value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pget_dxpl_mpio(hid_t dxpl_id, H5FD_mpio_xfer_t *xfer_mode)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, true)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (xfer_mode)
        if (H5P_get(plist, H5D_XFER_IO_XFER_MODE_NAME, xfer_mode) < 0)
            HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to get value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pset_dxpl_mpio_collective_opt(hid_t dxpl_id, H5FD_mpio_collective_opt_t opt_mode)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (dxpl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5D_XFER_MPIO_COLLECTIVE_OPT_NAME, &opt_mode) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to set value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pset_dxpl_mpio_chunk_opt(hid_t dxpl_id, H5FD_mpio_chunk_opt_t opt_mode)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (dxpl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5D_XFER_MPIO_CHUNK_OPT_HARD_NAME, &opt_mode) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to set value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pset_dxpl_mpio_chunk_opt_num(hid_t dxpl_id, unsigned num_chunk_per_proc)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (dxpl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5D_XFER_MPIO_CHUNK_OPT_NUM_NAME, &num_chunk_per_proc) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to set value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5Pset_dxpl_mpio_chunk_opt_ratio(hid_t dxpl_id, unsigned percent_num_proc_per_chunk)
{
    H5P_genplist_t *plist;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_API(FAIL)
    if (dxpl_id == H5P_DEFAULT)
        HGOTO_ERROR(H5E_PLIST, H5E_BADVALUE, FAIL, "can't set values in default property list");
    if (NULL == (plist = H5P_object_verify(dxpl_id, H5P_DATASET_XFER, false)))
        HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL, "not a dxpl");
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (H5P_set(plist, H5D_XFER_MPIO_CHUNK_OPT_RATIO_NAME, &percent_num_proc_per_chunk) < 0)
        HGOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "unable to set value");
done:
    FUNC_LEAVE_API(ret_value)
}
herr_t
H5FD_set_mpio_atomicity(H5FD_t *_file, bool flag)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_NOAPI_NOINIT
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    if (MPI_SUCCESS != (mpi_code = MPI_File_set_atomicity(file->f, (int)(flag != false))))
        HMPI_GOTO_ERROR(FAIL, "MPI_File_set_atomicity", mpi_code)
done:
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
herr_t
H5FD_get_mpio_atomicity(H5FD_t *_file, bool *flag)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
    int          temp_flag;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_NOAPI_NOINIT
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    if (MPI_SUCCESS != (mpi_code = MPI_File_get_atomicity(file->f, &temp_flag)))
        HMPI_GOTO_ERROR(FAIL, "MPI_File_get_atomicity", mpi_code)
    if (0 != temp_flag)
        *flag = true;
    else
        *flag = false;
done:
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static H5FD_t *
H5FD__mpio_open(const char *name, unsigned flags, hid_t fapl_id, haddr_t H5_ATTR_UNUSED maxaddr)
{
    H5FD_mpio_t    *file = NULL;
    H5P_genplist_t *plist;
    MPI_Comm        comm = MPI_COMM_NULL;
    MPI_Info        info = MPI_INFO_NULL;
    MPI_Info        info_used;
    MPI_File        fh;
    bool            file_opened = false;
    int             mpi_amode;
    int             mpi_rank = INT_MAX;
    int             mpi_size;
    MPI_Offset      file_size;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = false;
#endif
    int     mpi_code;
    H5FD_t *ret_value = NULL;
    FUNC_ENTER_PACKAGE
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, NULL, "can't initialize driver");
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "not a file access property list");
    if (H5FD_mpi_self_initialized_s) {
        comm = MPI_COMM_WORLD;
    }
    else {
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get MPI communicator");
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "can't get MPI info object");
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Comm_rank(comm, &mpi_rank)))
        HMPI_GOTO_ERROR(NULL, "MPI_Comm_rank failed", mpi_code)
    if (MPI_SUCCESS != (mpi_code = MPI_Comm_size(comm, &mpi_size)))
        HMPI_GOTO_ERROR(NULL, "MPI_Comm_size failed", mpi_code)
#ifdef H5FDmpio_DEBUG
    H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] &&
                              (H5FD_mpio_debug_rank_s < 0 || H5FD_mpio_debug_rank_s == mpi_rank));
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering - name = \"%s\", flags = 0x%x, fapl_id = %d, maxaddr = %lu\n",
                __func__, mpi_rank, name, flags, (int)fapl_id, (unsigned long)maxaddr);
#endif
    mpi_amode = (flags & H5F_ACC_RDWR) ? MPI_MODE_RDWR : MPI_MODE_RDONLY;
    if (flags & H5F_ACC_CREAT)
        mpi_amode |= MPI_MODE_CREATE;
    if (flags & H5F_ACC_EXCL)
        mpi_amode |= MPI_MODE_EXCL;
#ifdef H5FDmpio_DEBUG
    if (MPI_INFO_NULL != info) {
        char debug_str[128];
        int  flag;
        MPI_Info_get(info, H5F_MPIO_DEBUG_KEY, sizeof(debug_str) - 1, debug_str, &flag);
        if (flag)
            H5FD__mpio_parse_debug_str(debug_str);
    }
#endif
    if (MPI_SUCCESS != (mpi_code = MPI_File_open(comm, name, mpi_amode, info, &fh)))
        HMPI_GOTO_ERROR(NULL, "MPI_File_open failed", mpi_code)
    file_opened = true;
    if (MPI_SUCCESS != (mpi_code = MPI_File_get_info(fh, &info_used)))
        HMPI_GOTO_ERROR(NULL, "MPI_File_get_info failed", mpi_code)
    if (info_used != MPI_INFO_NULL) {
        int i, nkeys;
        if (info == MPI_INFO_NULL)
            info = info_used;
        else {
            if (MPI_SUCCESS != (mpi_code = MPI_Info_get_nkeys(info_used, &nkeys)))
                HMPI_GOTO_ERROR(NULL, "MPI_Info_get_nkeys failed", mpi_code)
            for (i = 0; i < nkeys; i++) {
                char key[MPI_MAX_INFO_KEY], value[MPI_MAX_INFO_VAL + 1];
                int  valuelen, flag;
                if (MPI_SUCCESS != (mpi_code = MPI_Info_get_nthkey(info_used, i, key)))
                    HMPI_GOTO_ERROR(NULL, "MPI_Info_get_nkeys failed", mpi_code)
                if (MPI_SUCCESS != (mpi_code = MPI_Info_get_valuelen(info_used, key, &valuelen, &flag)))
                    HMPI_GOTO_ERROR(NULL, "MPI_Info_get_valuelen failed", mpi_code)
                if (MPI_SUCCESS != (mpi_code = MPI_Info_get(info_used, key, valuelen, value, &flag)))
                    HMPI_GOTO_ERROR(NULL, "MPI_Info_get failed", mpi_code)
                if (MPI_SUCCESS != (mpi_code = MPI_Info_set(info, key, value)))
                    HMPI_GOTO_ERROR(NULL, "MPI_Info_set failed", mpi_code)
            }
            if (MPI_SUCCESS != (mpi_code = MPI_Info_free(&info_used)))
                HMPI_GOTO_ERROR(NULL, "MPI_Info_free failed", mpi_code)
        }
        if (H5P_set(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTSET, NULL, "can't set MPI info object");
    }
    if (NULL == (file = (H5FD_mpio_t *)H5MM_calloc(sizeof(H5FD_mpio_t))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_NOSPACE, NULL, "memory allocation failed");
    file->f        = fh;
    file->comm     = comm;
    file->info     = info;
    file->mpi_rank = mpi_rank;
    file->mpi_size = mpi_size;
    if (H5_mpio_get_file_sync_required(fh, &file->mpi_file_sync_required) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, NULL, "unable to get mpi_file_sync_required hint");
    if (mpi_rank == 0) {
        if (MPI_SUCCESS != (mpi_code = MPI_File_get_size(fh, &file_size)))
            file_size = (MPI_Offset)-1;
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Bcast(&file_size, (int)sizeof(MPI_Offset), MPI_BYTE, 0, comm)))
        HMPI_GOTO_ERROR(NULL, "MPI_Bcast failed", mpi_code)
    if (file_size < 0)
        HMPI_GOTO_ERROR(NULL, "MPI_File_get_size failed", mpi_code)
    if (file_size && (flags & H5F_ACC_TRUNC)) {
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_size(fh, (MPI_Offset)0)))
            HMPI_GOTO_ERROR(NULL, "MPI_File_set_size failed", mpi_code)
        if (MPI_SUCCESS != (mpi_code = MPI_Barrier(comm)))
            HMPI_GOTO_ERROR(NULL, "MPI_Barrier failed", mpi_code)
        file_size = 0;
    }
    file->eof       = H5FD_mpi_MPIOff_to_haddr(file_size);
    file->local_eof = file->eof;
    ret_value = (H5FD_t *)file;
done:
    if (ret_value == NULL) {
        if (file_opened)
            MPI_File_close(&fh);
        if (H5_mpi_comm_free(&comm) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTFREE, NULL, "unable to free MPI communicator");
        if (H5_mpi_info_free(&info) < 0)
            HDONE_ERROR(H5E_VFL, H5E_CANTFREE, NULL, "unable to free MPI info object");
        if (file)
            H5MM_xfree(file);
    }
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_close(H5FD_t *_file)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    int  mpi_rank               = file->mpi_rank;
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    if (MPI_SUCCESS != (mpi_code = MPI_File_close(&(file->f))))
        HMPI_GOTO_ERROR(FAIL, "MPI_File_close failed", mpi_code)
    H5_mpi_comm_free(&file->comm);
    H5_mpi_info_free(&file->info);
    H5MM_xfree(file);
done:
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_query(const H5FD_t H5_ATTR_UNUSED *_file, unsigned long *flags)
{
    FUNC_ENTER_PACKAGE_NOERR
    if (flags) {
        *flags = 0;
        *flags |= H5FD_FEAT_AGGREGATE_METADATA;
        *flags |= H5FD_FEAT_AGGREGATE_SMALLDATA;
        *flags |= H5FD_FEAT_HAS_MPI;
        *flags |= H5FD_FEAT_DEFAULT_VFD_COMPATIBLE;
    }
    FUNC_LEAVE_NOAPI(SUCCEED)
}
static haddr_t
H5FD__mpio_get_eoa(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_mpio_t *file = (const H5FD_mpio_t *)_file;
    FUNC_ENTER_PACKAGE_NOERR
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    FUNC_LEAVE_NOAPI(file->eoa)
}
static herr_t
H5FD__mpio_set_eoa(H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type, haddr_t addr)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
    FUNC_ENTER_PACKAGE_NOERR
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    file->eoa = addr;
    FUNC_LEAVE_NOAPI(SUCCEED)
}
static haddr_t
H5FD__mpio_get_eof(const H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type)
{
    const H5FD_mpio_t *file = (const H5FD_mpio_t *)_file;
    FUNC_ENTER_PACKAGE_NOERR
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    FUNC_LEAVE_NOAPI(file->eof)
}
static herr_t
H5FD__mpio_get_handle(H5FD_t *_file, hid_t H5_ATTR_UNUSED fapl, void **file_handle)
{
    H5FD_mpio_t *file      = (H5FD_mpio_t *)_file;
    herr_t       ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    if (!file_handle)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "file handle not valid");
    *file_handle = &(file->f);
done:
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_read(H5FD_t *_file, H5FD_mem_t H5_ATTR_UNUSED type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr,
                size_t size, void *buf)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
    MPI_Offset   mpi_off;
    MPI_Status   mpi_stat;
    MPI_Datatype buf_type = MPI_BYTE;
    int          size_i;
    MPI_Count    bytes_read = 0;
    MPI_Count    type_size;
    MPI_Count    io_size;
    MPI_Count    n;
    bool         use_view_this_time = false;
    bool         derived_type       = false;
    bool         rank0_bcast        = false;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_r_flag = (H5FD_mpio_debug_flags_s[(int)'r'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert(buf);
    memset(&mpi_stat, 0, sizeof(MPI_Status));
    if (H5FD_mpi_haddr_to_MPIOff(addr, &mpi_off) < 0)
        HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
    size_i = (int)size;
    if (type == H5FD_MEM_DRAW) {
        H5FD_mpio_xfer_t xfer_mode;
        if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
        if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
            MPI_Datatype file_type;
            use_view_this_time = true;
            if (H5CX_get_mpi_coll_datatypes(&buf_type, &file_type) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O datatypes");
            if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, file_type,
                                                             H5FD_mpi_native_g, file->info)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
            mpi_off = 0;
        }
    }
    if (use_view_this_time) {
        H5FD_mpio_collective_opt_t coll_opt_mode;
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstderr, "%s: (%d) using MPIO collective mode\n", __func__, file->mpi_rank);
#endif
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI collective IO\n", __func__, file->mpi_rank);
#endif
            if (H5CX_get_mpio_rank0_bcast()) {
#ifdef H5FDmpio_DEBUG
                if (H5FD_mpio_debug_r_flag)
                    Rfprintf(Rstderr, "%s: (%d) doing read-rank0-and-MPI_Bcast\n", __func__, file->mpi_rank);
#endif
                rank0_bcast = true;
                if (file->mpi_rank == 0) {
                    if (MPI_SUCCESS !=
                        (mpi_code = MPI_File_read_at(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
                        HMPI_DONE_ERROR(FAIL, "MPI_File_read_at failed", mpi_code)
                }
                if (MPI_SUCCESS != (mpi_code = MPI_Bcast(buf, size_i, buf_type, 0, file->comm)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_code)
            }
            else
                if (MPI_SUCCESS !=
                    (mpi_code = MPI_File_read_at_all(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at_all failed", mpi_code)
        }
        else {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_read_at(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at failed", mpi_code)
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
    }
    else {
        if (size != (hsize_t)size_i) {
            if (H5_mpio_create_large_type(size, 0, MPI_BYTE, &buf_type) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
            derived_type = true;
            size_i       = 1;
        }
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
        if (MPI_SUCCESS != (mpi_code = MPI_File_read_at(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at failed", mpi_code)
    }
    if (!rank0_bcast || (rank0_bcast && file->mpi_rank == 0)) {
        if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, buf_type, &bytes_read))) {
            if (rank0_bcast && file->mpi_rank == 0) {
                bytes_read = -1;
                HMPI_DONE_ERROR(FAIL, "MPI_Get_elements failed for rank 0", mpi_code)
            }
            else
                HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code)
        }
    }
    if (rank0_bcast)
        if (MPI_SUCCESS != MPI_Bcast(&bytes_read, 1, MPI_COUNT, 0, file->comm))
            HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", 0)
    if (MPI_SUCCESS != (mpi_code = MPI_Type_size_x(buf_type, &type_size)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_size failed", mpi_code)
    io_size = type_size * size_i;
    if (bytes_read < 0 || bytes_read > io_size)
        HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_r_flag)
        Rfprintf(Rstderr, "%s: (%d) mpi_off = %ld  bytes_read = %lld  type = %s\n", __func__, file->mpi_rank,
                (long)mpi_off, (long long)bytes_read, H5FD__mem_t_to_str(type));
#endif
    if ((n = (io_size - bytes_read)) > 0)
        memset((char *)buf + bytes_read, 0, (size_t)n);
done:
    if (derived_type)
        MPI_Type_free(&buf_type);
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_write(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id, haddr_t addr, size_t size,
                 const void *buf)
{
    H5FD_mpio_t     *file = (H5FD_mpio_t *)_file;
    MPI_Offset       mpi_off;
    MPI_Status       mpi_stat;
    MPI_Datatype     buf_type = MPI_BYTE;
    MPI_Count        bytes_written;
    MPI_Count        type_size;
    MPI_Count        io_size;
    int              size_i;
    bool             use_view_this_time = false;
    bool             derived_type       = false;
    H5FD_mpio_xfer_t xfer_mode;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_w_flag = (H5FD_mpio_debug_flags_s[(int)'w'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert(buf);
    assert(!H5CX_get_mpi_file_flushing());
    memset(&mpi_stat, 0, sizeof(MPI_Status));
    if (H5FD_mpi_haddr_to_MPIOff(addr, &mpi_off) < 0)
        HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
    size_i = (int)size;
    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        MPI_Datatype file_type;
        use_view_this_time = true;
        if (H5CX_get_mpi_coll_datatypes(&buf_type, &file_type) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O datatypes");
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, file_type,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
        mpi_off = 0;
    }
    if (use_view_this_time) {
        H5FD_mpio_collective_opt_t coll_opt_mode;
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstderr, "%s: (%d) using MPIO collective mode\n", __func__, file->mpi_rank);
#endif
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI collective IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_write_at_all(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at_all failed", mpi_code)
            if (file->mpi_file_sync_required) {
                if (MPI_SUCCESS != (mpi_code = MPI_File_sync(file->f)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_sync failed", mpi_code)
            }
        }
        else {
            if (type != H5FD_MEM_DRAW)
                HGOTO_ERROR(H5E_PLIST, H5E_BADTYPE, FAIL,
                            "Metadata Coll opt property should be collective at this point");
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_write_at(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at failed", mpi_code)
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
    }
    else {
        if (size != (hsize_t)size_i) {
            if (H5_mpio_create_large_type(size, 0, MPI_BYTE, &buf_type) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
            derived_type = true;
            size_i       = 1;
        }
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
        if (MPI_SUCCESS != (mpi_code = MPI_File_write_at(file->f, mpi_off, buf, size_i, buf_type, &mpi_stat)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at failed", mpi_code)
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, buf_type, &bytes_written)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code)
    if (MPI_SUCCESS != (mpi_code = MPI_Type_size_x(buf_type, &type_size)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_size failed", mpi_code)
    io_size = type_size * size_i;
    if (bytes_written != io_size || bytes_written < 0)
        HGOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "file write failed");
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_w_flag)
        Rfprintf(Rstderr, "%s: (%d) mpi_off = %ld  bytes_written = %lld  type = %s\n", __func__, file->mpi_rank,
                (long)mpi_off, (long long)bytes_written, H5FD__mem_t_to_str(type));
#endif
    file->eof = HADDR_UNDEF;
    if (bytes_written && (((haddr_t)bytes_written + addr) > file->local_eof))
        file->local_eof = addr + (haddr_t)bytes_written;
done:
    if (derived_type)
        MPI_Type_free(&buf_type);
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving: ret_value = %d\n", __func__, file->mpi_rank, ret_value);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_vector_build_types(uint32_t count, H5FD_mem_t types[], haddr_t addrs[], size_t sizes[],
                              H5_flexible_const_ptr_t bufs[], haddr_t *s_addrs[], size_t *s_sizes[],
                              uint32_t *s_sizes_len, H5_flexible_const_ptr_t *s_bufs[],
                              bool *vector_was_sorted, MPI_Offset *mpi_off,
                              H5_flexible_const_ptr_t *mpi_bufs_base, int *size_i, MPI_Datatype *buf_type,
                              bool *buf_type_created, MPI_Datatype *file_type, bool *file_type_created,
                              char *unused)
{
    hsize_t       bigio_count;
    bool          fixed_size = false;
    size_t        size;
    H5FD_mem_t   *s_types           = NULL;
    int          *mpi_block_lengths = NULL;
    MPI_Aint      mpi_bufs_base_Aint;
    MPI_Aint     *mpi_bufs          = NULL;
    MPI_Aint     *mpi_displacements = NULL;
    MPI_Datatype *sub_types         = NULL;
    uint8_t      *sub_types_created = NULL;
    int           i;
    int           j;
    int           mpi_code;
    herr_t        ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    assert(s_sizes);
    assert(s_bufs);
    assert(vector_was_sorted);
    assert(*vector_was_sorted);
    assert(mpi_off);
    assert(mpi_bufs_base);
    assert(size_i);
    assert(buf_type);
    assert(buf_type_created);
    assert(!*buf_type_created);
    assert(file_type);
    assert(file_type_created);
    assert(!*file_type_created);
    assert(unused);
    bigio_count = H5_mpi_get_bigio_count();
    if (s_sizes_len)
        *s_sizes_len = count;
    if (count == 1) {
        *size_i        = (int)sizes[0];
        *buf_type      = MPI_BYTE;
        *file_type     = MPI_BYTE;
        *mpi_bufs_base = bufs[0];
        *s_addrs = addrs;
        *s_sizes = sizes;
        *s_bufs  = bufs;
        if (H5FD_mpi_haddr_to_MPIOff(addrs[0], mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI offset");
        if (sizes[0] > bigio_count) {
            if (H5_mpio_create_large_type(sizes[0], 0, MPI_BYTE, buf_type) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
            *buf_type_created = true;
            if (H5_mpio_create_large_type(sizes[0], 0, MPI_BYTE, file_type) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
            *file_type_created = true;
            *size_i = 1;
        }
    }
    else if (count > 0) {
        if (H5FD_sort_vector_io_req(vector_was_sorted, count, types, addrs, sizes, bufs, &s_types, s_addrs,
                                    s_sizes, s_bufs) < 0)
            HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "can't sort vector I/O request");
        if ((NULL == (mpi_block_lengths = (int *)malloc((size_t)count * sizeof(int)))) ||
            (NULL == (mpi_displacements = (MPI_Aint *)malloc((size_t)count * sizeof(MPI_Aint)))) ||
            (NULL == (mpi_bufs = (MPI_Aint *)malloc((size_t)count * sizeof(MPI_Aint))))) {
            HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't alloc mpi block lengths / displacement");
        }
        j = 0;
        for (i = 1; i < (int)count; i++) {
            if ((*s_bufs)[i].cvp < (*s_bufs)[j].cvp) {
                j = i;
            }
        }
        *mpi_bufs_base = (*s_bufs)[j];
        if (MPI_SUCCESS != (mpi_code = MPI_Get_address(mpi_bufs_base->cvp, &mpi_bufs_base_Aint)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Get_address for s_bufs[] to mpi_bufs_base failed", mpi_code)
        *size_i = 1;
        fixed_size = false;
        for (i = 0; i < (int)count; i++) {
            if (!fixed_size) {
                if ((*s_sizes)[i] == 0) {
                    assert(*vector_was_sorted);
                    assert(i > 0);
                    fixed_size = true;
                    size       = sizes[i - 1];
                    if (s_sizes_len)
                        *s_sizes_len = (uint32_t)i;
                }
                else {
                    size = (*s_sizes)[i];
                }
            }
            mpi_block_lengths[i] = (int)size;
            mpi_displacements[i] = (MPI_Aint)(*s_addrs)[i];
            if (MPI_SUCCESS != (mpi_code = MPI_Get_address((*s_bufs)[i].cvp, &(mpi_bufs[i]))))
                HMPI_GOTO_ERROR(FAIL, "MPI_Get_address for s_bufs[] - mpi_bufs_base failed", mpi_code)
#if H5_CHECK_MPI_VERSION(3, 1)
            mpi_bufs[i] = MPI_Aint_diff(mpi_bufs[i], mpi_bufs_base_Aint);
#else
            mpi_bufs[i] = mpi_bufs[i] - mpi_bufs_base_Aint;
#endif
            if (size > bigio_count) {
                if (!sub_types) {
                    assert(!sub_types_created);
                    if (NULL == (sub_types = malloc((size_t)count * sizeof(MPI_Datatype))))
                        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't alloc sub types array");
                    if (NULL == (sub_types_created = (uint8_t *)calloc((size_t)count, 1))) {
                        H5MM_free(sub_types);
                        sub_types = NULL;
                        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't alloc sub types created array");
                    }
                    for (j = 0; j < (int)count; j++)
                        sub_types[j] = MPI_BYTE;
                }
                assert(sub_types_created);
                if (H5_mpio_create_large_type(size, 0, MPI_BYTE, &sub_types[i]) < 0)
                    HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
                sub_types_created[i] = true;
                mpi_block_lengths[i] = 1;
            }
            else
                assert(size == (size_t)mpi_block_lengths[i]);
        }
        if (sub_types) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct((int)count, mpi_block_lengths, mpi_bufs,
                                                                  sub_types, buf_type)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct for buf_type failed", mpi_code)
        }
        else if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hindexed((int)count, mpi_block_lengths, mpi_bufs,
                                                                     MPI_BYTE, buf_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed for buf_type failed", mpi_code)
        *buf_type_created = true;
        if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(buf_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit for buf_type failed", mpi_code)
        if (sub_types) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct((int)count, mpi_block_lengths,
                                                                  mpi_displacements, sub_types, file_type)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct for file_type failed", mpi_code)
        }
        else if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hindexed((int)count, mpi_block_lengths,
                                                                     mpi_displacements, MPI_BYTE, file_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed for file_type failed", mpi_code)
        *file_type_created = true;
        if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(file_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit for file_type failed", mpi_code)
        assert(mpi_block_lengths);
        free(mpi_block_lengths);
        mpi_block_lengths = NULL;
        assert(mpi_displacements);
        free(mpi_displacements);
        mpi_displacements = NULL;
        assert(mpi_bufs);
        free(mpi_bufs);
        mpi_bufs = NULL;
        if (sub_types) {
            assert(sub_types);
            for (i = 0; i < (int)count; i++)
                if (sub_types_created[i])
                    MPI_Type_free(&sub_types[i]);
            free(sub_types);
            sub_types = NULL;
            free(sub_types_created);
            sub_types_created = NULL;
        }
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
    }
    else {
        *buf_type  = MPI_BYTE;
        *file_type = MPI_BYTE;
        mpi_bufs_base->vp = unused;
        *size_i = 0;
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
    }
done:
    if (!*vector_was_sorted)
        if (s_types) {
            free(s_types);
            s_types = NULL;
        }
    if (ret_value < 0) {
        if (mpi_block_lengths) {
            free(mpi_block_lengths);
            mpi_block_lengths = NULL;
        }
        if (mpi_displacements) {
            free(mpi_displacements);
            mpi_displacements = NULL;
        }
        if (mpi_bufs) {
            free(mpi_bufs);
            mpi_bufs = NULL;
        }
        if (sub_types) {
            assert(sub_types_created);
            for (i = 0; i < (int)count; i++)
                if (sub_types_created[i])
                    MPI_Type_free(&sub_types[i]);
            free(sub_types);
            sub_types = NULL;
            free(sub_types_created);
            sub_types_created = NULL;
        }
    }
    assert(!mpi_block_lengths);
    assert(!mpi_displacements);
    assert(!mpi_bufs);
    assert(!sub_types);
    assert(!sub_types_created);
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_read_vector(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, uint32_t count, H5FD_mem_t types[],
                       haddr_t addrs[], size_t sizes[], void *bufs[])
{
    H5FD_mpio_t               *file              = (H5FD_mpio_t *)_file;
    bool                       vector_was_sorted = true;
    haddr_t                   *s_addrs           = NULL;
    size_t                    *s_sizes           = NULL;
    void                     **s_bufs            = NULL;
    char                       unused            = 0;
    void                      *mpi_bufs_base     = NULL;
    MPI_Datatype               buf_type          = MPI_BYTE;
    bool                       buf_type_created  = false;
    MPI_Datatype               file_type         = MPI_BYTE;
    bool                       file_type_created = false;
    int                        i;
    int                        mpi_code;
    MPI_Offset                 mpi_off = 0;
    MPI_Status                 mpi_stat;
    H5FD_mpio_xfer_t           xfer_mode;
    H5FD_mpio_collective_opt_t coll_opt_mode;
    int                        size_i;
    MPI_Count                  bytes_read = 0;
    MPI_Count                  type_size;
    MPI_Count                  io_size;
    MPI_Count                  n;
    bool                       rank0_bcast = false;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_r_flag = (H5FD_mpio_debug_flags_s[(int)'r'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert((types) || (count == 0));
    assert((addrs) || (count == 0));
    assert((sizes) || (count == 0));
    assert((bufs) || (count == 0));
    assert((count == 0) || (sizes[0] != 0));
    assert((count == 0) || (types[0] != H5FD_MEM_NOLIST));
    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        if (H5FD__mpio_vector_build_types(count, types, addrs, sizes, (H5_flexible_const_ptr_t *)bufs,
                                          &s_addrs, &s_sizes, NULL, (H5_flexible_const_ptr_t **)&s_bufs,
                                          &vector_was_sorted, &mpi_off,
                                          (H5_flexible_const_ptr_t *)&mpi_bufs_base, &size_i, &buf_type,
                                          &buf_type_created, &file_type, &file_type_created, &unused) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't build MPI datatypes for I/O");
        if (!vector_was_sorted)
            if (s_addrs) {
                free(s_addrs);
                s_addrs = NULL;
            }
        memset(&mpi_stat, 0, sizeof(mpi_stat));
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstdout, "%s: mpi_off = %ld  size_i = %d\n", __func__, (long)mpi_off, size_i);
#endif
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, file_type,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstdout, "%s: using MPIO collective mode\n", __func__);
#endif
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstdout, "%s: doing MPI collective IO\n", __func__);
#endif
            if (H5CX_get_mpio_rank0_bcast()) {
#ifdef H5FDmpio_DEBUG
                if (H5FD_mpio_debug_r_flag)
                    Rfprintf(Rstdout, "%s: doing read-rank0-and-MPI_Bcast\n", __func__);
#endif
                rank0_bcast = true;
                if (file->mpi_rank == 0)
                    if (MPI_SUCCESS != (mpi_code = MPI_File_read_at(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                    buf_type, &mpi_stat)))
                        HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at_all failed", mpi_code)
                if (MPI_SUCCESS != (mpi_code = MPI_Bcast(mpi_bufs_base, size_i, buf_type, 0, file->comm)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_code)
            }
            else if (MPI_SUCCESS != (mpi_code = MPI_File_read_at_all(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                     buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at_all failed", mpi_code)
        }
        else if (size_i > 0) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstdout, "%s: doing MPI independent IO\n", __func__);
#endif
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_read_at(file->f, mpi_off, mpi_bufs_base, size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at failed", mpi_code)
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
        if (!rank0_bcast || (rank0_bcast && file->mpi_rank == 0)) {
            if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, buf_type, &bytes_read)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code)
        }
        if (rank0_bcast)
            if (MPI_SUCCESS != MPI_Bcast(&bytes_read, 1, MPI_COUNT, 0, file->comm))
                HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", 0)
        if (MPI_SUCCESS != (mpi_code = MPI_Type_size_x(buf_type, &type_size)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_size failed", mpi_code)
        io_size = type_size * size_i;
        if (bytes_read < 0 || bytes_read > io_size)
            HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
        n = io_size - bytes_read;
        if (n > 0) {
            i = (int)count - 1;
            do {
                assert(i >= 0);
                io_size    = MIN(n, (MPI_Count)s_sizes[i]);
                bytes_read = (MPI_Count)s_sizes[i] - io_size;
                assert(bytes_read >= 0);
                memset((char *)s_bufs[i] + bytes_read, 0, (size_t)io_size);
                n -= io_size;
                i--;
            } while (n > 0);
        }
    }
    else if (count > 0) {
        haddr_t max_addr   = HADDR_MAX;
        bool    fixed_size = false;
        size_t  size;
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstdout, "%s: doing MPI independent IO\n", __func__);
#endif
        for (i = 0; i < (int)count; i++) {
            if (H5FD_mpi_haddr_to_MPIOff(addrs[i], &mpi_off) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
            if (!fixed_size) {
                if (sizes[i] == 0) {
                    fixed_size = true;
                    size       = sizes[i - 1];
                }
                else {
                    size = sizes[i];
                }
            }
            size_i = (int)size;
            if (size != (size_t)size_i) {
                if (H5_mpio_create_large_type(size, 0, MPI_BYTE, &buf_type) < 0)
                    HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
                buf_type_created = true;
                size_i           = 1;
            }
            if (addrs[i] < max_addr) {
                memset(&mpi_stat, 0, sizeof(mpi_stat));
                if (MPI_SUCCESS !=
                    (mpi_code = MPI_File_read_at(file->f, mpi_off, bufs[i], size_i, buf_type, &mpi_stat)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at failed", mpi_code)
                if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, MPI_BYTE, &bytes_read)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code)
                io_size = (MPI_Count)size;
                if (bytes_read < 0 || bytes_read > io_size)
                    HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
                if ((n = (io_size - bytes_read)) > 0) {
                    memset((char *)bufs[i] + bytes_read, 0, (size_t)n);
                    max_addr = addrs[i] + (haddr_t)bytes_read;
                }
            }
            else {
                memset((char *)bufs[i], 0, size);
            }
        }
    }
done:
    if (buf_type_created) {
        MPI_Type_free(&buf_type);
    }
    if (file_type_created) {
        MPI_Type_free(&file_type);
    }
    if (!vector_was_sorted) {
        if (s_addrs) {
            free(s_addrs);
            s_addrs = NULL;
        }
        if (s_sizes) {
            free(s_sizes);
            s_sizes = NULL;
        }
        if (s_bufs) {
            free(s_bufs);
            s_bufs = NULL;
        }
    }
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstdout, "%s: Leaving, proc %d: ret_value = %d\n", __func__, file->mpi_rank, ret_value);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_write_vector(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, uint32_t count, H5FD_mem_t types[],
                        haddr_t addrs[], size_t sizes[], const void *bufs[])
{
    H5FD_mpio_t               *file              = (H5FD_mpio_t *)_file;
    bool                       vector_was_sorted = true;
    haddr_t                   *s_addrs           = NULL;
    size_t                    *s_sizes           = NULL;
    const void               **s_bufs            = NULL;
    char                       unused            = 0;
    const void                *mpi_bufs_base     = NULL;
    MPI_Datatype               buf_type          = MPI_BYTE;
    bool                       buf_type_created  = false;
    MPI_Datatype               file_type         = MPI_BYTE;
    bool                       file_type_created = false;
    int                        i;
    int                        mpi_code;
    MPI_Offset                 mpi_off = 0;
    MPI_Status                 mpi_stat;
    H5FD_mpio_xfer_t           xfer_mode;
    H5FD_mpio_collective_opt_t coll_opt_mode;
    int                        size_i;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_w_flag = (H5FD_mpio_debug_flags_s[(int)'w'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    haddr_t max_addr  = 0;
    herr_t  ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert((types) || (count == 0));
    assert((addrs) || (count == 0));
    assert((sizes) || (count == 0));
    assert((bufs) || (count == 0));
    assert((count == 0) || (sizes[0] != 0));
    assert((count == 0) || (types[0] != H5FD_MEM_NOLIST));
    assert(!H5CX_get_mpi_file_flushing());
    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        uint32_t s_sizes_len;
        if (H5FD__mpio_vector_build_types(count, types, addrs, sizes, (H5_flexible_const_ptr_t *)bufs,
                                          &s_addrs, &s_sizes, &s_sizes_len,
                                          (H5_flexible_const_ptr_t **)&s_bufs, &vector_was_sorted, &mpi_off,
                                          (H5_flexible_const_ptr_t *)&mpi_bufs_base, &size_i, &buf_type,
                                          &buf_type_created, &file_type, &file_type_created, &unused) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't build MPI datatypes for I/O");
        if (count > 0)
            max_addr = s_addrs[count - 1] + (haddr_t)(s_sizes[s_sizes_len - 1]);
        if (!vector_was_sorted) {
            if (s_addrs) {
                free(s_addrs);
                s_addrs = NULL;
            }
            if (s_sizes) {
                free(s_sizes);
                s_sizes = NULL;
            }
            if (s_bufs) {
                free(s_bufs);
                s_bufs = NULL;
            }
        }
        memset(&mpi_stat, 0, sizeof(MPI_Status));
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstdout, "%s: mpi_off = %ld  size_i = %d\n", __func__, (long)mpi_off, size_i);
#endif
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, file_type,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstdout, "%s: using MPIO collective mode\n", __func__);
#endif
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstdout, "%s: doing MPI collective IO\n", __func__);
#endif
            if (MPI_SUCCESS != (mpi_code = MPI_File_write_at_all(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                 buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at_all failed", mpi_code)
            if (file->mpi_file_sync_required) {
                if (MPI_SUCCESS != (mpi_code = MPI_File_sync(file->f)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_sync failed", mpi_code)
            }
        }
        else if (size_i > 0) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstdout, "%s: doing MPI independent IO\n", __func__);
#endif
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_write_at(file->f, mpi_off, mpi_bufs_base, size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at failed", mpi_code)
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code)
    }
    else if (count > 0) {
        bool   fixed_size = false;
        size_t size;
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstdout, "%s: doing MPI independent IO\n", __func__);
#endif
        for (i = 0; i < (int)count; i++) {
            if (H5FD_mpi_haddr_to_MPIOff(addrs[i], &mpi_off) < 0)
                HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
            if (!fixed_size) {
                if (sizes[i] == 0) {
                    fixed_size = true;
                    size       = sizes[i - 1];
                }
                else {
                    size = sizes[i];
                }
            }
            size_i = (int)size;
            if (size != (size_t)size_i) {
                if (H5_mpio_create_large_type(size, 0, MPI_BYTE, &buf_type) < 0)
                    HGOTO_ERROR(H5E_INTERNAL, H5E_CANTGET, FAIL, "can't create MPI-I/O datatype");
                buf_type_created = true;
                size_i           = 1;
            }
            if (MPI_SUCCESS !=
                (mpi_code = MPI_File_write_at(file->f, mpi_off, bufs[i], size_i, buf_type, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at failed", mpi_code)
            if (addrs[i] + size > max_addr)
                max_addr = addrs[i] + size;
        }
    }
    file->eof = HADDR_UNDEF;
    if (max_addr > file->local_eof)
        file->local_eof = max_addr;
done:
    if (buf_type_created)
        MPI_Type_free(&buf_type);
    if (file_type_created)
        MPI_Type_free(&file_type);
    if (ret_value < 0 && !vector_was_sorted) {
        if (s_addrs) {
            free(s_addrs);
            s_addrs = NULL;
        }
        if (s_sizes) {
            free(s_sizes);
            s_sizes = NULL;
        }
        if (s_bufs) {
            free(s_bufs);
            s_bufs = NULL;
        }
    }
    assert(vector_was_sorted || !s_addrs);
    assert(vector_was_sorted || !s_sizes);
    assert(vector_was_sorted || !s_bufs);
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstdout, "%s: Leaving, proc %d: ret_value = %d\n", __func__, file->mpi_rank, ret_value);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__selection_build_types(bool io_op_write, size_t num_pieces, H5_flexible_const_ptr_t mbb,
                            H5S_t **file_spaces, H5S_t **mem_spaces, haddr_t offsets[],
                            H5_flexible_const_ptr_t bufs[], size_t src_element_sizes[],
                            size_t dst_element_sizes[], MPI_Datatype *final_ftype,
                            bool *final_ftype_is_derived, MPI_Datatype *final_mtype,
                            bool *final_mtype_is_derived)
{
    MPI_Datatype *piece_mtype           = NULL;
    MPI_Datatype *piece_ftype           = NULL;
    MPI_Aint     *piece_file_disp_array = NULL;
    MPI_Aint     *piece_mem_disp_array  = NULL;
    bool *piece_mft_is_derived_array = NULL;
    ;
    bool *piece_mmt_is_derived_array =
        NULL;
    int *piece_mpi_file_counts = NULL;
    int *piece_mpi_mem_counts  = NULL;
    haddr_t base_file_addr;
    size_t  i;
    int     mpi_code;
    bool                    extend_src_sizes = false;
    bool                    extend_dst_sizes = false;
    bool                    extend_bufs      = false;
    H5_flexible_const_ptr_t buf;
    size_t                  src_element_size, dst_element_size;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    if (NULL == (piece_mtype = (MPI_Datatype *)H5MM_malloc(num_pieces * sizeof(MPI_Datatype))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece memory datatype buffer");
    if (NULL == (piece_ftype = (MPI_Datatype *)H5MM_malloc(num_pieces * sizeof(MPI_Datatype))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece file datatype buffer");
    if (NULL == (piece_file_disp_array = (MPI_Aint *)H5MM_malloc(num_pieces * sizeof(MPI_Aint))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece file displacement buffer");
    if (NULL == (piece_mem_disp_array = (MPI_Aint *)H5MM_calloc(num_pieces * sizeof(MPI_Aint))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece memory displacement buffer");
    if (NULL == (piece_mpi_mem_counts = (int *)H5MM_calloc(num_pieces * sizeof(int))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece memory counts buffer");
    if (NULL == (piece_mpi_file_counts = (int *)H5MM_calloc(num_pieces * sizeof(int))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate piece file counts buffer");
    if (NULL == (piece_mmt_is_derived_array = (bool *)H5MM_calloc(num_pieces * sizeof(bool))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                    "couldn't allocate piece memory is derived datatype flags buffer");
    if (NULL == (piece_mft_is_derived_array = (bool *)H5MM_calloc(num_pieces * sizeof(bool))))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                    "couldn't allocate piece file is derived datatype flags buffer");
    base_file_addr = offsets[0];
    for (i = 0; i < num_pieces; i++) {
        hsize_t *permute_map = NULL;
        bool is_permuted = false;
        if (!extend_src_sizes) {
            if (src_element_sizes[i] == 0) {
                extend_src_sizes = true;
                src_element_size = src_element_sizes[i - 1];
            }
            else
                src_element_size = src_element_sizes[i];
        }
        if (!extend_dst_sizes) {
            if (dst_element_sizes[i] == 0) {
                extend_dst_sizes = true;
                dst_element_size = dst_element_sizes[i - 1];
            }
            else
                dst_element_size = src_element_sizes[i];
        }
        if (!extend_bufs) {
            if (bufs[i].cvp == NULL) {
                extend_bufs = true;
                buf         = bufs[i - 1];
            }
            else
                buf = bufs[i];
        }
        if (H5S_mpio_space_type(file_spaces[i], src_element_size, &piece_ftype[i],
                                &piece_mpi_file_counts[i],
                                &(piece_mft_is_derived_array[i]),
                                true,
                                &permute_map,
                                &is_permuted) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI file type");
        if (is_permuted)
            assert(permute_map);
        if (H5S_mpio_space_type(mem_spaces[i], dst_element_size, &piece_mtype[i], &piece_mpi_mem_counts[i],
                                &(piece_mmt_is_derived_array[i]), false,
                                &permute_map,
                                &is_permuted) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI buf type");
        if (is_permuted)
            assert(!permute_map);
        piece_file_disp_array[i] = (MPI_Aint)offsets[i] - (MPI_Aint)base_file_addr;
        if (io_op_write) {
            piece_mem_disp_array[i] = (MPI_Aint)buf.cvp - (MPI_Aint)mbb.cvp;
        }
        else {
            piece_mem_disp_array[i] = (MPI_Aint)buf.vp - (MPI_Aint)mbb.vp;
        }
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct((int)num_pieces, piece_mpi_file_counts,
                                                          piece_file_disp_array, piece_ftype, final_ftype)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code);
    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(final_ftype)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code);
    *final_ftype_is_derived = true;
    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct((int)num_pieces, piece_mpi_mem_counts,
                                                          piece_mem_disp_array, piece_mtype, final_mtype)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code);
    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(final_mtype)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code);
    *final_mtype_is_derived = true;
    for (i = 0; i < num_pieces; i++) {
        if (piece_mmt_is_derived_array[i])
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(piece_mtype + i)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
        if (piece_mft_is_derived_array[i])
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(piece_ftype + i)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
    }
done:
    if (piece_mtype)
        H5MM_xfree(piece_mtype);
    if (piece_ftype)
        H5MM_xfree(piece_ftype);
    if (piece_file_disp_array)
        H5MM_xfree(piece_file_disp_array);
    if (piece_mem_disp_array)
        H5MM_xfree(piece_mem_disp_array);
    if (piece_mpi_mem_counts)
        H5MM_xfree(piece_mpi_mem_counts);
    if (piece_mpi_file_counts)
        H5MM_xfree(piece_mpi_file_counts);
    if (piece_mmt_is_derived_array)
        H5MM_xfree(piece_mmt_is_derived_array);
    if (piece_mft_is_derived_array)
        H5MM_xfree(piece_mft_is_derived_array);
    FUNC_LEAVE_NOAPI(ret_value);
}
static herr_t
H5FD__mpio_read_selection(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id, size_t count,
                          hid_t mem_space_ids[], hid_t file_space_ids[], haddr_t offsets[],
                          size_t element_sizes[], void *bufs[])
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
    MPI_Offset   mpi_off;
    MPI_Status   mpi_stat;
    int          size_i;
    H5FD_mpio_xfer_t           xfer_mode;
    H5FD_mpio_collective_opt_t coll_opt_mode;
    MPI_Datatype final_mtype;
    bool         final_mtype_is_derived = false;
    MPI_Datatype final_ftype;
    bool         final_ftype_is_derived = false;
    hid_t                   *s_mem_space_ids      = NULL;
    hid_t                   *s_file_space_ids     = NULL;
    haddr_t                 *s_offsets            = NULL;
    size_t                  *s_element_sizes      = NULL;
    H5_flexible_const_ptr_t *s_bufs               = NULL;
    bool                     selection_was_sorted = true;
    uint32_t i, j;
    H5S_t  **s_mem_spaces  = NULL;
    H5S_t  **s_file_spaces = NULL;
    haddr_t  tmp_offset    = 0;
    void    *mpi_bufs_base = NULL;
    char     unused        = 0;
    MPI_Count bytes_read = 0;
    MPI_Count type_size;
    MPI_Count io_size;
    MPI_Count n;
    bool      rank0_bcast = false;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_r_flag = (H5FD_mpio_debug_flags_s[(int)'r'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int                     mpi_code;
    H5_flexible_const_ptr_t mbb;
    herr_t                  ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert((count == 0) || (mem_space_ids));
    assert((count == 0) || (file_space_ids));
    assert((count == 0) || (offsets));
    assert((count == 0) || (element_sizes));
    assert((count == 0) || (bufs));
    assert((count == 0) || (element_sizes[0] != 0));
    assert((count == 0) || (bufs[0] != NULL));
    memset(&mpi_stat, 0, sizeof(MPI_Status));
    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        if (count) {
            if (H5FD_sort_selection_io_req(&selection_was_sorted, count, mem_space_ids, file_space_ids,
                                           offsets, element_sizes, (H5_flexible_const_ptr_t *)bufs,
                                           &s_mem_space_ids, &s_file_space_ids, &s_offsets, &s_element_sizes,
                                           &s_bufs) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "can't sort selection I/O request");
            tmp_offset = s_offsets[0];
            if (NULL == (s_file_spaces = H5MM_malloc(count * sizeof(H5S_t *))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "memory allocation failed for file space list");
            if (NULL == (s_mem_spaces = H5MM_malloc(count * sizeof(H5S_t *))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "memory allocation failed for memory space list");
            for (i = 0; i < count; i++) {
                if (NULL == (s_mem_spaces[i] = (H5S_t *)H5I_object_verify(s_mem_space_ids[i], H5I_DATASPACE)))
                    HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, H5I_INVALID_HID,
                                "can't retrieve memory dataspace from ID");
                if (NULL ==
                    (s_file_spaces[i] = (H5S_t *)H5I_object_verify(s_file_space_ids[i], H5I_DATASPACE)))
                    HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, H5I_INVALID_HID,
                                "can't retrieve file dataspace from ID");
            }
            j = 0;
            if ((count > 1) && (s_bufs[1].vp != NULL)) {
                for (i = 1; i < count; i++)
                    if (s_bufs[i].vp < s_bufs[j].vp)
                        j = i;
            }
            mpi_bufs_base = s_bufs[j].vp;
            mbb.vp        = mpi_bufs_base;
            if (H5FD__selection_build_types(false, count, mbb, s_file_spaces, s_mem_spaces, s_offsets, s_bufs,
                                            s_element_sizes, s_element_sizes, &final_ftype,
                                            &final_ftype_is_derived, &final_mtype,
                                            &final_mtype_is_derived) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "couldn't build type for MPI-IO");
            size_i = 1;
        }
        else {
            size_i = 0;
            mpi_bufs_base = &unused;
            final_ftype = MPI_BYTE;
            final_mtype = MPI_BYTE;
        }
        if (H5FD_mpi_haddr_to_MPIOff(tmp_offset, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, final_ftype,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code);
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstderr, "%s: (%d) using MPIO collective mode\n", __func__, file->mpi_rank);
#endif
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI collective IO\n", __func__, file->mpi_rank);
#endif
            if (H5CX_get_mpio_rank0_bcast()) {
#ifdef H5FDmpio_DEBUG
                if (H5FD_mpio_debug_r_flag)
                    Rfprintf(Rstderr, "%s: (%d) doing read-rank0-and-MPI_Bcast\n", __func__, file->mpi_rank);
#endif
                rank0_bcast = true;
                if (file->mpi_rank == 0) {
                    if (MPI_SUCCESS != (mpi_code = MPI_File_read_at(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                    final_mtype, &mpi_stat)))
                        HMPI_DONE_ERROR(FAIL, "MPI_File_read_at failed", mpi_code);
                }
                if (MPI_SUCCESS != (mpi_code = MPI_Bcast(mpi_bufs_base, size_i, final_mtype, 0, file->comm)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_code);
            }
            else
                if (MPI_SUCCESS != (mpi_code = MPI_File_read_at_all(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                    final_mtype, &mpi_stat)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at_all failed", mpi_code);
        }
        else {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_r_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS != (mpi_code = MPI_File_read_at(file->f, mpi_off, mpi_bufs_base, size_i,
                                                            final_mtype, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_read_at failed", mpi_code);
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code);
        if (!rank0_bcast || (rank0_bcast && file->mpi_rank == 0)) {
            if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, final_mtype, &bytes_read))) {
                if (rank0_bcast && file->mpi_rank == 0) {
                    bytes_read = -1;
                    HMPI_DONE_ERROR(FAIL, "MPI_Get_elements failed", mpi_code);
                }
                else
                    HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code);
            }
        }
        if (rank0_bcast)
            if (MPI_SUCCESS != MPI_Bcast(&bytes_read, 1, MPI_COUNT, 0, file->comm))
                HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", 0);
        if (MPI_SUCCESS != (mpi_code = MPI_Type_size_x(final_mtype, &type_size)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_size failed", mpi_code);
        io_size = type_size * size_i;
        if (bytes_read < 0 || bytes_read > io_size)
            HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "file read failed");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstderr, "%s: (%d) mpi_off = %ld  bytes_read = %lld  type = %s\n", __func__,
                    file->mpi_rank, (long)mpi_off, (long long)bytes_read, H5FD__mem_t_to_str(type));
#endif
        if ((n = (io_size - bytes_read)) > 0)
            memset((char *)bufs[0] + bytes_read, 0, (size_t)n);
    }
    else {
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_r_flag)
            Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
        if (_file->base_addr > 0) {
            for (i = 0; i < count; i++) {
                assert(offsets[i] >= _file->base_addr);
                offsets[i] -= _file->base_addr;
            }
        }
        if (H5FD_read_from_selection(_file, type, (uint32_t)count, mem_space_ids, file_space_ids, offsets,
                                     element_sizes, bufs) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_READERROR, FAIL, "read vector from selection failed");
    }
done:
    if (final_mtype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&final_mtype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
    if (final_ftype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&final_ftype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
    if (s_mem_spaces)
        s_mem_spaces = H5MM_xfree(s_mem_spaces);
    if (s_file_spaces)
        s_file_spaces = H5MM_xfree(s_file_spaces);
    if (!selection_was_sorted) {
        free(s_mem_space_ids);
        s_mem_space_ids = NULL;
        free(s_file_space_ids);
        s_file_space_ids = NULL;
        free(s_offsets);
        s_offsets = NULL;
        free(s_element_sizes);
        s_element_sizes = NULL;
        free(s_bufs);
        s_bufs = NULL;
    }
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_write_selection(H5FD_t *_file, H5FD_mem_t type, hid_t H5_ATTR_UNUSED dxpl_id, size_t count,
                           hid_t mem_space_ids[], hid_t file_space_ids[], haddr_t offsets[],
                           size_t element_sizes[], const void *bufs[])
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
    MPI_Offset   mpi_off;
    MPI_Offset   save_mpi_off;
    MPI_Status   mpi_stat;
    int                        size_i;
    H5FD_mpio_xfer_t           xfer_mode;
    H5FD_mpio_collective_opt_t coll_opt_mode;
    MPI_Datatype final_mtype;
    bool         final_mtype_is_derived = false;
    MPI_Datatype final_ftype;
    bool         final_ftype_is_derived = false;
    hid_t                   *s_mem_space_ids      = NULL;
    hid_t                   *s_file_space_ids     = NULL;
    haddr_t                 *s_offsets            = NULL;
    size_t                  *s_element_sizes      = NULL;
    H5_flexible_const_ptr_t *s_bufs               = NULL;
    bool                     selection_was_sorted = true;
    const void              *mpi_bufs_base        = NULL;
    uint32_t                i, j;
    H5S_t                 **s_mem_spaces  = NULL;
    H5S_t                 **s_file_spaces = NULL;
    haddr_t                 tmp_offset    = 0;
    char                    unused        = 0;
    H5_flexible_const_ptr_t mbb;
    MPI_Count bytes_written;
    MPI_Count type_size;
    MPI_Count io_size;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
    bool H5FD_mpio_debug_w_flag = (H5FD_mpio_debug_flags_s[(int)'w'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    assert((count == 0) || (mem_space_ids));
    assert((count == 0) || (file_space_ids));
    assert((count == 0) || (offsets));
    assert((count == 0) || (element_sizes));
    assert((count == 0) || (bufs));
    assert((count == 0) || (element_sizes[0] != 0));
    assert((count == 0) || (bufs[0] != NULL));
    assert(!H5CX_get_mpi_file_flushing());
    memset(&mpi_stat, 0, sizeof(MPI_Status));
    if (H5CX_get_io_xfer_mode(&xfer_mode) < 0)
        HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O transfer mode");
    if (xfer_mode == H5FD_MPIO_COLLECTIVE) {
        if (count) {
            if (H5FD_sort_selection_io_req(&selection_was_sorted, count, mem_space_ids, file_space_ids,
                                           offsets, element_sizes, (H5_flexible_const_ptr_t *)bufs,
                                           &s_mem_space_ids, &s_file_space_ids, &s_offsets, &s_element_sizes,
                                           &s_bufs) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_BADVALUE, FAIL, "can't sort selection I/O request");
            tmp_offset = s_offsets[0];
            if (NULL == (s_file_spaces = H5MM_malloc(count * sizeof(H5S_t *))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "memory allocation failed for file space list");
            if (NULL == (s_mem_spaces = H5MM_malloc(count * sizeof(H5S_t *))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "memory allocation failed for memory space list");
            for (i = 0; i < count; i++) {
                if (NULL ==
                    (s_file_spaces[i] = (H5S_t *)H5I_object_verify(s_file_space_ids[i], H5I_DATASPACE)))
                    HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, H5I_INVALID_HID,
                                "can't retrieve file dataspace from ID");
                if (NULL == (s_mem_spaces[i] = (H5S_t *)H5I_object_verify(s_mem_space_ids[i], H5I_DATASPACE)))
                    HGOTO_ERROR(H5E_VFL, H5E_BADTYPE, H5I_INVALID_HID,
                                "can't retrieve memory dataspace from ID");
            }
            j = 0;
            if ((count > 1) && (s_bufs[1].cvp != NULL)) {
                for (i = 1; i < count; i++)
                    if (s_bufs[i].cvp < s_bufs[j].cvp)
                        j = i;
            }
            mpi_bufs_base = s_bufs[j].cvp;
            mbb.cvp       = mpi_bufs_base;
            if (H5FD__selection_build_types(true, count, mbb, s_file_spaces, s_mem_spaces, s_offsets, s_bufs,
                                            s_element_sizes, s_element_sizes, &final_ftype,
                                            &final_ftype_is_derived, &final_mtype,
                                            &final_mtype_is_derived) < 0)
                HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "couldn't build type for MPI-IO");
            size_i = 1;
        }
        else {
            size_i = 0;
            mpi_bufs_base = &unused;
            final_ftype = MPI_BYTE;
            final_mtype = MPI_BYTE;
        }
        if (H5FD_mpi_haddr_to_MPIOff(tmp_offset, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't convert from haddr to MPI off");
        save_mpi_off = mpi_off;
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, mpi_off, MPI_BYTE, final_ftype,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code);
        if (H5FD_mpi_haddr_to_MPIOff((haddr_t)0, &mpi_off) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "can't set MPI off to 0");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstderr, "%s: (%d) using MPIO collective mode\n", __func__, file->mpi_rank);
#endif
        if (H5CX_get_mpio_coll_opt(&coll_opt_mode) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");
        if (coll_opt_mode == H5FD_MPIO_COLLECTIVE_IO) {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI collective IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS != (mpi_code = MPI_File_write_at_all(file->f, mpi_off, mpi_bufs_base, size_i,
                                                                 final_mtype, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at_all failed", mpi_code);
            if (file->mpi_file_sync_required) {
                if (MPI_SUCCESS != (mpi_code = MPI_File_sync(file->f)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_File_sync failed", mpi_code);
            }
        }
        else {
#ifdef H5FDmpio_DEBUG
            if (H5FD_mpio_debug_w_flag)
                Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
            if (MPI_SUCCESS != (mpi_code = MPI_File_write_at(file->f, mpi_off, mpi_bufs_base, size_i,
                                                             final_mtype, &mpi_stat)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_write_at failed", mpi_code);
        }
        if (MPI_SUCCESS != (mpi_code = MPI_File_set_view(file->f, (MPI_Offset)0, MPI_BYTE, MPI_BYTE,
                                                         H5FD_mpi_native_g, file->info)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_set_view failed", mpi_code);
        if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&mpi_stat, final_mtype, &bytes_written)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements failed", mpi_code);
        if (MPI_SUCCESS != (mpi_code = MPI_Type_size_x(final_mtype, &type_size)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_size failed", mpi_code);
        io_size = type_size * size_i;
        if (bytes_written != io_size || bytes_written < 0)
            HGOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "file write failed");
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstderr, "%s: (%d) mpi_off = %ld  bytes_written = %lld  type = %s\n", __func__,
                    file->mpi_rank, (long)mpi_off, (long long)bytes_written, H5FD__mem_t_to_str(type));
#endif
        file->eof = HADDR_UNDEF;
        if (bytes_written && (((haddr_t)bytes_written + (haddr_t)save_mpi_off) > file->local_eof))
            file->local_eof = (haddr_t)save_mpi_off + (haddr_t)bytes_written;
    }
    else {
#ifdef H5FDmpio_DEBUG
        if (H5FD_mpio_debug_w_flag)
            Rfprintf(Rstderr, "%s: (%d) doing MPI independent IO\n", __func__, file->mpi_rank);
#endif
        if (_file->base_addr > 0) {
            for (i = 0; i < count; i++) {
                assert(offsets[i] >= _file->base_addr);
                offsets[i] -= _file->base_addr;
            }
        }
        if (H5FD_write_from_selection(_file, type, (uint32_t)count, mem_space_ids, file_space_ids, offsets,
                                      element_sizes, bufs) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_WRITEERROR, FAIL, "write vector from selection failed");
    }
done:
    if (final_mtype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&final_mtype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
    if (final_ftype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&final_ftype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code);
    if (s_mem_spaces)
        s_mem_spaces = H5MM_xfree(s_mem_spaces);
    if (s_file_spaces)
        s_file_spaces = H5MM_xfree(s_file_spaces);
    if (!selection_was_sorted) {
        free(s_mem_space_ids);
        s_mem_space_ids = NULL;
        free(s_file_space_ids);
        s_file_space_ids = NULL;
        free(s_offsets);
        s_offsets = NULL;
        free(s_element_sizes);
        s_element_sizes = NULL;
        free(s_bufs);
        s_bufs = NULL;
    }
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving: ret_value = %d\n", __func__, file->mpi_rank, ret_value);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_flush(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, bool closing)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    int    mpi_code;
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    if (!closing)
        if (MPI_SUCCESS != (mpi_code = MPI_File_sync(file->f)))
            HMPI_GOTO_ERROR(FAIL, "MPI_File_sync failed", mpi_code)
done:
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_truncate(H5FD_t *_file, hid_t H5_ATTR_UNUSED dxpl_id, bool H5_ATTR_UNUSED closing)
{
    H5FD_mpio_t *file = (H5FD_mpio_t *)_file;
#ifdef H5FDmpio_DEBUG
    bool H5FD_mpio_debug_t_flag = (H5FD_mpio_debug_flags_s[(int)'t'] && H5FD_MPIO_TRACE_THIS_RANK(file));
#endif
    herr_t ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Entering\n", __func__, file->mpi_rank);
#endif
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    if (!H5_addr_eq(file->eoa, file->last_eoa)) {
        int        mpi_code;
        MPI_Offset size;
        MPI_Offset needed_eof;
        if (!H5CX_get_mpi_file_flushing())
            if (MPI_SUCCESS != (mpi_code = MPI_Barrier(file->comm)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_code)
        if (0 == file->mpi_rank) {
            if (MPI_SUCCESS != (mpi_code = MPI_File_get_size(file->f, &size)))
                size = (MPI_Offset)-1;
        }
        if (MPI_SUCCESS != (mpi_code = MPI_Bcast(&size, (int)sizeof(MPI_Offset), MPI_BYTE, 0, file->comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_code)
        if (size < 0)
            HMPI_GOTO_ERROR(FAIL, "MPI_File_get_size failed", mpi_code)
        if (H5FD_mpi_haddr_to_MPIOff(file->eoa, &needed_eof) < 0)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL, "cannot convert from haddr_t to MPI_Offset");
        if (size != needed_eof) {
            if (MPI_SUCCESS != (mpi_code = MPI_File_set_size(file->f, needed_eof)))
                HMPI_GOTO_ERROR(FAIL, "MPI_File_set_size failed", mpi_code)
            if (MPI_SUCCESS != (mpi_code = MPI_Barrier(file->comm)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_code)
        }
        file->last_eoa = file->eoa;
    }
done:
#ifdef H5FDmpio_DEBUG
    if (H5FD_mpio_debug_t_flag)
        Rfprintf(Rstderr, "%s: (%d) Leaving\n", __func__, file->mpi_rank);
#endif
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_delete(const char *filename, hid_t fapl_id)
{
    H5P_genplist_t *plist;
    MPI_Comm        comm     = MPI_COMM_NULL;
    MPI_Info        info     = MPI_INFO_NULL;
    int             mpi_rank = INT_MAX;
    int             mpi_code;
    herr_t          ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    assert(filename);
    if (!H5FD_mpio_init_s)
        if (H5FD__mpio_init() < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTINIT, FAIL, "can't initialize driver");
    if (NULL == (plist = H5P_object_verify(fapl_id, H5P_FILE_ACCESS, true)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a file access property list");
    assert(H5FD_MPIO == H5P_peek_driver(plist));
    if (H5FD_mpi_self_initialized_s) {
        comm = MPI_COMM_WORLD;
    }
    else {
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_INFO_NAME, &info) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI info object");
        if (H5P_get(plist, H5F_ACS_MPI_PARAMS_COMM_NAME, &comm) < 0)
            HGOTO_ERROR(H5E_VFL, H5E_CANTGET, FAIL, "can't get MPI communicator");
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Comm_rank(comm, &mpi_rank)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Comm_rank failed", mpi_code)
    if (MPI_SUCCESS != (mpi_code = MPI_Barrier(comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_code)
    if (mpi_rank == 0) {
        if (MPI_SUCCESS != (mpi_code = MPI_File_delete(filename, info)))
            HMPI_DONE_ERROR(FAIL, "MPI_File_delete failed", mpi_code)
    }
    if (MPI_SUCCESS != (mpi_code = MPI_Barrier(comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_code)
done:
    if (H5_mpi_comm_free(&comm) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "unable to free MPI communicator");
    if (H5_mpi_info_free(&info) < 0)
        HDONE_ERROR(H5E_VFL, H5E_CANTFREE, FAIL, "unable to free MPI info object");
    FUNC_LEAVE_NOAPI(ret_value)
}
static herr_t
H5FD__mpio_ctl(H5FD_t *_file, uint64_t op_code, uint64_t flags, const void H5_ATTR_UNUSED *input,
               void **output)
{
    H5FD_mpio_t *file      = (H5FD_mpio_t *)_file;
    herr_t       ret_value = SUCCEED;
    FUNC_ENTER_PACKAGE
    assert(file);
    assert(H5FD_MPIO == file->pub.driver_id);
    switch (op_code) {
        case H5FD_CTL_GET_MPI_COMMUNICATOR_OPCODE:
            assert(output);
            assert(*output);
            **((MPI_Comm **)output) = file->comm;
            break;
        case H5FD_CTL_GET_MPI_INFO_OPCODE:
            assert(output);
            assert(*output);
            **((MPI_Info **)output) = file->info;
            break;
        case H5FD_CTL_GET_MPI_RANK_OPCODE:
            assert(output);
            assert(*output);
            **((int **)output) = file->mpi_rank;
            break;
        case H5FD_CTL_GET_MPI_SIZE_OPCODE:
            assert(output);
            assert(*output);
            **((int **)output) = file->mpi_size;
            break;
        case H5FD_CTL_GET_MPI_FILE_SYNC_OPCODE:
            assert(output);
            assert(*output);
            **((bool **)output) = file->mpi_file_sync_required;
            break;
        default:
            if (flags & H5FD_CTL_FAIL_IF_UNKNOWN_FLAG) {
                HGOTO_ERROR(H5E_VFL, H5E_FCNTL, FAIL, "unknown op_code and fail if unknown");
            }
            break;
    }
done:
    FUNC_LEAVE_NOAPI(ret_value)
}
#endif
