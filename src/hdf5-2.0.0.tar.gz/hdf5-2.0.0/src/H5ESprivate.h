/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5ESprivate_H
#define H5ESprivate_H

#include "H5ESpublic.h"
#include "H5ESdevelop.h"

#include "H5VLprivate.h"

typedef struct H5ES_t H5ES_t;

herr_t H5ES_insert(hid_t es_id, H5VL_connector_t *connector, void *token, const char *caller,
                   const char *caller_args, ...);

#endif
