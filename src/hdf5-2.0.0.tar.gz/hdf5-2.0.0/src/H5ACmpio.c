/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5ACmodule.h"
#define H5F_FRIEND

#include "H5private.h"
#include "H5ACpkg.h"
#include "H5Cprivate.h"
#include "H5CXprivate.h"
#include "H5Eprivate.h"
#include "H5FLprivate.h"
#include "H5Fpkg.h"
#include "H5MMprivate.h"
#include "H5SLprivate.h"

#ifdef H5_HAVE_PARALLEL

typedef struct H5AC_slist_entry_t {
    haddr_t addr;
} H5AC_slist_entry_t;

typedef struct H5AC_addr_list_ud_t {
    H5AC_aux_t *aux_ptr;
    haddr_t    *addr_buf_ptr;
    unsigned    u;
} H5AC_addr_list_ud_t;

static herr_t H5AC__broadcast_candidate_list(H5AC_t *cache_ptr, unsigned *num_entries_ptr,
                                             haddr_t **haddr_buf_ptr_ptr);
static herr_t H5AC__broadcast_clean_list(H5AC_t *cache_ptr);
static herr_t H5AC__construct_candidate_list(H5AC_t *cache_ptr, H5AC_aux_t *aux_ptr, int sync_point_op);
static herr_t H5AC__copy_candidate_list_to_buffer(const H5AC_t *cache_ptr, unsigned *num_entries_ptr,
                                                  haddr_t **haddr_buf_ptr_ptr);
static herr_t H5AC__propagate_and_apply_candidate_list(H5F_t *f);
static herr_t H5AC__propagate_flushed_and_still_clean_entries_list(H5F_t *f);
static herr_t H5AC__receive_haddr_list(MPI_Comm mpi_comm, unsigned *num_entries_ptr,
                                       haddr_t **haddr_buf_ptr_ptr);
static herr_t H5AC__receive_candidate_list(const H5AC_t *cache_ptr, unsigned *num_entries_ptr,
                                           haddr_t **haddr_buf_ptr_ptr);
static herr_t H5AC__receive_and_apply_clean_list(H5F_t *f);
static herr_t H5AC__tidy_cache_0_lists(H5AC_t *cache_ptr, unsigned num_candidates,
                                       haddr_t *candidates_list_ptr);
static herr_t H5AC__rsp__dist_md_write__flush(H5F_t *f);
static herr_t H5AC__rsp__dist_md_write__flush_to_min_clean(H5F_t *f);
static herr_t H5AC__rsp__p0_only__flush(H5F_t *f);
static herr_t H5AC__rsp__p0_only__flush_to_min_clean(H5F_t *f);

H5FL_DEFINE(H5AC_aux_t);

H5FL_DEFINE_STATIC(H5AC_slist_entry_t);

herr_t
H5AC__set_sync_point_done_callback(H5C_t *cache_ptr, H5AC_sync_point_done_cb_t sync_point_done)
{
    H5AC_aux_t *aux_ptr;

    FUNC_ENTER_PACKAGE_NOERR

    assert(cache_ptr);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    aux_ptr->sync_point_done = sync_point_done;

    FUNC_LEAVE_NOAPI(SUCCEED)
}

herr_t
H5AC__set_write_done_callback(H5C_t *cache_ptr, H5AC_write_done_cb_t write_done)
{
    H5AC_aux_t *aux_ptr;

    FUNC_ENTER_PACKAGE_NOERR

    assert(cache_ptr);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    aux_ptr->write_done = write_done;

    FUNC_LEAVE_NOAPI(SUCCEED)
}

herr_t
H5AC_add_candidate(H5AC_t *cache_ptr, haddr_t addr)
{
    H5AC_aux_t         *aux_ptr;
    H5AC_slist_entry_t *slist_entry_ptr = NULL;
    herr_t              ret_value       = SUCCEED;

    FUNC_ENTER_NOAPI(FAIL)

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert(aux_ptr->candidate_slist_ptr != NULL);

    if (NULL == (slist_entry_ptr = H5FL_MALLOC(H5AC_slist_entry_t)))
        HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "Can't allocate candidate slist entry");
    slist_entry_ptr->addr = addr;

    if (H5SL_insert(aux_ptr->candidate_slist_ptr, slist_entry_ptr, &(slist_entry_ptr->addr)) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTINSERT, FAIL, "can't insert entry into dirty entry slist");

done:

    if (ret_value < 0)
        if (slist_entry_ptr)
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__broadcast_candidate_list(H5AC_t *cache_ptr, unsigned *num_entries_ptr, haddr_t **haddr_buf_ptr_ptr)
{
    H5AC_aux_t *aux_ptr       = NULL;
    haddr_t    *haddr_buf_ptr = NULL;
    int         mpi_result;
    unsigned    num_entries;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank == 0);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert(aux_ptr->candidate_slist_ptr != NULL);
    assert(num_entries_ptr != NULL);
    assert(*num_entries_ptr == 0);
    assert(haddr_buf_ptr_ptr != NULL);
    assert(*haddr_buf_ptr_ptr == NULL);

    num_entries = (unsigned)H5SL_count(aux_ptr->candidate_slist_ptr);
    if (MPI_SUCCESS != (mpi_result = MPI_Bcast(&num_entries, 1, MPI_UNSIGNED, 0, aux_ptr->mpi_comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)

    if (num_entries > 0) {
        size_t   buf_size        = 0;
        unsigned chk_num_entries = 0;

        if (H5AC__copy_candidate_list_to_buffer(cache_ptr, &chk_num_entries, &haddr_buf_ptr) < 0) {

            HDONE_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't construct candidate buffer.");
        }
        assert(chk_num_entries == num_entries);
        assert(haddr_buf_ptr != NULL);

        buf_size = sizeof(haddr_t) * num_entries;
        if (MPI_SUCCESS !=
            (mpi_result = MPI_Bcast((void *)haddr_buf_ptr, (int)buf_size, MPI_BYTE, 0, aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)
    }

    *num_entries_ptr   = num_entries;
    *haddr_buf_ptr_ptr = haddr_buf_ptr;

done:
    if (ret_value < 0)
        if (haddr_buf_ptr)
            haddr_buf_ptr = (haddr_t *)H5MM_xfree((void *)haddr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__broadcast_clean_list_cb(void *_item, void H5_ATTR_UNUSED *_key, void *_udata)
{
    H5AC_slist_entry_t  *slist_entry_ptr = (H5AC_slist_entry_t *)_item;
    H5AC_addr_list_ud_t *udata           = (H5AC_addr_list_ud_t *)_udata;
    haddr_t              addr;

    FUNC_ENTER_PACKAGE_NOERR

    assert(slist_entry_ptr);
    assert(udata);

    addr                          = slist_entry_ptr->addr;
    udata->addr_buf_ptr[udata->u] = addr;
    udata->u++;

    slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    if (NULL !=
        (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(udata->aux_ptr->d_slist_ptr, (void *)(&addr))))
        slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static herr_t
H5AC__broadcast_clean_list(H5AC_t *cache_ptr)
{
    haddr_t    *addr_buf_ptr = NULL;
    H5AC_aux_t *aux_ptr;
    int         mpi_result;
    unsigned    num_entries = 0;
    herr_t      ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank == 0);
    assert(aux_ptr->c_slist_ptr != NULL);

    num_entries = (unsigned)H5SL_count(aux_ptr->c_slist_ptr);
    if (MPI_SUCCESS != (mpi_result = MPI_Bcast(&num_entries, 1, MPI_UNSIGNED, 0, aux_ptr->mpi_comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)

    if (num_entries > 0) {
        H5AC_addr_list_ud_t udata;
        size_t              buf_size;

        buf_size = sizeof(haddr_t) * num_entries;
        if (NULL == (addr_buf_ptr = (haddr_t *)H5MM_malloc(buf_size))) {

            HDONE_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "memory allocation failed for addr buffer");
        }
        else {

            udata.aux_ptr      = aux_ptr;
            udata.addr_buf_ptr = addr_buf_ptr;
            udata.u            = 0;

            if (H5SL_free(aux_ptr->c_slist_ptr, H5AC__broadcast_clean_list_cb, &udata) < 0) {

                HDONE_ERROR(H5E_CACHE, H5E_CANTFREE, FAIL, "Can't build address list for clean entries");
            }
        }

        if (MPI_SUCCESS !=
            (mpi_result = MPI_Bcast((void *)addr_buf_ptr, (int)buf_size, MPI_BYTE, 0, aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)
    }

    if (aux_ptr->sync_point_done)
        (aux_ptr->sync_point_done)(num_entries, addr_buf_ptr);

done:
    if (addr_buf_ptr)
        addr_buf_ptr = (haddr_t *)H5MM_xfree((void *)addr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__construct_candidate_list(H5AC_t *cache_ptr, H5AC_aux_t H5_ATTR_NDEBUG_UNUSED *aux_ptr,
                               int sync_point_op)
{
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert((sync_point_op == H5AC_SYNC_POINT_OP__FLUSH_CACHE) || (aux_ptr->mpi_rank == 0));
    assert(aux_ptr->d_slist_ptr != NULL);
    assert(aux_ptr->c_slist_ptr != NULL);
    assert(H5SL_count(aux_ptr->c_slist_ptr) == 0);
    assert(aux_ptr->candidate_slist_ptr != NULL);
    assert(H5SL_count(aux_ptr->candidate_slist_ptr) == 0);
    assert((sync_point_op == H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN) ||
           (sync_point_op == H5AC_SYNC_POINT_OP__FLUSH_CACHE));

    switch (sync_point_op) {
        case H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN:
            if (H5C_construct_candidate_list__min_clean((H5C_t *)cache_ptr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "H5C_construct_candidate_list__min_clean() failed.");
            break;

        case H5AC_SYNC_POINT_OP__FLUSH_CACHE:
            if (H5C_construct_candidate_list__clean_cache((H5C_t *)cache_ptr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL,
                            "H5C_construct_candidate_list__clean_cache() failed.");
            break;

        default:
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "unknown sync point operation.");
            break;
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__copy_candidate_list_to_buffer_cb(void *_item, void H5_ATTR_UNUSED *_key, void *_udata)
{
    H5AC_slist_entry_t  *slist_entry_ptr = (H5AC_slist_entry_t *)_item;
    H5AC_addr_list_ud_t *udata           = (H5AC_addr_list_ud_t *)_udata;

    FUNC_ENTER_PACKAGE_NOERR

    assert(slist_entry_ptr);
    assert(udata);

    udata->addr_buf_ptr[udata->u] = slist_entry_ptr->addr;
    udata->u++;

    slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    FUNC_LEAVE_NOAPI(SUCCEED)
}

static herr_t
H5AC__copy_candidate_list_to_buffer(const H5AC_t *cache_ptr, unsigned *num_entries_ptr,
                                    haddr_t **haddr_buf_ptr_ptr)
{
    H5AC_aux_t         *aux_ptr = NULL;
    H5AC_addr_list_ud_t udata;
    haddr_t            *haddr_buf_ptr = NULL;
    size_t              buf_size;
    unsigned            num_entries = 0;
    herr_t              ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert(aux_ptr->candidate_slist_ptr != NULL);
    assert(H5SL_count(aux_ptr->candidate_slist_ptr) > 0);
    assert(num_entries_ptr != NULL);
    assert(*num_entries_ptr == 0);
    assert(haddr_buf_ptr_ptr != NULL);
    assert(*haddr_buf_ptr_ptr == NULL);

    num_entries = (unsigned)H5SL_count(aux_ptr->candidate_slist_ptr);

    buf_size = sizeof(haddr_t) * num_entries;
    if (NULL == (haddr_buf_ptr = (haddr_t *)H5MM_malloc(buf_size)))
        HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "memory allocation failed for haddr buffer");

    udata.aux_ptr      = aux_ptr;
    udata.addr_buf_ptr = haddr_buf_ptr;
    udata.u            = 0;

    if (H5SL_free(aux_ptr->candidate_slist_ptr, H5AC__copy_candidate_list_to_buffer_cb, &udata) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTFREE, FAIL, "Can't build address list for candidate entries");

    *num_entries_ptr   = num_entries;
    *haddr_buf_ptr_ptr = haddr_buf_ptr;

done:
    if (ret_value < 0)
        if (haddr_buf_ptr)
            haddr_buf_ptr = (haddr_t *)H5MM_xfree((void *)haddr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5AC__log_deleted_entry(const H5AC_info_t *entry_ptr)
{
    H5AC_t             *cache_ptr;
    H5AC_aux_t         *aux_ptr;
    H5AC_slist_entry_t *slist_entry_ptr = NULL;
    haddr_t             addr;

    FUNC_ENTER_PACKAGE_NOERR

    assert(entry_ptr);
    addr      = entry_ptr->addr;
    cache_ptr = entry_ptr->cache_ptr;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank == 0);
    assert(aux_ptr->d_slist_ptr != NULL);
    assert(aux_ptr->c_slist_ptr != NULL);

    if (NULL != (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->d_slist_ptr, (void *)(&addr))))
        slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    if (NULL != (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)(&addr))))
        slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    FUNC_LEAVE_NOAPI(SUCCEED)
}

herr_t
H5AC__log_dirtied_entry(const H5AC_info_t *entry_ptr)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(entry_ptr);
    assert(entry_ptr->is_dirty == false);
    cache_ptr = entry_ptr->cache_ptr;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    if (aux_ptr->mpi_rank == 0) {
        H5AC_slist_entry_t *slist_entry_ptr;
        haddr_t             addr = entry_ptr->addr;

        assert(aux_ptr->d_slist_ptr != NULL);
        assert(aux_ptr->c_slist_ptr != NULL);

        if (NULL == H5SL_search(aux_ptr->d_slist_ptr, (void *)(&addr))) {

            if (NULL == (slist_entry_ptr = H5FL_MALLOC(H5AC_slist_entry_t)))
                HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "Can't allocate dirty slist entry .");
            slist_entry_ptr->addr = addr;

            if (H5SL_insert(aux_ptr->d_slist_ptr, slist_entry_ptr, &(slist_entry_ptr->addr)) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_CANTINSERT, FAIL, "can't insert entry into dirty entry slist.");

            aux_ptr->dirty_bytes += entry_ptr->size;
#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
            aux_ptr->unprotect_dirty_bytes += entry_ptr->size;
            aux_ptr->unprotect_dirty_bytes_updates += 1;
#endif
        }

        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)(&addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);
    }
    else {
        aux_ptr->dirty_bytes += entry_ptr->size;
#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
        aux_ptr->unprotect_dirty_bytes += entry_ptr->size;
        aux_ptr->unprotect_dirty_bytes_updates += 1;
#endif
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5AC__log_cleaned_entry(const H5AC_info_t *entry_ptr)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;

    FUNC_ENTER_PACKAGE_NOERR

    assert(entry_ptr);
    assert(entry_ptr->is_dirty == false);
    cache_ptr = entry_ptr->cache_ptr;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    if (aux_ptr->mpi_rank == 0) {
        H5AC_slist_entry_t *slist_entry_ptr;
        haddr_t             addr = entry_ptr->addr;

        assert(aux_ptr->d_slist_ptr != NULL);
        assert(aux_ptr->c_slist_ptr != NULL);

        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)(&addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);
        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->d_slist_ptr, (void *)(&addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

    }

    aux_ptr->dirty_bytes -= entry_ptr->size;

    FUNC_LEAVE_NOAPI(SUCCEED)
}

herr_t
H5AC__log_flushed_entry(H5C_t *cache_ptr, haddr_t addr, bool was_dirty, unsigned flags)
{
    bool                cleared;
    H5AC_aux_t         *aux_ptr;
    H5AC_slist_entry_t *slist_entry_ptr = NULL;
    herr_t              ret_value       = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank == 0);
    assert(aux_ptr->c_slist_ptr != NULL);

    cleared = ((flags & H5C__FLUSH_CLEAR_ONLY_FLAG) != 0);

    if (cleared) {

        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)(&addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);
        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->d_slist_ptr, (void *)(&addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);
    }
    else if (was_dirty) {
        if (NULL == H5SL_search(aux_ptr->c_slist_ptr, (void *)(&addr))) {

            if (NULL == (slist_entry_ptr = H5FL_MALLOC(H5AC_slist_entry_t)))
                HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "Can't allocate clean slist entry .");
            slist_entry_ptr->addr = addr;

            if (H5SL_insert(aux_ptr->c_slist_ptr, slist_entry_ptr, &(slist_entry_ptr->addr)) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_CANTINSERT, FAIL, "can't insert entry into clean entry slist.");
        }
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5AC__log_inserted_entry(const H5AC_info_t *entry_ptr)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(entry_ptr);
    cache_ptr = entry_ptr->cache_ptr;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    if (aux_ptr->mpi_rank == 0) {
        H5AC_slist_entry_t *slist_entry_ptr;

        assert(aux_ptr->d_slist_ptr != NULL);
        assert(aux_ptr->c_slist_ptr != NULL);

        if (NULL != H5SL_search(aux_ptr->d_slist_ptr, (const void *)(&entry_ptr->addr)))
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Inserted entry already in dirty slist.");

        if (NULL == (slist_entry_ptr = H5FL_MALLOC(H5AC_slist_entry_t)))
            HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "Can't allocate dirty slist entry .");
        slist_entry_ptr->addr = entry_ptr->addr;
        if (H5SL_insert(aux_ptr->d_slist_ptr, slist_entry_ptr, &(slist_entry_ptr->addr)) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTINSERT, FAIL, "can't insert entry into dirty entry slist.");

        if (NULL != H5SL_search(aux_ptr->c_slist_ptr, (const void *)(&entry_ptr->addr)))
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Inserted entry in clean slist.");
    }

    aux_ptr->dirty_bytes += entry_ptr->size;

#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
    aux_ptr->insert_dirty_bytes += entry_ptr->size;
    aux_ptr->insert_dirty_bytes_updates += 1;
#endif

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5AC__log_moved_entry(const H5F_t *f, haddr_t old_addr, haddr_t new_addr)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    bool        entry_in_cache;
    bool        entry_dirty;
    size_t      entry_size;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f);
    assert(f->shared);
    cache_ptr = (H5AC_t *)f->shared->cache;
    assert(cache_ptr);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);

    if (H5C_get_entry_status(f, old_addr, &entry_size, &entry_in_cache, &entry_dirty, NULL, NULL, NULL, NULL,
                             NULL, NULL) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't get entry status.");
    if (!entry_in_cache)
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "entry not in cache.");

    if (aux_ptr->mpi_rank == 0) {
        H5AC_slist_entry_t *slist_entry_ptr;

        assert(aux_ptr->d_slist_ptr != NULL);
        assert(aux_ptr->c_slist_ptr != NULL);

        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)(&old_addr))))
            slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, slist_entry_ptr);

        if (NULL !=
            (slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->d_slist_ptr, (void *)(&old_addr))))
            slist_entry_ptr->addr = new_addr;
        else {

            assert(!entry_dirty);
            if (NULL == (slist_entry_ptr = H5FL_MALLOC(H5AC_slist_entry_t)))
                HGOTO_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "Can't allocate dirty slist entry .");
            slist_entry_ptr->addr = new_addr;

            aux_ptr->dirty_bytes += entry_size;

#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
            aux_ptr->move_dirty_bytes += entry_size;
            aux_ptr->move_dirty_bytes_updates += 1;
#endif
        }

        if (H5SL_insert(aux_ptr->d_slist_ptr, slist_entry_ptr, &(slist_entry_ptr->addr)) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTINSERT, FAIL, "can't insert entry into dirty entry slist.");
    }
    else if (!entry_dirty) {
        aux_ptr->dirty_bytes += entry_size;

#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
        aux_ptr->move_dirty_bytes += entry_size;
        aux_ptr->move_dirty_bytes_updates += 1;
#endif
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__propagate_and_apply_candidate_list(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    haddr_t    *candidates_list_ptr = NULL;
    int         mpi_result;
    unsigned    num_candidates = 0;
    herr_t      ret_value      = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);

    if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

    if (aux_ptr->mpi_rank == 0) {
        if (H5AC__broadcast_candidate_list(cache_ptr, &num_candidates, &candidates_list_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't broadcast candidate slist.");

        assert(H5SL_count(aux_ptr->candidate_slist_ptr) == 0);
    }
    else {
        if (H5AC__receive_candidate_list(cache_ptr, &num_candidates, &candidates_list_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't receive candidate broadcast.");
    }

    if (num_candidates > 0) {
        herr_t result;

        aux_ptr->write_permitted = true;

        result = H5C_apply_candidate_list(f, cache_ptr, num_candidates, candidates_list_ptr,
                                          aux_ptr->mpi_rank, aux_ptr->mpi_size);

        aux_ptr->write_permitted = false;

        if (result < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't apply candidate list.");

        if (aux_ptr->write_done)
            (aux_ptr->write_done)();

        if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

        if (aux_ptr->mpi_rank == 0)
            if (H5AC__tidy_cache_0_lists(cache_ptr, num_candidates, candidates_list_ptr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't tidy up process 0 lists.");
    }

    if (aux_ptr->sync_point_done)
        (aux_ptr->sync_point_done)(num_candidates, candidates_list_ptr);

done:
    if (candidates_list_ptr)
        candidates_list_ptr = (haddr_t *)H5MM_xfree((void *)candidates_list_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__propagate_flushed_and_still_clean_entries_list(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__PROCESS_0_ONLY);

    if (aux_ptr->mpi_rank == 0) {
        if (H5AC__broadcast_clean_list(cache_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't broadcast clean slist.");
        assert(H5SL_count(aux_ptr->c_slist_ptr) == 0);
    }
    else if (H5AC__receive_and_apply_clean_list(f) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't receive and/or process clean slist broadcast.");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__receive_haddr_list(MPI_Comm mpi_comm, unsigned *num_entries_ptr, haddr_t **haddr_buf_ptr_ptr)
{
    haddr_t *haddr_buf_ptr = NULL;
    int      mpi_result;
    unsigned num_entries;
    herr_t   ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(num_entries_ptr != NULL);
    assert(*num_entries_ptr == 0);
    assert(haddr_buf_ptr_ptr != NULL);
    assert(*haddr_buf_ptr_ptr == NULL);

    if (MPI_SUCCESS != (mpi_result = MPI_Bcast(&num_entries, 1, MPI_UNSIGNED, 0, mpi_comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)

    if (num_entries > 0) {
        size_t buf_size;

        buf_size = sizeof(haddr_t) * num_entries;
        if (NULL == (haddr_buf_ptr = (haddr_t *)H5MM_malloc(buf_size))) {

            HDONE_ERROR(H5E_CACHE, H5E_CANTALLOC, FAIL, "memory allocation failed for haddr buffer");
        }

        if (MPI_SUCCESS !=
            (mpi_result = MPI_Bcast((void *)haddr_buf_ptr, (int)buf_size, MPI_BYTE, 0, mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Bcast failed", mpi_result)
    }

    *num_entries_ptr   = num_entries;
    *haddr_buf_ptr_ptr = haddr_buf_ptr;

done:
    if (ret_value < 0)
        if (haddr_buf_ptr)
            haddr_buf_ptr = (haddr_t *)H5MM_xfree((void *)haddr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__receive_and_apply_clean_list(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    haddr_t    *haddr_buf_ptr = NULL;
    unsigned    num_entries   = 0;
    herr_t      ret_value     = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank != 0);

    if (H5AC__receive_haddr_list(aux_ptr->mpi_comm, &num_entries, &haddr_buf_ptr) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "can't receive clean list");

    if (num_entries > 0)

        if (H5C_mark_entries_as_clean(f, num_entries, haddr_buf_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't mark entries clean.");

    if (aux_ptr->sync_point_done)
        (aux_ptr->sync_point_done)(num_entries, haddr_buf_ptr);

done:
    if (haddr_buf_ptr)
        haddr_buf_ptr = (haddr_t *)H5MM_xfree((void *)haddr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__receive_candidate_list(const H5AC_t *cache_ptr, unsigned *num_entries_ptr, haddr_t **haddr_buf_ptr_ptr)
{
    H5AC_aux_t *aux_ptr;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->mpi_rank != 0);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert(num_entries_ptr != NULL);
    assert(*num_entries_ptr == 0);
    assert(haddr_buf_ptr_ptr != NULL);
    assert(*haddr_buf_ptr_ptr == NULL);

    if (H5AC__receive_haddr_list(aux_ptr->mpi_comm, num_entries_ptr, haddr_buf_ptr_ptr) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "can't receive clean list");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__rsp__dist_md_write__flush(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    haddr_t    *haddr_buf_ptr = NULL;
    int         mpi_result;
    unsigned    num_entries = 0;
    herr_t      ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);

    if (H5C_construct_candidate_list__clean_cache(cache_ptr) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't construct candidate list.");

    if (H5SL_count(aux_ptr->candidate_slist_ptr) > 0) {
        herr_t result;

        if (H5AC__copy_candidate_list_to_buffer(cache_ptr, &num_entries, &haddr_buf_ptr) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't construct candidate buffer.");

        if (!H5CX_get_mpi_file_flushing())
            if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

        aux_ptr->write_permitted = true;

        result = H5C_apply_candidate_list(f, cache_ptr, num_entries, haddr_buf_ptr, aux_ptr->mpi_rank,
                                          aux_ptr->mpi_size);

        aux_ptr->write_permitted = false;

        if (result < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't apply candidate list.");

        if (aux_ptr->write_done)
            (aux_ptr->write_done)();

        if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

        if (aux_ptr->mpi_rank == 0)
            if (H5AC__tidy_cache_0_lists(cache_ptr, num_entries, haddr_buf_ptr) < 0)
                HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Can't tidy up process 0 lists.");
    }

    if (aux_ptr->sync_point_done)
        (aux_ptr->sync_point_done)(num_entries, haddr_buf_ptr);

done:
    if (haddr_buf_ptr)
        haddr_buf_ptr = (haddr_t *)H5MM_xfree((void *)haddr_buf_ptr);

    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__rsp__dist_md_write__flush_to_min_clean(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    bool        evictions_enabled;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);

    if (H5C_get_evictions_enabled((const H5C_t *)cache_ptr, &evictions_enabled) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "H5C_get_evictions_enabled() failed.");

    if (evictions_enabled) {

        if (aux_ptr->mpi_rank == 0) {

            if (H5AC__construct_candidate_list(cache_ptr, aux_ptr, H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN) <
                0)
                HDONE_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't construct candidate list.");
        }

        if (H5AC__propagate_and_apply_candidate_list(f) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't propagate and apply candidate list.");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__rsp__p0_only__flush(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    int         mpi_result;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__PROCESS_0_ONLY);

    if (!H5CX_get_mpi_file_flushing())
        if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

    if (aux_ptr->mpi_rank == 0) {
        herr_t result;

        aux_ptr->write_permitted = true;

        result = H5C_flush_cache(f, H5AC__NO_FLAGS_SET);

        aux_ptr->write_permitted = false;

        if (result < 0) {

            HDONE_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't flush.");
        }
        else {

            if (aux_ptr->write_done)
                (aux_ptr->write_done)();
        }
    }

    if (H5AC__propagate_flushed_and_still_clean_entries_list(f) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't propagate clean entries list.");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__rsp__p0_only__flush_to_min_clean(H5F_t *f)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    bool        evictions_enabled;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__PROCESS_0_ONLY);

    if (H5C_get_evictions_enabled((const H5C_t *)cache_ptr, &evictions_enabled) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "H5C_get_evictions_enabled() failed.");

    if (evictions_enabled) {
        int mpi_result;

        if (MPI_SUCCESS != (mpi_result = MPI_Barrier(aux_ptr->mpi_comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Barrier failed", mpi_result)

        if (0 == aux_ptr->mpi_rank) {
            herr_t result;

            aux_ptr->write_permitted = true;

            result = H5C_flush_to_min_clean(f);

            aux_ptr->write_permitted = false;

            if (result < 0) {

                HDONE_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "H5C_flush_to_min_clean() failed.");
            }
            else {

                if (aux_ptr->write_done)
                    (aux_ptr->write_done)();
            }
        }

        if (H5AC__propagate_flushed_and_still_clean_entries_list(f) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't propagate clean entries list.");
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

herr_t
H5AC__run_sync_point(H5F_t *f, int sync_point_op)
{
    H5AC_t     *cache_ptr;
    H5AC_aux_t *aux_ptr;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f != NULL);
    cache_ptr = f->shared->cache;
    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert((sync_point_op == H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN) ||
           (sync_point_op == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED));

#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
    Rfprintf(Rstdout, "%d:%s...:%u: (u/uu/i/iu/m/mu) = %zu/%u/%zu/%u/%zu/%u\n", aux_ptr->mpi_rank, __func__,
            aux_ptr->dirty_bytes_propagations, aux_ptr->unprotect_dirty_bytes,
            aux_ptr->unprotect_dirty_bytes_updates, aux_ptr->insert_dirty_bytes,
            aux_ptr->insert_dirty_bytes_updates, aux_ptr->move_dirty_bytes,
            aux_ptr->move_dirty_bytes_updates);
#endif

    if (H5C_clear_coll_entries(cache_ptr, true) < 0)
        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "H5C_clear_coll_entries() failed.");

    switch (aux_ptr->metadata_write_strategy) {
        case H5AC_METADATA_WRITE_STRATEGY__PROCESS_0_ONLY:
            switch (sync_point_op) {
                case H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN:
                    if (H5AC__rsp__p0_only__flush_to_min_clean(f) < 0)
                        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL,
                                    "H5AC__rsp__p0_only__flush_to_min_clean() failed.");
                    break;

                case H5AC_SYNC_POINT_OP__FLUSH_CACHE:
                    if (H5AC__rsp__p0_only__flush(f) < 0)
                        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL, "H5AC__rsp__p0_only__flush() failed.");
                    break;

                default:
                    HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "unknown flush op");
                    break;
            }
            break;

        case H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED:
            switch (sync_point_op) {
                case H5AC_SYNC_POINT_OP__FLUSH_TO_MIN_CLEAN:
                    if (H5AC__rsp__dist_md_write__flush_to_min_clean(f) < 0)
                        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL,
                                    "H5AC__rsp__dist_md_write__flush_to_min_clean() failed.");
                    break;

                case H5AC_SYNC_POINT_OP__FLUSH_CACHE:
                    if (H5AC__rsp__dist_md_write__flush(f) < 0)
                        HGOTO_ERROR(H5E_CACHE, H5E_CANTGET, FAIL,
                                    "H5AC__rsp__dist_md_write__flush() failed.");
                    break;

                default:
                    HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "unknown flush op");
                    break;
            }
            break;

        default:
            HGOTO_ERROR(H5E_CACHE, H5E_SYSTEM, FAIL, "Unknown metadata write strategy.");
            break;
    }

    aux_ptr->dirty_bytes = 0;

#ifdef H5AC_DEBUG_DIRTY_BYTES_CREATION
    aux_ptr->dirty_bytes_propagations += 1;
    aux_ptr->unprotect_dirty_bytes         = 0;
    aux_ptr->unprotect_dirty_bytes_updates = 0;
    aux_ptr->insert_dirty_bytes            = 0;
    aux_ptr->insert_dirty_bytes_updates    = 0;
    aux_ptr->move_dirty_bytes              = 0;
    aux_ptr->move_dirty_bytes_updates      = 0;
#endif

done:
    FUNC_LEAVE_NOAPI(ret_value)
}

static herr_t
H5AC__tidy_cache_0_lists(H5AC_t *cache_ptr, unsigned num_candidates, haddr_t *candidates_list_ptr)
{
    H5AC_aux_t *aux_ptr;
    unsigned    u;

    FUNC_ENTER_PACKAGE_NOERR

    assert(cache_ptr != NULL);
    aux_ptr = (H5AC_aux_t *)H5C_get_aux_ptr(cache_ptr);
    assert(aux_ptr != NULL);
    assert(aux_ptr->metadata_write_strategy == H5AC_METADATA_WRITE_STRATEGY__DISTRIBUTED);
    assert(aux_ptr->mpi_rank == 0);
    assert(num_candidates > 0);
    assert(candidates_list_ptr != NULL);

    for (u = 0; u < num_candidates; u++) {
        H5AC_slist_entry_t *d_slist_entry_ptr;
        H5AC_slist_entry_t *c_slist_entry_ptr;
        haddr_t             addr;

        addr = candidates_list_ptr[u];

        if (NULL !=
            (d_slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->d_slist_ptr, (void *)&addr)))
            d_slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, d_slist_entry_ptr);
        if (NULL !=
            (c_slist_entry_ptr = (H5AC_slist_entry_t *)H5SL_remove(aux_ptr->c_slist_ptr, (void *)&addr)))
            c_slist_entry_ptr = H5FL_FREE(H5AC_slist_entry_t, c_slist_entry_ptr);
    }

    FUNC_LEAVE_NOAPI(SUCCEED)
}

herr_t
H5AC__flush_entries(H5F_t *f)
{
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(f);
    assert(f->shared->cache);

    if (H5C_get_aux_ptr(f->shared->cache))
        if (H5AC__run_sync_point(f, H5AC_SYNC_POINT_OP__FLUSH_CACHE) < 0)
            HGOTO_ERROR(H5E_CACHE, H5E_CANTFLUSH, FAIL, "Can't run sync point.");

done:
    FUNC_LEAVE_NOAPI(ret_value)
}
#endif
