/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Smodule.h" 

#include "H5private.h"   
#include "H5Dprivate.h"  
#include "H5Eprivate.h"  
#include "H5FLprivate.h" 
#include "H5MMprivate.h" 
#include "H5Spkg.h"      
#include "H5VMprivate.h" 

#ifdef H5_HAVE_PARALLEL

#define H5S_MPIO_INITIAL_ALLOC_COUNT 256

typedef struct H5S_mpio_mpitype_node_t {
    MPI_Datatype                    type; 
    struct H5S_mpio_mpitype_node_t *next; 
} H5S_mpio_mpitype_node_t;

typedef struct H5S_mpio_mpitype_list_t {
    H5S_mpio_mpitype_node_t *head; 
    H5S_mpio_mpitype_node_t *tail; 
} H5S_mpio_mpitype_list_t;

static herr_t H5S__mpio_all_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                                 bool *is_derived_type);
static herr_t H5S__mpio_none_type(MPI_Datatype *new_type, int *count, bool *is_derived_type);
static herr_t H5S__mpio_create_point_datatype(size_t elmt_size, hsize_t num_points, MPI_Aint *disp,
                                              MPI_Datatype *new_type);
static herr_t H5S__mpio_point_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                                   bool *is_derived_type, bool do_permute, hsize_t **permute_map,
                                   bool *is_permuted);
static herr_t H5S__mpio_permute_type(H5S_t *space, size_t elmt_size, hsize_t **permute_map,
                                     MPI_Datatype *new_type, int *count, bool *is_derived_type);
static herr_t H5S__mpio_reg_hyper_type(H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                                       bool *is_derived_type);
static herr_t H5S__mpio_span_hyper_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type,
                                        int *count, bool *is_derived_type);
static herr_t H5S__release_datatype(H5S_mpio_mpitype_list_t *type_list);
static herr_t H5S__obtain_datatype(H5S_hyper_span_info_t *spans, const hsize_t *down, size_t elmt_size,
                                   const MPI_Datatype *elmt_type, MPI_Datatype *span_type,
                                   H5S_mpio_mpitype_list_t *type_list, unsigned op_info_i, uint64_t op_gen);

H5FL_DEFINE_STATIC(H5S_mpio_mpitype_node_t);

H5FL_EXTERN(H5S_sel_iter_t);

static herr_t
H5S__mpio_all_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                   bool *is_derived_type)
{
    hsize_t  total_bytes;
    hssize_t snelmts;             
    hsize_t  nelmts;              
    hsize_t  bigio_count;         
    herr_t   ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(space);

    
    if ((snelmts = (hssize_t)H5S_GET_EXTENT_NPOINTS(space)) < 0)
        HGOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "src dataspace has invalid selection");
    H5_CHECKED_ASSIGN(nelmts, hsize_t, snelmts, hssize_t);

    total_bytes = (hsize_t)elmt_size * nelmts;
    bigio_count = H5_mpi_get_bigio_count();

    
    if (bigio_count >= total_bytes) {
        
        *new_type = MPI_BYTE;
        H5_CHECKED_ASSIGN(*count, int, total_bytes, hsize_t);
        *is_derived_type = false;
    }
    else {
        
        if (H5_mpio_create_large_type(total_bytes, 0, MPI_BYTE, new_type) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                        "couldn't create a large datatype from the all selection");
        *count           = 1;
        *is_derived_type = true;
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__mpio_none_type(MPI_Datatype *new_type, int *count, bool *is_derived_type)
{
    FUNC_ENTER_PACKAGE_NOERR

    
    *new_type        = MPI_BYTE;
    *count           = 0;
    *is_derived_type = false;

    FUNC_LEAVE_NOAPI(SUCCEED)
} 

static herr_t
H5S__mpio_create_point_datatype(size_t elmt_size, hsize_t num_points, MPI_Aint *disp, MPI_Datatype *new_type)
{
    MPI_Datatype  elmt_type;                 
    bool          elmt_type_created = false; 
    int          *inner_blocks      = NULL;  
    MPI_Aint     *inner_disps       = NULL;
    MPI_Datatype *inner_types       = NULL;
    hsize_t       bigio_count;         
    int           mpi_code;            
    herr_t        ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    if (MPI_SUCCESS != (mpi_code = MPI_Type_contiguous((int)elmt_size, MPI_BYTE, &elmt_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code)
    elmt_type_created = true;

    bigio_count = H5_mpi_get_bigio_count();

    
    if (bigio_count >= num_points) {
        
        if (MPI_SUCCESS !=
            (mpi_code = MPI_Type_create_hindexed_block((int)num_points, 1, disp, elmt_type, new_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_indexed_block failed", mpi_code)

        
        if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(new_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)
    }
    else {
        
        int     total_types, i;
        int     remaining_points;
        int     num_big_types;
        hsize_t leftover;

        
        num_big_types = (int)(num_points / bigio_count);

        leftover = (hsize_t)num_points - (hsize_t)num_big_types * (hsize_t)bigio_count;
        H5_CHECKED_ASSIGN(remaining_points, int, leftover, hsize_t);

        total_types = (int)(remaining_points) ? (num_big_types + 1) : num_big_types;

        
        if (NULL == (inner_types = (MPI_Datatype *)H5MM_malloc((sizeof(MPI_Datatype) * (size_t)total_types))))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of blocks");

        if (NULL == (inner_blocks = (int *)H5MM_malloc(sizeof(int) * (size_t)total_types)))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of blocks");

        if (NULL == (inner_disps = (MPI_Aint *)H5MM_malloc(sizeof(MPI_Aint) * (size_t)total_types)))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of blocks");

        for (i = 0; i < num_big_types; i++) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hindexed_block((int)bigio_count, 1,
                                                                          &disp[(hsize_t)i * bigio_count],
                                                                          elmt_type, &inner_types[i])))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed_block failed", mpi_code);
            inner_blocks[i] = 1;
            inner_disps[i]  = 0;
        } 

        if (remaining_points) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hindexed_block(
                                    remaining_points, 1, &disp[(hsize_t)num_big_types * bigio_count],
                                    elmt_type, &inner_types[num_big_types])))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed_block failed", mpi_code);
            inner_blocks[num_big_types] = 1;
            inner_disps[num_big_types]  = 0;
        }

        if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct(total_types, inner_blocks, inner_disps,
                                                              inner_types, new_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct", mpi_code);

        for (i = 0; i < total_types; i++)
            MPI_Type_free(&inner_types[i]);

        
        if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(new_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)
    } 

done:
    if (elmt_type_created)
        MPI_Type_free(&elmt_type);
    if (inner_types)
        H5MM_free(inner_types);
    if (inner_blocks)
        H5MM_free(inner_blocks);
    if (inner_disps)
        H5MM_free(inner_disps);

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__mpio_point_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                     bool *is_derived_type, bool do_permute, hsize_t **permute, bool *is_permuted)
{
    MPI_Aint       *disp = NULL;         
    H5S_pnt_node_t *curr = NULL;         
    hssize_t        snum_points;         
    hsize_t         num_points;          
    hsize_t         u;                   
    herr_t          ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(space);

    
    if ((snum_points = (hssize_t)H5S_GET_SELECT_NPOINTS(space)) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTCOUNT, FAIL, "can't get number of elements selected");
    num_points = (hsize_t)snum_points;

    
    if (NULL == (disp = (MPI_Aint *)H5MM_malloc(sizeof(MPI_Aint) * num_points)))
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of displacements");

    
    if (do_permute)
        if (NULL == (*permute = (hsize_t *)H5MM_malloc(sizeof(hsize_t) * num_points)))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate permutation array");

    
    curr = space->select.sel_info.pnt_lst->head;
    for (u = 0; u < num_points; u++) {
        
        hsize_t disp_tmp = H5VM_array_offset(space->extent.rank, space->extent.size, curr->pnt);
        if (disp_tmp > LONG_MAX) 
            HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "disp overflow");
        disp[u] = (MPI_Aint)disp_tmp;
        disp[u] *= (MPI_Aint)elmt_size;

        
        if (do_permute) {
            if (u > 0 && disp[u] < disp[u - 1]) {
                hsize_t s = 0, l = u, m = u / 2;

                *is_permuted = true;
                do {
                    if (disp[u] > disp[m])
                        s = m + 1;
                    else if (disp[u] < disp[m])
                        l = m;
                    else
                        break;
                    m = s + ((l - s) / 2);
                } while (s < l);

                if (m < u) {
                    MPI_Aint temp;

                    temp = disp[u];
                    memmove(disp + m + 1, disp + m, (u - m) * sizeof(MPI_Aint));
                    disp[m] = temp;
                } 
                (*permute)[u] = m;
            } 
            else
                (*permute)[u] = num_points;
        } 
        
        else {
            ; 
        }     

        
        curr = curr->next;
    } 

    
    if (H5S__mpio_create_point_datatype(elmt_size, num_points, disp, new_type) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create an MPI Datatype from point selection");

    
    *count           = 1;
    *is_derived_type = true;

done:
    if (NULL != disp)
        H5MM_free(disp);

    
    if (!(*is_permuted) && (*permute)) {
        H5MM_free(*permute);
        *permute = NULL;
    } 

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__mpio_permute_type(H5S_t *space, size_t elmt_size, hsize_t **permute, MPI_Datatype *new_type, int *count,
                       bool *is_derived_type)
{
    MPI_Aint       *disp          = NULL;  
    H5S_sel_iter_t *sel_iter      = NULL;  
    bool            sel_iter_init = false; 
    hssize_t        snum_points;           
    hsize_t         num_points;            
    hsize_t        *off = NULL;
    size_t         *len = NULL;
    size_t          max_elem;            
    hsize_t         u;                   
    herr_t          ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(space);

    
    if ((snum_points = (hssize_t)H5S_GET_SELECT_NPOINTS(space)) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTCOUNT, FAIL, "can't get number of elements selected");
    num_points = (hsize_t)snum_points;

    
    if (NULL == (disp = (MPI_Aint *)H5MM_malloc(sizeof(MPI_Aint) * num_points)))
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of displacements");

    
    if (NULL == (off = H5MM_malloc(H5D_IO_VECTOR_SIZE * sizeof(*off))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't allocate sequence offsets array");
    if (NULL == (len = H5MM_malloc(H5D_IO_VECTOR_SIZE * sizeof(*len))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't allocate sequence lengths array");

    
    if (NULL == (sel_iter = H5FL_MALLOC(H5S_sel_iter_t)))
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "couldn't allocate dataspace selection iterator");

    
    if (H5S_select_iter_init(sel_iter, space, elmt_size, 0) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTINIT, FAIL, "unable to initialize selection iterator");
    sel_iter_init = true; 

    
    H5_CHECKED_ASSIGN(max_elem, size_t, num_points, hsize_t);

    
    u = 0;
    while (max_elem > 0) {
        size_t nelem;    
        size_t nseq;     
        size_t curr_seq; 

        
        if (H5S_SELECT_ITER_GET_SEQ_LIST(sel_iter, (size_t)H5D_IO_VECTOR_SIZE, max_elem, &nseq, &nelem, off,
                                         len) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_UNSUPPORTED, FAIL, "sequence length generation failed");

        
        for (curr_seq = 0; curr_seq < nseq; curr_seq++) {
            hsize_t curr_off; 
            size_t  curr_len; 

            
            curr_off = off[curr_seq];

            
            curr_len = len[curr_seq];

            
            while (curr_len > 0) {
                
                if (curr_off > LONG_MAX)
                    HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "curr_off overflow");
                disp[u] = (MPI_Aint)curr_off;

                
                if ((*permute)[u] != num_points) {
                    MPI_Aint temp = disp[u];

                    memmove(disp + (*permute)[u] + 1, disp + (*permute)[u],
                            (u - (*permute)[u]) * sizeof(MPI_Aint));
                    disp[(*permute)[u]] = temp;
                } 

                
                u++;

                
                curr_off += elmt_size;

                
                curr_len -= elmt_size;
            } 
        }     

        
        max_elem -= nelem;
    } 

    
    if (H5S__mpio_create_point_datatype(elmt_size, num_points, disp, new_type) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create an MPI Datatype from point selection");

    
    *count           = 1;
    *is_derived_type = true;

done:
    
    if (sel_iter) {
        if (sel_iter_init && H5S_SELECT_ITER_RELEASE(sel_iter) < 0)
            HDONE_ERROR(H5E_DATASPACE, H5E_CANTRELEASE, FAIL, "unable to release selection iterator");
        sel_iter = H5FL_FREE(H5S_sel_iter_t, sel_iter);
    }

    H5MM_free(len);
    H5MM_free(off);

    
    if (disp)
        H5MM_free(disp);
    if (*permute) {
        H5MM_free(*permute);
        *permute = NULL;
    } 

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__mpio_reg_hyper_type(H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                         bool *is_derived_type)
{
    H5S_sel_iter_t *sel_iter      = NULL;  
    bool            sel_iter_init = false; 

    struct dim { 
        hssize_t start;
        hsize_t  strid;
        hsize_t  block;
        hsize_t  xtent;
        hsize_t  count;
    } d[H5S_MAX_RANK];

    hsize_t          bigio_count; 
    hsize_t          offset[H5S_MAX_RANK];
    hsize_t          max_xtent[H5S_MAX_RANK];
    H5S_hyper_dim_t *diminfo; 
    unsigned         rank;
    MPI_Datatype     inner_type, outer_type;
    MPI_Aint         extent_len, start_disp, new_extent;
    MPI_Aint         lb;       
    unsigned         u;        
    int              i;        
    int              mpi_code; 
    herr_t           ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    assert(space);
    assert(sizeof(MPI_Aint) >= sizeof(elmt_size));

    bigio_count = H5_mpi_get_bigio_count();

    
    if (NULL == (sel_iter = H5FL_MALLOC(H5S_sel_iter_t)))
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "couldn't allocate dataspace selection iterator");

    
    if (H5S_select_iter_init(sel_iter, space, elmt_size, 0) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTINIT, FAIL, "unable to initialize selection iterator");
    sel_iter_init = true; 

    
    diminfo = sel_iter->u.hyp.diminfo;
    assert(diminfo);

    

    
    if (sel_iter->u.hyp.iter_rank != 0 && sel_iter->u.hyp.iter_rank < space->extent.rank) {
        
        rank = sel_iter->u.hyp.iter_rank;

        for (u = 0; u < rank; ++u) {
            H5_CHECK_OVERFLOW(diminfo[u].start, hsize_t, hssize_t);
            d[u].start = (hssize_t)diminfo[u].start + sel_iter->u.hyp.sel_off[u];
            d[u].strid = diminfo[u].stride;
            d[u].block = diminfo[u].block;
            d[u].count = diminfo[u].count;
            d[u].xtent = sel_iter->u.hyp.size[u];

            
            assert(d[u].block > 0);
            assert(d[u].count > 0);
            assert(d[u].xtent > 0);
        }
    }
    else {
        
        rank = space->extent.rank;

        for (u = 0; u < rank; ++u) {
            H5_CHECK_OVERFLOW(diminfo[u].start, hsize_t, hssize_t);
            d[u].start = (hssize_t)diminfo[u].start + space->select.offset[u];
            d[u].strid = diminfo[u].stride;
            d[u].block = diminfo[u].block;
            d[u].count = diminfo[u].count;
            d[u].xtent = space->extent.size[u];

            
            assert(d[u].block > 0);
            assert(d[u].count > 0);
            assert(d[u].xtent > 0);
        }
    }

    
    offset[rank - 1]    = 1;
    max_xtent[rank - 1] = d[rank - 1].xtent;

    for (i = ((int)rank) - 2; i >= 0; --i) {
        offset[i]    = offset[i + 1] * d[i + 1].xtent;
        max_xtent[i] = max_xtent[i + 1] * d[i].xtent;
    }

    

    

    
    if (bigio_count >= elmt_size) {
        
        if (MPI_SUCCESS != (mpi_code = MPI_Type_contiguous((int)elmt_size, MPI_BYTE, &inner_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code)
    }
    else
        
        if (H5_mpio_create_large_type(elmt_size, 0, MPI_BYTE, &inner_type) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                        "couldn't create a large inner datatype in hyper selection");

    
    for (i = ((int)rank) - 1; i >= 0; --i) {

        
        if (bigio_count >= d[i].count && bigio_count >= d[i].block && bigio_count >= d[i].strid) {
            
            mpi_code = MPI_Type_vector((int)(d[i].count), 
                                       (int)(d[i].block), 
                                       (int)(d[i].strid), 
                                       inner_type,        
                                       &outer_type);      

            MPI_Type_free(&inner_type);
            if (mpi_code != MPI_SUCCESS)
                HMPI_GOTO_ERROR(FAIL, "couldn't create MPI vector type", mpi_code)
        }
        else {
            

            MPI_Aint     stride_in_bytes, inner_extent;
            MPI_Datatype block_type;

            
            if (bigio_count < d[i].block) {
                if (H5_mpio_create_large_type(d[i].block, 0, inner_type, &block_type) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                "couldn't create a large block datatype in hyper selection");
            }
            else if (MPI_SUCCESS !=
                     (mpi_code = MPI_Type_contiguous((int)d[i].block, inner_type, &block_type)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code)

            
            {
                MPI_Aint unused_lb_arg;
                MPI_Type_get_extent(inner_type, &unused_lb_arg, &inner_extent);
            }
            stride_in_bytes = inner_extent * (MPI_Aint)d[i].strid;

            
            if (bigio_count < d[i].count) {
                if (H5_mpio_create_large_type(d[i].count, stride_in_bytes, block_type, &outer_type) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                "couldn't create a large outer datatype in hyper selection");
            }
            
            else if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hvector((int)d[i].count, 
                                                                        1,               
                                                                        stride_in_bytes, 
                                                                        block_type,      
                                                                        &outer_type)))   
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hvector failed", mpi_code)

            MPI_Type_free(&block_type);
            MPI_Type_free(&inner_type);
        } 

        

        
        
        if (d[i].start > LONG_MAX || offset[i] > LONG_MAX || elmt_size > LONG_MAX)
            HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "result overflow");
        start_disp = (MPI_Aint)d[i].start * (MPI_Aint)offset[i] * (MPI_Aint)elmt_size;

        if (max_xtent[i] > LONG_MAX)
            HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "max_xtent overflow");
        new_extent = (MPI_Aint)elmt_size * (MPI_Aint)max_xtent[i];
        if (MPI_SUCCESS != (mpi_code = MPI_Type_get_extent(outer_type, &lb, &extent_len)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_get_extent failed", mpi_code)

        
        if (start_disp > 0 || extent_len < new_extent) {
            MPI_Datatype interm_type;
            int          block_len = 1;

            assert(0 == lb);

            mpi_code = MPI_Type_create_hindexed(1, &block_len, &start_disp, outer_type, &interm_type);
            MPI_Type_free(&outer_type);
            if (mpi_code != MPI_SUCCESS)
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed failed", mpi_code)

            mpi_code = MPI_Type_create_resized(interm_type, lb, new_extent, &inner_type);
            MPI_Type_free(&interm_type);
            if (mpi_code != MPI_SUCCESS)
                HMPI_GOTO_ERROR(FAIL, "couldn't resize MPI vector type", mpi_code)
        } 
        else
            inner_type = outer_type;
    } 
      

    
    *new_type = inner_type;
    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(new_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

    
    *count           = 1; 
    *is_derived_type = true;

done:
    
    if (sel_iter) {
        if (sel_iter_init && H5S_SELECT_ITER_RELEASE(sel_iter) < 0)
            HDONE_ERROR(H5E_DATASPACE, H5E_CANTRELEASE, FAIL, "unable to release selection iterator");
        sel_iter = H5FL_FREE(H5S_sel_iter_t, sel_iter);
    }

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__mpio_span_hyper_type(const H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count,
                          bool *is_derived_type)
{
    H5S_mpio_mpitype_list_t type_list;                    
    MPI_Datatype            elmt_type;                    
    bool                    elmt_type_is_derived = false; 
    MPI_Datatype            span_type;                    
    hsize_t                 bigio_count;                  
    hsize_t                 down[H5S_MAX_RANK];           
    uint64_t                op_gen;                       
    int                     mpi_code;                     
    herr_t                  ret_value = SUCCEED;          

    FUNC_ENTER_PACKAGE

    
    assert(space);
    assert(space->extent.size);
    assert(space->select.sel_info.hslab->span_lst);
    assert(space->select.sel_info.hslab->span_lst->head);

    bigio_count = H5_mpi_get_bigio_count();
    
    if (bigio_count >= elmt_size) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_contiguous((int)elmt_size, MPI_BYTE, &elmt_type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code)
    }
    else if (H5_mpio_create_large_type(elmt_size, 0, MPI_BYTE, &elmt_type) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                    "couldn't create a large element datatype in span_hyper selection");
    elmt_type_is_derived = true;

    
    H5VM_array_down(space->extent.rank, space->extent.size, down);

    
    op_gen = H5S__hyper_get_op_gen();

    
    
    type_list.head = type_list.tail = NULL;
    if (H5S__obtain_datatype(space->select.sel_info.hslab->span_lst, down, elmt_size, &elmt_type, &span_type,
                             &type_list, 0, op_gen) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't obtain MPI derived data type");
    if (MPI_SUCCESS != (mpi_code = MPI_Type_dup(span_type, new_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_dup failed", mpi_code)
    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(new_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

    
    if (H5S__release_datatype(&type_list) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTRELEASE, FAIL, "couldn't release MPI derived data type");

    
    *count           = 1;
    *is_derived_type = true;

done:
    
    if (elmt_type_is_derived)
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&elmt_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__release_datatype(H5S_mpio_mpitype_list_t *type_list)
{
    H5S_mpio_mpitype_node_t *curr;                
    herr_t                   ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(type_list);

    
    curr = type_list->head;
    while (curr) {
        H5S_mpio_mpitype_node_t *next;     
        int                      mpi_code; 

        
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&curr->type)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

        
        next = curr->next;

        
        curr = H5FL_FREE(H5S_mpio_mpitype_node_t, curr);

        
        curr = next;
    } 

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__obtain_datatype(H5S_hyper_span_info_t *spans, const hsize_t *down, size_t elmt_size,
                     const MPI_Datatype *elmt_type, MPI_Datatype *span_type,
                     H5S_mpio_mpitype_list_t *type_list, unsigned op_info_i, uint64_t op_gen)
{
    H5S_hyper_span_t *span;                  
    hsize_t           bigio_count;           
    size_t            alloc_count       = 0; 
    size_t            outercount        = 0; 
    MPI_Datatype     *inner_type        = NULL;
    bool              inner_types_freed = false; 
    int              *blocklen          = NULL;
    MPI_Aint         *disp              = NULL;
    size_t            u;                   
    int               mpi_code;            
    herr_t            ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(spans);
    assert(type_list);

    bigio_count = H5_mpi_get_bigio_count();
    
    if (spans->op_info[op_info_i].op_gen != op_gen) {
        H5S_mpio_mpitype_node_t *type_node; 

        
        alloc_count = H5S_MPIO_INITIAL_ALLOC_COUNT;
        if (NULL == (disp = (MPI_Aint *)H5MM_malloc(alloc_count * sizeof(MPI_Aint))))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of displacements");
        if (NULL == (blocklen = (int *)H5MM_malloc(alloc_count * sizeof(int))))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate array of block lengths");

        
        span = spans->head;
        if (NULL == span->down) {
            bool large_block = false; 

            outercount = 0;
            while (span) {
                hsize_t nelmts; 

                
                if (outercount >= alloc_count) {
                    MPI_Aint *tmp_disp;     
                    int      *tmp_blocklen; 

                    
                    alloc_count *= 2;

                    
                    if (NULL == (tmp_disp = (MPI_Aint *)H5MM_realloc(disp, alloc_count * sizeof(MPI_Aint))))
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                                    "can't allocate array of displacements");
                    disp = tmp_disp;
                    if (NULL == (tmp_blocklen = (int *)H5MM_realloc(blocklen, alloc_count * sizeof(int))))
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                                    "can't allocate array of block lengths");
                    blocklen = tmp_blocklen;
                } 

                
                nelmts = (span->high - span->low) + 1;

                
                disp[outercount] = (MPI_Aint)elmt_size * (MPI_Aint)span->low;
                H5_CHECK_OVERFLOW(nelmts, hsize_t, int);
                blocklen[outercount] = (int)nelmts;

                if (bigio_count < (hsize_t)blocklen[outercount])
                    large_block = true; 

                span = span->next;
                outercount++;
            } 

            
            if (bigio_count >= outercount && large_block == false) {
                if (MPI_SUCCESS !=
                    (mpi_code = MPI_Type_create_hindexed((int)outercount, blocklen, disp, *elmt_type,
                                                         &spans->op_info[op_info_i].u.down_type)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hindexed failed", mpi_code)
            }      
            else { 
                for (u = 0; u < outercount; u++) {
                    MPI_Datatype temp_type = MPI_DATATYPE_NULL;

                    
                    if ((hsize_t)(blocklen[u]) > bigio_count) {
                        if (H5_mpio_create_large_type((hsize_t)blocklen[u], 0, *elmt_type, &temp_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't create a large element datatype in span_hyper selection");
                    } 
                    else if (MPI_SUCCESS !=
                             (mpi_code = MPI_Type_contiguous((int)blocklen[u], *elmt_type, &temp_type)))
                        HMPI_GOTO_ERROR(FAIL, "MPI_Type_contiguous failed", mpi_code)

                    
                    if (0 == u) 
                        spans->op_info[op_info_i].u.down_type = temp_type;
                    else {
                        int          bl[2] = {1, 1};
                        MPI_Aint     ds[2] = {disp[u - 1], disp[u]};
                        MPI_Datatype dt[2] = {spans->op_info[op_info_i].u.down_type, temp_type};

                        if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct(
                                                2,                                        
                                                bl,                                       
                                                ds,                                       
                                                dt,                                       
                                                &spans->op_info[op_info_i].u.down_type))) 
                            HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)

                        
                        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&temp_type)))
                            HMPI_GOTO_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
                    } 
                }     
            }         
        }             
        else {
            MPI_Aint stride; 

            if (NULL == (inner_type = (MPI_Datatype *)H5MM_malloc(alloc_count * sizeof(MPI_Datatype))))
                HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                            "can't allocate array of inner MPI datatypes");

            
            stride = (MPI_Aint)(*down) * (MPI_Aint)elmt_size;

            
            outercount = 0;
            while (span) {
                MPI_Datatype down_type; 
                hsize_t      nelmts;    

                
                if (outercount >= alloc_count) {
                    MPI_Aint     *tmp_disp;       
                    int          *tmp_blocklen;   
                    MPI_Datatype *tmp_inner_type; 

                    
                    alloc_count *= 2;

                    
                    if (NULL == (tmp_disp = (MPI_Aint *)H5MM_realloc(disp, alloc_count * sizeof(MPI_Aint))))
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                                    "can't allocate array of displacements");
                    disp = tmp_disp;
                    if (NULL == (tmp_blocklen = (int *)H5MM_realloc(blocklen, alloc_count * sizeof(int))))
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                                    "can't allocate array of block lengths");
                    blocklen = tmp_blocklen;
                    if (NULL == (tmp_inner_type = (MPI_Datatype *)H5MM_realloc(
                                     inner_type, alloc_count * sizeof(MPI_Datatype))))
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL,
                                    "can't allocate array of inner MPI datatypes");
                    inner_type = tmp_inner_type;
                } 

                
                
                
                disp[outercount]     = (MPI_Aint)span->low * stride;
                blocklen[outercount] = 1;

                
                if (H5S__obtain_datatype(span->down, down + 1, elmt_size, elmt_type, &down_type, type_list,
                                         op_info_i, op_gen) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't obtain MPI derived data type");

                
                nelmts = (span->high - span->low) + 1;

                
                H5_CHECK_OVERFLOW(nelmts, hsize_t, int);
                if (MPI_SUCCESS != (mpi_code = MPI_Type_create_hvector((int)nelmts, 1, stride, down_type,
                                                                       &inner_type[outercount])))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_hvector failed", mpi_code)

                span = span->next;
                outercount++;
            } 

            
            H5_CHECK_OVERFLOW(outercount, size_t, int);
            if (MPI_SUCCESS != (mpi_code = MPI_Type_create_struct((int)outercount, blocklen, disp, inner_type,
                                                                  &spans->op_info[op_info_i].u.down_type)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)

            
            for (u = 0; u < outercount; u++)
                if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&inner_type[u])))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            inner_types_freed = true;
        } 

        
        if (NULL == (type_node = H5FL_MALLOC(H5S_mpio_mpitype_node_t)))
            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTALLOC, FAIL, "can't allocate MPI data type list node");

        
        type_node->type = spans->op_info[op_info_i].u.down_type;
        type_node->next = NULL;

        
        if (type_list->head == NULL)
            type_list->head = type_list->tail = type_node;
        else {
            type_list->tail->next = type_node;
            type_list->tail       = type_node;
        } 

        
        spans->op_info[op_info_i].op_gen = op_gen;
    } 

    
    *span_type = spans->op_info[op_info_i].u.down_type;

done:
    
    if (inner_type != NULL) {
        if (!inner_types_freed)
            for (u = 0; u < outercount; u++)
                if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&inner_type[u])))
                    HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
        H5MM_free(inner_type);
    } 
    if (blocklen != NULL)
        H5MM_free(blocklen);
    if (disp != NULL)
        H5MM_free(disp);

    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5S_mpio_space_type(H5S_t *space, size_t elmt_size, MPI_Datatype *new_type, int *count, bool *is_derived_type,
                    bool do_permute, hsize_t **permute_map, bool *is_permuted)
{
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_NOAPI_NOINIT

    
    assert(space);
    assert(elmt_size);

    
    switch (H5S_GET_EXTENT_TYPE(space)) {
        case H5S_NULL:
        case H5S_SCALAR:
        case H5S_SIMPLE:
            
            if (true == *is_permuted) {
                switch (H5S_GET_SELECT_TYPE(space)) {
                    case H5S_SEL_NONE:
                        if (H5S__mpio_none_type(new_type, count, is_derived_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert 'none' selection to MPI type");
                        break;

                    case H5S_SEL_ALL:
                    case H5S_SEL_POINTS:
                    case H5S_SEL_HYPERSLABS:
                        
                        assert(!do_permute);

                        if (H5S__mpio_permute_type(space, elmt_size, permute_map, new_type, count,
                                                   is_derived_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert 'all' selection to MPI type");
                        break;

                    case H5S_SEL_ERROR:
                    case H5S_SEL_N:
                    default:
                        assert("unknown selection type" && 0);
                        break;
                } 
            }     
            
            else {
                switch (H5S_GET_SELECT_TYPE(space)) {
                    case H5S_SEL_NONE:
                        if (H5S__mpio_none_type(new_type, count, is_derived_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert 'none' selection to MPI type");
                        break;

                    case H5S_SEL_ALL:
                        if (H5S__mpio_all_type(space, elmt_size, new_type, count, is_derived_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert 'all' selection to MPI type");
                        break;

                    case H5S_SEL_POINTS:
                        if (H5S__mpio_point_type(space, elmt_size, new_type, count, is_derived_type,
                                                 do_permute, permute_map, is_permuted) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert 'point' selection to MPI type");
                        break;

                    case H5S_SEL_HYPERSLABS:
                        if ((H5S_SELECT_IS_REGULAR(space) == true)) {
                            if (H5S__mpio_reg_hyper_type(space, elmt_size, new_type, count, is_derived_type) <
                                0)
                                HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                            "couldn't convert regular 'hyperslab' selection to MPI type");
                        } 
                        else if (H5S__mpio_span_hyper_type(space, elmt_size, new_type, count,
                                                           is_derived_type) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL,
                                        "couldn't convert irregular 'hyperslab' selection to MPI type");
                        break;

                    case H5S_SEL_ERROR:
                    case H5S_SEL_N:
                    default:
                        assert("unknown selection type" && 0);
                        break;
                } 
            }     
            break;

        case H5S_NO_CLASS:
        default:
            assert("unknown dataspace type" && 0);
            break;
    } 

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

#endif 
