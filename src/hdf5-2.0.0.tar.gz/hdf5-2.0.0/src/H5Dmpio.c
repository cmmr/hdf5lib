/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Dmodule.h" 

#include "H5private.h"   
#include "H5CXprivate.h" 
#include "H5Dpkg.h"      
#include "H5Eprivate.h"  
#include "H5Fprivate.h"  
#include "H5FDprivate.h" 
#include "H5FLprivate.h" 
#include "H5MMprivate.h" 
#include "H5Oprivate.h"  
#include "H5Pprivate.h"  
#include "H5Sprivate.h"  
#include "H5SLprivate.h" 
#include "H5VMprivate.h" 

#ifdef H5_HAVE_PARALLEL

#define H5D_ONE_LINK_CHUNK_IO          0
#define H5D_MULTI_CHUNK_IO             1
#define H5D_ONE_LINK_CHUNK_IO_MORE_OPT 2
#define H5D_MULTI_CHUNK_IO_MORE_OPT    3

#define H5D_CHUNK_IO_MODE_COL 1

#define H5D_CHUNK_SELECT_REG 1

#define H5D_CHUNK_REDISTRIBUTE_THRES ((size_t)((25 * H5_MB) / sizeof(H5D_chunk_redistribute_info_t)))

#define H5D_CHUNK_NUM_SEND_MSGS_INIT 64

#define H5D_CHUNK_MOD_DATA_TAG 64

#define H5D_MPIO_INIT_CHUNK_IDX_INFO(index_info, dset)                                                       \
    do {                                                                                                     \
        (index_info).f      = (dset)->oloc.file;                                                             \
        (index_info).pline  = &((dset)->shared->dcpl_cache.pline);                                           \
        (index_info).layout = &((dset)->shared->layout);                                                     \
    } while (0)

typedef struct H5D_chunk_addr_info_t {
    
    haddr_t          piece_addr;
    H5D_piece_info_t piece_info;
} H5D_chunk_addr_info_t;

typedef enum H5D_mpio_no_rank0_bcast_cause_t {
    H5D_MPIO_RANK0_BCAST            = 0x00,
    H5D_MPIO_RANK0_NOT_H5S_ALL      = 0x01,
    H5D_MPIO_RANK0_NOT_CONTIGUOUS   = 0x02,
    H5D_MPIO_RANK0_NOT_FIXED_SIZE   = 0x04,
    H5D_MPIO_RANK0_GREATER_THAN_2GB = 0x08
} H5D_mpio_no_rank0_bcast_cause_t;

typedef struct H5D_chunk_alloc_info_t {
    H5F_block_t chunk_current;
    H5F_block_t chunk_new;
    hsize_t     chunk_idx;
    haddr_t     dset_oloc_addr;
} H5D_chunk_alloc_info_t;

typedef struct H5D_chunk_index_info_t {
    
    hsize_t chunk_idx;
    haddr_t dset_oloc_addr;

    unsigned filter_mask;
    bool     need_insert;
} H5D_chunk_index_info_t;

typedef struct H5D_filtered_collective_chunk_info_t {
    H5D_chunk_index_info_t index_info;

    H5D_piece_info_t *chunk_info;
    H5F_block_t       chunk_current;
    H5F_block_t       chunk_new;
    bool              need_read;
    bool              skip_filter_pline;
    size_t            io_size;
    size_t            chunk_buf_size;
    int               orig_owner;
    int               new_owner;
    int               num_writers;
    void             *buf;

    UT_hash_handle hh;
} H5D_filtered_collective_chunk_info_t;

typedef struct H5D_mpio_filtered_dset_info_t {
    const H5D_dset_io_info_t *dset_io_info;
    H5D_fill_buf_info_t       fb_info;
    H5D_chk_idx_info_t        chunk_idx_info;
    hsize_t                   file_chunk_size;
    haddr_t                   dset_oloc_addr;
    H5S_t                    *fill_space;
    bool                      should_fill;
    bool                      fb_info_init;
    bool                      index_empty;

    UT_hash_handle hh;
} H5D_mpio_filtered_dset_info_t;

typedef struct H5D_filtered_collective_io_info_t {
    H5D_filtered_collective_chunk_info_t *chunk_infos;
    H5D_filtered_collective_chunk_info_t *chunk_hash_table;
    size_t                                chunk_hash_table_keylen;
    size_t                                num_chunk_infos;
    size_t                                num_chunks_to_read;
    bool                                  all_dset_indices_empty;
    bool                                  no_dset_index_insert_methods;

    union {
        H5D_mpio_filtered_dset_info_t *single_dset_info;
        H5D_mpio_filtered_dset_info_t *dset_info_hash_table;
    } dset_info;
} H5D_filtered_collective_io_info_t;

typedef struct H5D_chunk_redistribute_info_t {
    H5F_block_t chunk_block;
    hsize_t     chunk_idx;
    haddr_t     dset_oloc_addr;
    int         orig_owner;
    int         new_owner;
    int         num_writers;
} H5D_chunk_redistribute_info_t;

typedef struct H5D_chunk_insert_info_t {
    H5F_block_t            chunk_block;
    H5D_chunk_index_info_t index_info;
} H5D_chunk_insert_info_t;

static herr_t H5D__piece_io(H5D_io_info_t *io_info);
static herr_t H5D__multi_chunk_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_info,
                                             int mpi_rank, int mpi_size);
static herr_t H5D__multi_chunk_filtered_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_infos,
                                                      size_t num_dset_infos, int mpi_rank, int mpi_size);
static herr_t H5D__link_piece_collective_io(H5D_io_info_t *io_info, int mpi_rank);
static herr_t H5D__link_chunk_filtered_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_infos,
                                                     size_t num_dset_infos, int mpi_rank, int mpi_size);
static herr_t H5D__inter_collective_io(H5D_io_info_t *io_info, const H5D_dset_io_info_t *di,
                                       H5S_t *file_space, H5S_t *mem_space);
static herr_t H5D__final_collective_io(H5D_io_info_t *io_info, hsize_t mpi_buf_count,
                                       MPI_Datatype mpi_file_type, MPI_Datatype mpi_buf_type);
static herr_t H5D__obtain_mpio_mode(H5D_io_info_t *io_info, H5D_dset_io_info_t *di, uint8_t assign_io_mode[],
                                    haddr_t chunk_addr[], int mpi_rank, int mpi_size);
static herr_t H5D__mpio_get_sum_chunk(const H5D_io_info_t *io_info, int *sum_chunkf);
static herr_t H5D__mpio_get_sum_chunk_dset(const H5D_io_info_t *io_info, const H5D_dset_io_info_t *dset_info,
                                           int *sum_chunkf);
static herr_t H5D__mpio_collective_filtered_chunk_io_setup(const H5D_io_info_t      *io_info,
                                                           const H5D_dset_io_info_t *di,
                                                           size_t num_dset_infos, int mpi_rank,
                                                           H5D_filtered_collective_io_info_t *chunk_list);
static herr_t H5D__mpio_redistribute_shared_chunks(H5D_filtered_collective_io_info_t *chunk_list,
                                                   const H5D_io_info_t *io_info, int mpi_rank, int mpi_size,
                                                   size_t **rank_chunks_assigned_map);
static herr_t H5D__mpio_redistribute_shared_chunks_int(H5D_filtered_collective_io_info_t *chunk_list,
                                                       size_t *num_chunks_assigned_map,
                                                       bool all_ranks_involved, const H5D_io_info_t *io_info,
                                                       int mpi_rank, int mpi_size);
static herr_t H5D__mpio_share_chunk_modification_data(H5D_filtered_collective_io_info_t *chunk_list,
                                                      H5D_io_info_t *io_info, int mpi_rank,
                                                      int H5_ATTR_NDEBUG_UNUSED mpi_size,
                                                      unsigned char          ***chunk_msg_bufs,
                                                      int                      *chunk_msg_bufs_len);
static herr_t H5D__mpio_collective_filtered_chunk_read(H5D_filtered_collective_io_info_t *chunk_list,
                                                       const H5D_io_info_t *io_info, size_t num_dset_infos,
                                                       int mpi_rank);
static herr_t H5D__mpio_collective_filtered_chunk_update(H5D_filtered_collective_io_info_t *chunk_list,
                                                         unsigned char                    **chunk_msg_bufs,
                                                         int chunk_msg_bufs_len, const H5D_io_info_t *io_info,
                                                         size_t num_dset_infos, int mpi_rank);
static herr_t H5D__mpio_collective_filtered_chunk_reallocate(H5D_filtered_collective_io_info_t *chunk_list,
                                                             size_t        *num_chunks_assigned_map,
                                                             H5D_io_info_t *io_info, size_t num_dset_infos,
                                                             int mpi_rank, int mpi_size);
static herr_t H5D__mpio_collective_filtered_chunk_reinsert(H5D_filtered_collective_io_info_t *chunk_list,
                                                           size_t        *num_chunks_assigned_map,
                                                           H5D_io_info_t *io_info, size_t num_dset_infos,
                                                           int mpi_rank, int mpi_size);
static herr_t H5D__mpio_get_chunk_redistribute_info_types(MPI_Datatype *contig_type,
                                                          bool         *contig_type_derived,
                                                          MPI_Datatype *resized_type,
                                                          bool         *resized_type_derived);
static herr_t H5D__mpio_get_chunk_alloc_info_types(MPI_Datatype *contig_type, bool *contig_type_derived,
                                                   MPI_Datatype *resized_type, bool *resized_type_derived);
static herr_t H5D__mpio_get_chunk_insert_info_types(MPI_Datatype *contig_type, bool *contig_type_derived,
                                                    MPI_Datatype *resized_type, bool *resized_type_derived);
static herr_t H5D__mpio_collective_filtered_vec_io(const H5D_filtered_collective_io_info_t *chunk_list,
                                                   H5F_shared_t *f_sh, H5D_io_op_type_t op_type);
static int    H5D__cmp_piece_addr(const void *chunk_addr_info1, const void *chunk_addr_info2);
static int    H5D__cmp_filtered_collective_io_info_entry(const void *filtered_collective_io_info_entry1,
                                                         const void *filtered_collective_io_info_entry2);
static int    H5D__cmp_chunk_redistribute_info(const void *entry1, const void *entry2);
static int    H5D__cmp_chunk_redistribute_info_orig_owner(const void *entry1, const void *entry2);

#ifdef H5Dmpio_DEBUG
static herr_t H5D__mpio_debug_init(void);
static herr_t H5D__mpio_dump_collective_filtered_chunk_list(H5D_filtered_collective_io_info_t *chunk_list,
                                                            int                                mpi_rank);
#endif

H5FL_EXTERN(H5S_sel_iter_t);

#ifdef H5Dmpio_DEBUG

static int               H5D_mpio_debug_flags_s[256];
static int               H5D_mpio_debug_rank_s[8] = {-1, -1, -1, -1, -1, -1, -1, -1};
static bool              H5D_mpio_debug_inited    = false;
static const char *const trace_in_pre             = "-> ";
static const char *const trace_out_pre            = "<- ";
static int               debug_indent             = 0;
static FILE             *debug_stream             = NULL;

#define H5D_MPIO_DEBUG_THIS_RANK(rank)                                                                       \
    (H5D_mpio_debug_rank_s[0] < 0 || rank == H5D_mpio_debug_rank_s[0] || rank == H5D_mpio_debug_rank_s[1] || \
     rank == H5D_mpio_debug_rank_s[2] || rank == H5D_mpio_debug_rank_s[3] ||                                 \
     rank == H5D_mpio_debug_rank_s[4] || rank == H5D_mpio_debug_rank_s[5] ||                                 \
     rank == H5D_mpio_debug_rank_s[6] || rank == H5D_mpio_debug_rank_s[7])

#define H5D_MPIO_DEBUG(rank, string)                                                                         \
    do {                                                                                                     \
        if (debug_stream && H5D_MPIO_DEBUG_THIS_RANK(rank)) {                                                \
            Rfprintf(debug_stream, "%*s(Rank %d) " string "\n", debug_indent, "", rank);                      \
            fflush(debug_stream);                                                                            \
        }                                                                                                    \
    } while (0)

#define H5D_MPIO_DEBUG_VA(rank, string, ...)                                                                 \
    do {                                                                                                     \
        if (debug_stream && H5D_MPIO_DEBUG_THIS_RANK(rank)) {                                                \
            Rfprintf(debug_stream, "%*s(Rank %d) " string "\n", debug_indent, "", rank, __VA_ARGS__);         \
            fflush(debug_stream);                                                                            \
        }                                                                                                    \
    } while (0)

#define H5D_MPIO_TRACE_ENTER(rank)                                                                           \
    do {                                                                                                     \
        bool trace_flag = H5D_mpio_debug_flags_s[(int)'t'];                                                  \
                                                                                                             \
        if (trace_flag) {                                                                                    \
            H5D_MPIO_DEBUG_VA(rank, "%s%s", trace_in_pre, __func__);                                         \
            debug_indent += (int)strlen(trace_in_pre);                                                       \
        }                                                                                                    \
    } while (0)

#define H5D_MPIO_TRACE_EXIT(rank)                                                                            \
    do {                                                                                                     \
        bool trace_flag = H5D_mpio_debug_flags_s[(int)'t'];                                                  \
                                                                                                             \
        if (trace_flag) {                                                                                    \
            debug_indent -= (int)strlen(trace_out_pre);                                                      \
            H5D_MPIO_DEBUG_VA(rank, "%s%s", trace_out_pre, __func__);                                        \
        }                                                                                                    \
    } while (0)

#define H5D_MPIO_TIME_START(rank, op_name)                                                                   \
    {                                                                                                        \
        bool              time_flag  = H5D_mpio_debug_flags_s[(int)'c'];                                     \
        double            start_time = 0.0, end_time = 0.0;                                                  \
        const char *const op = op_name;                                                                      \
                                                                                                             \
        if (time_flag) {                                                                                     \
            start_time = MPI_Wtime();                                                                        \
        }

#define H5D_MPIO_TIME_STOP(rank)                                                                             \
    if (time_flag) {                                                                                         \
        end_time = MPI_Wtime();                                                                              \
        H5D_MPIO_DEBUG_VA(rank, "'%s' took %f seconds", op, (end_time - start_time));                        \
    }                                                                                                        \
    }

static void
H5D__mpio_parse_debug_str(const char *s)
{
    FUNC_ENTER_PACKAGE_NOERR

    assert(s);

    while (*s) {
        int c = (int)(*s);

        if (c >= (int)'0' && c <= (int)'9') {
            bool range = false;

            if (*(s + 1) && *(s + 2))
                range = (int)*(s + 1) == '-' && (int)*(s + 2) >= (int)'0' && (int)*(s + 2) <= (int)'9';

            if (range) {
                int start_rank = c - (int)'0';
                int end_rank   = (int)*(s + 2) - '0';
                int num_ranks  = end_rank - start_rank + 1;
                int i;

                if (num_ranks > 8) {
                    end_rank  = start_rank + 7;
                    num_ranks = 8;
                }

                for (i = 0; i < num_ranks; i++)
                    H5D_mpio_debug_rank_s[i] = start_rank++;

                s += 3;
            }
            else
                H5D_mpio_debug_rank_s[0] = c - (int)'0';
        }
        else
            H5D_mpio_debug_flags_s[c]++;

        s++;
    }

    FUNC_LEAVE_NOAPI_VOID
}

static herr_t
H5D__mpio_debug_init(void)
{
    const char *debug_str;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE_NOERR

    assert(!H5D_mpio_debug_inited);

    
    memset(H5D_mpio_debug_flags_s, 0, sizeof(H5D_mpio_debug_flags_s));

    
    debug_str = getenv("H5D_mpio_Debug");
    if (debug_str)
        H5D__mpio_parse_debug_str(debug_str);

    if (H5DEBUG(D))
        debug_stream = Rstdout;

    H5D_mpio_debug_inited = true;

    FUNC_LEAVE_NOAPI(ret_value)
}

#endif

htri_t
H5D__mpio_opt_possible(H5D_io_info_t *io_info)
{
    H5FD_mpio_xfer_t io_xfer_mode; 
    size_t           i;
    H5D_t           *dset;
    const H5S_t     *file_space;
    const H5S_t     *mem_space;
    H5D_type_info_t *type_info;
    unsigned         local_cause[2] = {0, 0}; 
                                              
    unsigned global_cause[2] = {0, 0};        
    htri_t   is_vl_storage;    
    htri_t   ret_value = true; 

    FUNC_ENTER_PACKAGE

    
    assert(io_info);

    for (i = 0; i < io_info->count; i++) {
        assert(io_info->dsets_info[i].file_space);
        assert(io_info->dsets_info[i].mem_space);
    }

    
    if (H5CX_get_io_xfer_mode(&io_xfer_mode) < 0)
        
        local_cause[0] |= H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE;
    if (io_xfer_mode == H5FD_MPIO_INDEPENDENT)
        local_cause[0] |= H5D_MPIO_SET_INDEPENDENT;

    for (i = 0; i < io_info->count; i++) {
        
        if (io_info->dsets_info[i].skip_io)
            continue;

        
        dset       = io_info->dsets_info[i].dset;
        file_space = io_info->dsets_info[i].file_space;
        mem_space  = io_info->dsets_info[i].mem_space;
        type_info  = &io_info->dsets_info[i].type_info;

        
        
        if (!H5FD_mpi_opt_types_g)
            local_cause[0] |= H5D_MPIO_MPI_OPT_TYPES_ENV_VAR_DISABLED;

        
        assert(io_info->use_select_io != H5D_SELECTION_IO_MODE_DEFAULT);

        
        if (io_info->use_select_io != H5D_SELECTION_IO_MODE_ON) {
            
            if (!type_info->is_conv_noop)
                local_cause[0] |= H5D_MPIO_DATATYPE_CONVERSION;

            
            if (!type_info->is_xform_noop)
                local_cause[0] |= H5D_MPIO_DATA_TRANSFORMS;
        }

        
        if (!((H5S_SIMPLE == H5S_GET_EXTENT_TYPE(mem_space) || H5S_SCALAR == H5S_GET_EXTENT_TYPE(mem_space) ||
               H5S_NULL == H5S_GET_EXTENT_TYPE(mem_space)) &&
              (H5S_SIMPLE == H5S_GET_EXTENT_TYPE(file_space) ||
               H5S_SCALAR == H5S_GET_EXTENT_TYPE(file_space))))
            local_cause[0] |= H5D_MPIO_NOT_SIMPLE_OR_SCALAR_DATASPACES;

        
        if (!(dset->shared->layout.type == H5D_CONTIGUOUS || dset->shared->layout.type == H5D_CHUNKED))
            local_cause[0] |= H5D_MPIO_NOT_CONTIGUOUS_OR_CHUNKED_DATASET;

        
        if (dset->shared->dcpl_cache.efl.nused > 0)
            local_cause[0] |= H5D_MPIO_NOT_CONTIGUOUS_OR_CHUNKED_DATASET;

            

#ifndef H5_HAVE_PARALLEL_FILTERED_WRITES
        
        if (io_info->op_type == H5D_IO_OP_WRITE && dset->shared->dcpl_cache.pline.nused > 0)
            local_cause[0] |= H5D_MPIO_PARALLEL_FILTERED_WRITES_DISABLED;
#endif

        
        if ((io_info->use_select_io == H5D_SELECTION_IO_MODE_OFF) && local_cause[0] &&
            !(local_cause[0] &
              ~((unsigned)H5D_MPIO_DATATYPE_CONVERSION | (unsigned)H5D_MPIO_DATA_TRANSFORMS))) {
            assert(io_info->no_selection_io_cause & H5D_MPIO_NO_SELECTION_IO_CAUSES);
            local_cause[0] |= H5D_MPIO_NO_SELECTION_IO;
        }

        

        
        if (H5S_GET_SELECT_TYPE(file_space) != H5S_SEL_ALL)
            local_cause[1] |= H5D_MPIO_RANK0_NOT_H5S_ALL;
        
        else if (H5D_CONTIGUOUS != dset->shared->layout.type)
            
            local_cause[1] |= H5D_MPIO_RANK0_NOT_CONTIGUOUS;
        else if ((is_vl_storage = H5T_is_vl_storage(type_info->dset_type)) < 0)
            local_cause[0] |= H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE;
        else if (is_vl_storage)
            local_cause[1] |= H5D_MPIO_RANK0_NOT_FIXED_SIZE;
        else {
            size_t type_size; 

            
            if (0 == (type_size = H5T_GET_SIZE(type_info->dset_type)))
                local_cause[0] |= H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE;
            else {
                hssize_t snelmts; 

                
                if ((snelmts = H5S_GET_EXTENT_NPOINTS(file_space)) < 0)
                    local_cause[0] |= H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE;
                else {
                    hsize_t dset_size;

                    
                    dset_size = ((hsize_t)snelmts) * type_size;

                    
                    if (dset_size > ((hsize_t)(2.0F * H5_GB) - 1))
                        local_cause[1] |= H5D_MPIO_RANK0_GREATER_THAN_2GB;
                } 
            }     
        }         
    }             

    
    if (local_cause[0] & H5D_MPIO_SET_INDEPENDENT)
        global_cause[0] = local_cause[0];
    else {
        int mpi_code; 

        
        if (MPI_SUCCESS !=
            (mpi_code = MPI_Allreduce(local_cause, global_cause, 2, MPI_UNSIGNED, MPI_BOR, io_info->comm)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Allreduce failed", mpi_code)
    } 

    
    H5CX_set_mpio_local_no_coll_cause(local_cause[0]);
    H5CX_set_mpio_global_no_coll_cause(global_cause[0]);

    
    if (global_cause[0] == 0 && global_cause[1] == 0) {
        H5CX_set_mpio_rank0_bcast(true);
#ifdef H5_HAVE_INSTRUMENTED_LIBRARY
        H5CX_test_set_mpio_coll_rank0_bcast(true);
#endif 
    }  

    
    ret_value = global_cause[0] > 0 ? false : true;

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5D__mpio_get_no_coll_cause_strings(char *local_cause, size_t local_cause_len, char *global_cause,
                                    size_t global_cause_len)
{
    uint32_t local_no_coll_cause;
    uint32_t global_no_coll_cause;
    size_t   local_cause_bytes_written  = 0;
    size_t   global_cause_bytes_written = 0;
    int      nbits;
    herr_t   ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert((local_cause && local_cause_len > 0) || (global_cause && global_cause_len > 0));

    
    HDcompile_assert(H5D_MPIO_NO_COLLECTIVE_MAX_CAUSE == (H5D_mpio_no_collective_cause_t)0x200);

    
    if (local_cause)
        *local_cause = '\0';
    if (global_cause)
        *global_cause = '\0';

    
    if (H5CX_get_mpio_local_no_coll_cause(&local_no_coll_cause) < 0)
        HGOTO_ERROR(H5E_CONTEXT, H5E_CANTGET, FAIL, "unable to get local no collective cause value");
    if (H5CX_get_mpio_global_no_coll_cause(&global_no_coll_cause) < 0)
        HGOTO_ERROR(H5E_CONTEXT, H5E_CANTGET, FAIL, "unable to get global no collective cause value");

    
    nbits = 8 * sizeof(local_no_coll_cause);
    for (int bit_pos = 0; bit_pos < nbits; bit_pos++) {
        H5D_mpio_no_collective_cause_t cur_cause;
        const char                    *cause_str;
        size_t                         buf_space_left;

        cur_cause = (H5D_mpio_no_collective_cause_t)(1 << bit_pos);
        if (cur_cause == H5D_MPIO_NO_COLLECTIVE_MAX_CAUSE)
            break;

        switch (cur_cause) {
            case H5D_MPIO_SET_INDEPENDENT:
                cause_str = "independent I/O was requested";
                break;
            case H5D_MPIO_DATATYPE_CONVERSION:
                cause_str = "datatype conversions were required";
                break;
            case H5D_MPIO_DATA_TRANSFORMS:
                cause_str = "data transforms needed to be applied";
                break;
            case H5D_MPIO_MPI_OPT_TYPES_ENV_VAR_DISABLED:
                cause_str = "optimized MPI types flag wasn't set";
                break;
            case H5D_MPIO_NOT_SIMPLE_OR_SCALAR_DATASPACES:
                cause_str = "one of the dataspaces was neither simple nor scalar";
                break;
            case H5D_MPIO_NOT_CONTIGUOUS_OR_CHUNKED_DATASET:
                cause_str = "dataset was not contiguous or chunked";
                break;
            case H5D_MPIO_PARALLEL_FILTERED_WRITES_DISABLED:
                cause_str = "parallel writes to filtered datasets are disabled";
                break;
            case H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE:
                cause_str = "an error occurred while checking if collective I/O was possible";
                break;
            case H5D_MPIO_NO_SELECTION_IO:
                cause_str = "collective I/O may be supported by selection or vector I/O but that feature was "
                            "not possible (see causes via H5Pget_no_selection_io_cause())";
                break;

            case H5D_MPIO_COLLECTIVE:
            case H5D_MPIO_NO_COLLECTIVE_MAX_CAUSE:
            default:
                cause_str = "invalid or unknown no collective cause reason";
                assert(0 && "invalid or unknown no collective cause reason");
                break;
        }

        
        if (local_cause && (cur_cause & local_no_coll_cause)) {
            buf_space_left = local_cause_len - local_cause_bytes_written;

            
            if (buf_space_left && local_cause_bytes_written) {
                strncat(local_cause, "; ", buf_space_left);
                local_cause_bytes_written += MIN(buf_space_left, 2);
                buf_space_left -= MIN(buf_space_left, 2);
            }

            if (buf_space_left) {
                strncat(local_cause, cause_str, buf_space_left);
                local_cause_bytes_written += MIN(buf_space_left, strlen(cause_str));
            }
        }

        
        if (global_cause && (cur_cause & global_no_coll_cause)) {
            buf_space_left = global_cause_len - global_cause_bytes_written;

            
            if (buf_space_left && global_cause_bytes_written) {
                strncat(global_cause, "; ", buf_space_left);
                global_cause_bytes_written += MIN(buf_space_left, 2);
                buf_space_left -= MIN(buf_space_left, 2);
            }

            if (buf_space_left) {
                strncat(global_cause, cause_str, buf_space_left);
                global_cause_bytes_written += MIN(buf_space_left, strlen(cause_str));
            }
        }
    }

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5D__mpio_select_read(const H5D_io_info_t *io_info, hsize_t mpi_buf_count, H5S_t H5_ATTR_UNUSED *file_space,
                      H5S_t H5_ATTR_UNUSED *mem_space)
{
    void  *rbuf      = NULL;
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    rbuf = io_info->base_maddr.vp;

    
    H5_CHECK_OVERFLOW(mpi_buf_count, hsize_t, size_t);
    if (H5F_shared_block_read(io_info->f_sh, H5FD_MEM_DRAW, io_info->store_faddr, (size_t)mpi_buf_count,
                              rbuf) < 0)
        HGOTO_ERROR(H5E_IO, H5E_READERROR, FAIL, "can't finish collective parallel read");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5D__mpio_select_write(const H5D_io_info_t *io_info, hsize_t mpi_buf_count, H5S_t H5_ATTR_UNUSED *file_space,
                       H5S_t H5_ATTR_UNUSED *mem_space)
{
    const void *wbuf      = NULL;
    herr_t      ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    wbuf = io_info->base_maddr.cvp;

    
    H5_CHECK_OVERFLOW(mpi_buf_count, hsize_t, size_t);
    if (H5F_shared_block_write(io_info->f_sh, H5FD_MEM_DRAW, io_info->store_faddr, (size_t)mpi_buf_count,
                               wbuf) < 0)
        HGOTO_ERROR(H5E_IO, H5E_WRITEERROR, FAIL, "can't finish collective parallel write");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_get_sum_chunk(const H5D_io_info_t *io_info, int *sum_chunkf)
{
    int    num_chunkf; 
    size_t ori_num_chunkf;
    int    mpi_code; 
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    num_chunkf     = 0;
    ori_num_chunkf = io_info->pieces_added;
    H5_CHECKED_ASSIGN(num_chunkf, int, ori_num_chunkf, size_t);

    
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Allreduce(&num_chunkf, sum_chunkf, 1, MPI_INT, MPI_SUM, io_info->comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Allreduce failed", mpi_code)

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_get_sum_chunk_dset(const H5D_io_info_t *io_info, const H5D_dset_io_info_t *dset_info,
                             int *sum_chunkf)
{
    int    num_chunkf; 
    size_t ori_num_chunkf;
    int    mpi_code; 
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    assert(dset_info->layout->type == H5D_CHUNKED);

    
    num_chunkf     = 0;
    ori_num_chunkf = H5SL_count(dset_info->layout_io_info.chunk_map->dset_sel_pieces);
    H5_CHECKED_ASSIGN(num_chunkf, int, ori_num_chunkf, size_t);

    
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Allreduce(&num_chunkf, sum_chunkf, 1, MPI_INT, MPI_SUM, io_info->comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Allreduce failed", mpi_code)

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__piece_io(H5D_io_info_t *io_info)
{
    H5FD_mpio_chunk_opt_t chunk_opt_mode;
#ifdef H5Dmpio_DEBUG
    bool  log_file_flag  = false;
    FILE *debug_log_file = NULL;
#endif
    int      io_option        = H5D_MULTI_CHUNK_IO_MORE_OPT;
    bool     recalc_io_option = false;
    bool     use_multi_dset   = false;
    unsigned one_link_chunk_io_threshold; 
    int      sum_chunk = -1;
    int      mpi_rank;
    int      mpi_size;
    size_t   i;
    herr_t   ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    assert(io_info);
    assert(io_info->using_mpi_vfd);
    assert(io_info->count > 0);

    
    if ((mpi_rank = H5F_mpi_get_rank(io_info->dsets_info[0].dset->oloc.file)) < 0)
        HGOTO_ERROR(H5E_IO, H5E_MPI, FAIL, "unable to obtain MPI rank");
    if ((mpi_size = H5F_mpi_get_size(io_info->dsets_info[0].dset->oloc.file)) < 0)
        HGOTO_ERROR(H5E_IO, H5E_MPI, FAIL, "unable to obtain MPI size");

#ifdef H5Dmpio_DEBUG
    
    if (!H5D_mpio_debug_inited && H5D__mpio_debug_init() < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL, "can't initialize H5Dmpio debugging");

    
    log_file_flag = H5D_mpio_debug_flags_s[(int)'f'];
    if (log_file_flag) {
        char   debug_log_filename[1024];
        time_t time_now;

        snprintf(debug_log_filename, 1024, "H5Dmpio_debug.rank%d", mpi_rank);

        if (NULL == (debug_log_file = fopen(debug_log_filename, "a")))
            HGOTO_ERROR(H5E_IO, H5E_OPENERROR, FAIL, "couldn't open debugging log file");

        
        time_now = time(NULL);
        Rfprintf(debug_log_file, "##### %s", asctime(localtime(&time_now)));

        debug_stream = debug_log_file;
    }
#endif

    
    if (H5CX_get_mpio_chunk_opt_mode(&chunk_opt_mode) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't get chunk optimization option");

    if (H5FD_MPIO_CHUNK_ONE_IO == chunk_opt_mode)
        io_option = H5D_ONE_LINK_CHUNK_IO; 
    
    else if (H5FD_MPIO_CHUNK_MULTI_IO == chunk_opt_mode)
        io_option = H5D_MULTI_CHUNK_IO;
    else
        recalc_io_option = true;

    
    if (io_info->count > 1 && (io_option == H5D_ONE_LINK_CHUNK_IO || recalc_io_option)) {
        
        use_multi_dset = true;

        
        if (recalc_io_option && use_multi_dset) {
            
            if (H5CX_get_mpio_chunk_opt_num(&one_link_chunk_io_threshold) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL,
                            "couldn't get chunk optimization option threshold value");

            
            if (one_link_chunk_io_threshold > 0) {
                
                if (H5D__mpio_get_sum_chunk(io_info, &sum_chunk) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_CANTSWAP, FAIL,
                                "unable to obtain the total chunk number of all processes");

                
                if ((unsigned)sum_chunk / (unsigned)mpi_size < one_link_chunk_io_threshold) {
                    recalc_io_option = false;
                    use_multi_dset   = false;
                }
            }
        }
    }

    
    if (use_multi_dset) {
#ifdef H5_HAVE_INSTRUMENTED_LIBRARY
        
        if (H5D_ONE_LINK_CHUNK_IO == io_option) {
            if (H5CX_test_set_mpio_coll_chunk_link_hard(0) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
        } 
#endif    

        
        if (io_info->filtered_count > 0) {
            if (H5D__link_chunk_filtered_collective_io(io_info, io_info->dsets_info, io_info->count, mpi_rank,
                                                       mpi_size) < 0)
                HGOTO_ERROR(H5E_IO, (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                            FAIL, "couldn't finish filtered linked chunk MPI-IO");
        }

        
        if ((io_info->filtered_count == 0) || (io_info->filtered_count < io_info->count)) {
            
            if (H5D__link_piece_collective_io(io_info, mpi_rank) < 0)
                HGOTO_ERROR(H5E_IO, (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                            FAIL, "couldn't finish linked chunk MPI-IO");
        }
    }
    else {
        
        for (i = 0; i < io_info->count; i++) {
            if (io_info->dsets_info[i].skip_io)
                continue;

            if (io_info->dsets_info[i].layout->type == H5D_CONTIGUOUS) {
                
                H5D_mpio_actual_io_mode_t actual_io_mode = H5D_MPIO_CONTIGUOUS_COLLECTIVE;

                io_info->store_faddr = io_info->dsets_info[i].store->contig.dset_addr;
                io_info->base_maddr  = io_info->dsets_info[i].buf;

                if (H5D__inter_collective_io(io_info, &io_info->dsets_info[i],
                                             io_info->dsets_info[i].file_space,
                                             io_info->dsets_info[i].mem_space) < 0)
                    HGOTO_ERROR(H5E_IO, (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                FAIL, "couldn't finish shared collective MPI-IO");

                
                H5CX_set_mpio_actual_io_mode(actual_io_mode);
            }
            else {
                
                assert(io_info->dsets_info[i].layout->type == H5D_CHUNKED);

                
                if (recalc_io_option) {
                    
                    if (H5CX_get_mpio_chunk_opt_num(&one_link_chunk_io_threshold) < 0)
                        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL,
                                    "couldn't get chunk optimization option threshold value");

                    
                    if (one_link_chunk_io_threshold == 0) {
                        io_option        = H5D_ONE_LINK_CHUNK_IO_MORE_OPT;
                        recalc_io_option = false;
                    }
                    else {
                        
                        if (H5D__mpio_get_sum_chunk_dset(io_info, &io_info->dsets_info[i], &sum_chunk) < 0)
                            HGOTO_ERROR(H5E_DATASPACE, H5E_CANTSWAP, FAIL,
                                        "unable to obtain the total chunk number of all processes");

                        
                        
                        if ((unsigned)sum_chunk / (unsigned)mpi_size >= one_link_chunk_io_threshold)
                            io_option = H5D_ONE_LINK_CHUNK_IO_MORE_OPT;
                        else
                            io_option = H5D_MULTI_CHUNK_IO_MORE_OPT;
                    }
                }

                
                switch (io_option) {
                    case H5D_ONE_LINK_CHUNK_IO:
                    case H5D_ONE_LINK_CHUNK_IO_MORE_OPT:
                        
                        if (io_info->dsets_info[i].dset->shared->dcpl_cache.pline.nused > 0) {
                            if (H5D__link_chunk_filtered_collective_io(io_info, &io_info->dsets_info[i], 1,
                                                                       mpi_rank, mpi_size) < 0)
                                HGOTO_ERROR(
                                    H5E_IO,
                                    (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                    FAIL, "couldn't finish filtered linked chunk MPI-IO");
                        } 
                        else {
                            
                            if (io_info->count > 1) {
                                io_option        = H5D_MULTI_CHUNK_IO_MORE_OPT;
                                recalc_io_option = true;

                                if (H5D__multi_chunk_collective_io(io_info, &io_info->dsets_info[i], mpi_rank,
                                                                   mpi_size) < 0)
                                    HGOTO_ERROR(
                                        H5E_IO,
                                        (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                        FAIL, "couldn't finish optimized multiple chunk MPI-IO");
                            }
                            else {
                                
                                if (H5D__link_piece_collective_io(io_info, mpi_rank) < 0)
                                    HGOTO_ERROR(
                                        H5E_IO,
                                        (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                        FAIL, "couldn't finish linked chunk MPI-IO");
                            }
                        }

                        break;

                    case H5D_MULTI_CHUNK_IO: 
                    default:                 
                        
                        if (io_info->dsets_info[i].dset->shared->dcpl_cache.pline.nused > 0) {
                            if (H5D__multi_chunk_filtered_collective_io(io_info, &io_info->dsets_info[i], 1,
                                                                        mpi_rank, mpi_size) < 0)
                                HGOTO_ERROR(
                                    H5E_IO,
                                    (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                    FAIL, "couldn't finish optimized multiple filtered chunk MPI-IO");
                        } 
                        else {
                            
                            if (H5D__multi_chunk_collective_io(io_info, &io_info->dsets_info[i], mpi_rank,
                                                               mpi_size) < 0)
                                HGOTO_ERROR(
                                    H5E_IO,
                                    (H5D_IO_OP_READ == io_info->op_type ? H5E_READERROR : H5E_WRITEERROR),
                                    FAIL, "couldn't finish optimized multiple chunk MPI-IO");
                        }

                        break;
                } 

#ifdef H5_HAVE_INSTRUMENTED_LIBRARY
                {
                    
                    if (H5D_ONE_LINK_CHUNK_IO == io_option) {
                        if (H5CX_test_set_mpio_coll_chunk_link_hard(0) < 0)
                            HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
                    } 
                    else if (H5D_MULTI_CHUNK_IO == io_option) {
                        if (H5CX_test_set_mpio_coll_chunk_multi_hard(0) < 0)
                            HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
                    } 
                    else if (H5D_ONE_LINK_CHUNK_IO_MORE_OPT == io_option) {
                        if (H5CX_test_set_mpio_coll_chunk_link_num_true(0) < 0)
                            HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
                    } 
                    else if (H5D_MULTI_CHUNK_IO_MORE_OPT == io_option) {
                        if (H5CX_test_set_mpio_coll_chunk_link_num_false(0) < 0)
                            HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
                    } 
                }
#endif 
            }
        }
    }

done:
#ifdef H5Dmpio_DEBUG
    
    if (debug_log_file) {
        Rfprintf(debug_log_file, "##############\n\n");
        if (EOF == fclose(debug_log_file))
            HDONE_ERROR(H5E_IO, H5E_CLOSEERROR, FAIL, "couldn't close debugging log file");
        debug_stream = H5DEBUG(D) ? Rstdout : NULL;
    }
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5D__collective_read(H5D_io_info_t *io_info)
{
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    if (H5D__piece_io(io_info) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_READERROR, FAIL, "read error");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5D__collective_write(H5D_io_info_t *io_info)
{
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    if (H5D__piece_io(io_info) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_WRITEERROR, FAIL, "write error");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
#ifdef H5Dmpio_DEBUG
H5D__link_piece_collective_io(H5D_io_info_t *io_info, int mpi_rank)
#else
H5D__link_piece_collective_io(H5D_io_info_t *io_info, int H5_ATTR_UNUSED mpi_rank)
#endif
{
    MPI_Datatype  chunk_final_mtype; 
    bool          chunk_final_mtype_is_derived = false;
    MPI_Datatype  chunk_final_ftype; 
    bool          chunk_final_ftype_is_derived = false;
    H5D_storage_t ctg_store; 
    MPI_Datatype *chunk_mtype           = NULL;
    MPI_Datatype *chunk_ftype           = NULL;
    MPI_Aint     *chunk_file_disp_array = NULL;
    MPI_Aint     *chunk_mem_disp_array  = NULL;
    bool *chunk_mft_is_derived_array = NULL; 
    bool *chunk_mbt_is_derived_array =
        NULL;                          
    int *chunk_mpi_file_counts = NULL; 
    int *chunk_mpi_mem_counts  = NULL; 
    int  mpi_code;                     
    H5D_mpio_actual_chunk_opt_mode_t actual_chunk_opt_mode = H5D_MPIO_LINK_CHUNK;
    H5D_mpio_actual_io_mode_t        actual_io_mode        = 0;
    herr_t                           ret_value             = SUCCEED;

    FUNC_ENTER_PACKAGE

    
    for (size_t i = 0; i < io_info->count; i++) {
        
        if (io_info->dsets_info[i].skip_io)
            continue;

        
        if ((io_info->dsets_info[i].dset->shared->dcpl_cache.pline.nused > 0) &&
            (io_info->dsets_info[i].layout->type != H5D_CONTIGUOUS))
            continue;

        if (io_info->dsets_info[i].layout->type == H5D_CHUNKED)
            actual_io_mode |= H5D_MPIO_CHUNK_COLLECTIVE;
        else if (io_info->dsets_info[i].layout->type == H5D_CONTIGUOUS)
            actual_io_mode |= H5D_MPIO_CONTIGUOUS_COLLECTIVE;
        else
            HGOTO_ERROR(H5E_IO, H5E_UNSUPPORTED, FAIL, "unsupported storage layout");
    }

    
    H5CX_set_mpio_actual_chunk_opt(actual_chunk_opt_mode);

    
    H5CX_set_mpio_actual_io_mode(actual_io_mode);

    
    {
        hsize_t mpi_buf_count; 
        size_t  num_chunk;     

        H5D_piece_info_t *piece_info;

        
        H5_flexible_const_ptr_t base_buf_addr;
        base_buf_addr.cvp = NULL;

        
        assert(io_info->filtered_pieces_added <= io_info->pieces_added);
        num_chunk = io_info->pieces_added - io_info->filtered_pieces_added;
        H5_CHECK_OVERFLOW(num_chunk, size_t, int);

#ifdef H5Dmpio_DEBUG
        H5D_MPIO_DEBUG_VA(mpi_rank, "num_chunk = %zu\n", num_chunk);
#endif

        
        if (num_chunk) {
            bool need_sort = false;

            
            assert(io_info->sel_pieces[0]->faddr != HADDR_UNDEF);
            for (size_t i = 1; i < io_info->pieces_added; i++) {
                assert(io_info->sel_pieces[i]->faddr != HADDR_UNDEF);

                if (io_info->sel_pieces[i]->faddr < io_info->sel_pieces[i - 1]->faddr) {
                    need_sort = true;
                    break;
                }
            }

            
            if (need_sort)
                qsort(io_info->sel_pieces, io_info->pieces_added, sizeof(io_info->sel_pieces[0]),
                      H5D__cmp_piece_addr);

            
            if (NULL == (chunk_mtype = (MPI_Datatype *)H5MM_malloc(num_chunk * sizeof(MPI_Datatype))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk memory datatype buffer");
            if (NULL == (chunk_ftype = (MPI_Datatype *)H5MM_malloc(num_chunk * sizeof(MPI_Datatype))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk file datatype buffer");
            if (NULL == (chunk_file_disp_array = (MPI_Aint *)H5MM_malloc(num_chunk * sizeof(MPI_Aint))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk file displacement buffer");
            if (NULL == (chunk_mem_disp_array = (MPI_Aint *)H5MM_calloc(num_chunk * sizeof(MPI_Aint))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk memory displacement buffer");
            if (NULL == (chunk_mpi_mem_counts = (int *)H5MM_calloc(num_chunk * sizeof(int))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk memory counts buffer");
            if (NULL == (chunk_mpi_file_counts = (int *)H5MM_calloc(num_chunk * sizeof(int))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk file counts buffer");
            if (NULL == (chunk_mbt_is_derived_array = (bool *)H5MM_calloc(num_chunk * sizeof(bool))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk memory is derived datatype flags buffer");
            if (NULL == (chunk_mft_is_derived_array = (bool *)H5MM_calloc(num_chunk * sizeof(bool))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk file is derived datatype flags buffer");

            
            ctg_store.contig.dset_addr = HADDR_UNDEF;
            for (size_t i = 0; i < io_info->pieces_added; i++) {
                if (!io_info->sel_pieces[i]->filtered_dset) {
                    ctg_store.contig.dset_addr = io_info->sel_pieces[i]->faddr;
                    base_buf_addr              = io_info->sel_pieces[i]->dset_info->buf;
                    break;
                }
            }
            assert(ctg_store.contig.dset_addr != HADDR_UNDEF);

#ifdef H5Dmpio_DEBUG
            H5D_MPIO_DEBUG(mpi_rank, "before iterate over selected pieces\n");
#endif

            
            
            for (size_t i = 0, curr_idx = 0; i < io_info->pieces_added; i++) {
                hsize_t *permute_map = NULL; 
                bool is_permuted = false;

                
                piece_info = io_info->sel_pieces[i];

                
                if (piece_info->filtered_dset)
                    continue;

                
                
                if (H5S_mpio_space_type(piece_info->fspace, piece_info->dset_info->type_info.src_type_size,
                                        &chunk_ftype[curr_idx],                  
                                        &chunk_mpi_file_counts[curr_idx],        
                                        &(chunk_mft_is_derived_array[curr_idx]), 
                                        true,                                    
                                        &permute_map,                            
                                        &is_permuted ) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI file type");

                
                if (is_permuted)
                    assert(permute_map);
                if (H5S_mpio_space_type(piece_info->mspace, piece_info->dset_info->type_info.dst_type_size,
                                        &chunk_mtype[curr_idx], &chunk_mpi_mem_counts[curr_idx],
                                        &(chunk_mbt_is_derived_array[curr_idx]), false, 
                                        &permute_map, 
                                        &is_permuted ) < 0)
                    HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI buf type");
                
                if (is_permuted)
                    assert(!permute_map);

                
                chunk_file_disp_array[curr_idx] =
                    (MPI_Aint)piece_info->faddr - (MPI_Aint)ctg_store.contig.dset_addr;

                if (io_info->op_type == H5D_IO_OP_WRITE) {
                    chunk_mem_disp_array[curr_idx] =
                        (MPI_Aint)piece_info->dset_info->buf.cvp - (MPI_Aint)base_buf_addr.cvp;
                }
                else if (io_info->op_type == H5D_IO_OP_READ) {
                    chunk_mem_disp_array[curr_idx] =
                        (MPI_Aint)piece_info->dset_info->buf.vp - (MPI_Aint)base_buf_addr.vp;
                }

                curr_idx++;
            } 

            
            if (MPI_SUCCESS !=
                (mpi_code = MPI_Type_create_struct((int)num_chunk, chunk_mpi_file_counts,
                                                   chunk_file_disp_array, chunk_ftype, &chunk_final_ftype)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)

            if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(&chunk_final_ftype)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)
            chunk_final_ftype_is_derived = true;

            
            if (MPI_SUCCESS !=
                (mpi_code = MPI_Type_create_struct((int)num_chunk, chunk_mpi_mem_counts, chunk_mem_disp_array,
                                                   chunk_mtype, &chunk_final_mtype)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
            if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(&chunk_final_mtype)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)
            chunk_final_mtype_is_derived = true;

            
            for (size_t i = 0; i < num_chunk; i++) {
                if (chunk_mbt_is_derived_array[i])
                    if (MPI_SUCCESS != (mpi_code = MPI_Type_free(chunk_mtype + i)))
                        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

                if (chunk_mft_is_derived_array[i])
                    if (MPI_SUCCESS != (mpi_code = MPI_Type_free(chunk_ftype + i)))
                        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            } 

            
            mpi_buf_count = (hsize_t)1;
        }      
        else { 
            ctg_store.contig.dset_addr = 0;

            
            base_buf_addr = io_info->dsets_info[0].buf;

            
            chunk_final_ftype = MPI_BYTE;
            chunk_final_mtype = MPI_BYTE;

            
            mpi_buf_count = (hsize_t)0;
        } 

#ifdef H5Dmpio_DEBUG
        H5D_MPIO_DEBUG(mpi_rank, "before coming to final collective I/O");
#endif
        
        io_info->store_faddr = ctg_store.contig.dset_addr;
        io_info->base_maddr  = base_buf_addr;

        
        if (H5D__final_collective_io(io_info, mpi_buf_count, chunk_final_ftype, chunk_final_mtype) < 0)
            HGOTO_ERROR(H5E_IO, H5E_CANTGET, FAIL, "couldn't finish MPI-IO");
    }

done:
#ifdef H5Dmpio_DEBUG
    H5D_MPIO_DEBUG_VA(mpi_rank, "before freeing memory inside H5D_link_collective_io ret_value = %d",
                      ret_value);
#endif

    if (ret_value < 0)
        H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_NO_CHUNK_OPTIMIZATION);

    
    if (chunk_mtype)
        H5MM_xfree(chunk_mtype);
    if (chunk_ftype)
        H5MM_xfree(chunk_ftype);
    if (chunk_file_disp_array)
        H5MM_xfree(chunk_file_disp_array);
    if (chunk_mem_disp_array)
        H5MM_xfree(chunk_mem_disp_array);
    if (chunk_mpi_mem_counts)
        H5MM_xfree(chunk_mpi_mem_counts);
    if (chunk_mpi_file_counts)
        H5MM_xfree(chunk_mpi_file_counts);
    if (chunk_mbt_is_derived_array)
        H5MM_xfree(chunk_mbt_is_derived_array);
    if (chunk_mft_is_derived_array)
        H5MM_xfree(chunk_mft_is_derived_array);

    
    if (chunk_final_mtype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&chunk_final_mtype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    if (chunk_final_ftype_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&chunk_final_ftype)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__link_chunk_filtered_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_infos,
                                       size_t num_dset_infos, int mpi_rank, int mpi_size)
{
    H5D_filtered_collective_io_info_t chunk_list               = {0};
    unsigned char                   **chunk_msg_bufs           = NULL;
    size_t                           *rank_chunks_assigned_map = NULL;
    int                               chunk_msg_bufs_len       = 0;
    herr_t                            ret_value                = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(io_info);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_DEBUG_VA(mpi_rank, "Performing Linked-chunk I/O (%s) with MPI Comm size of %d",
                      io_info->op_type == H5D_IO_OP_WRITE ? "write" : "read", mpi_size);
    H5D_MPIO_TIME_START(mpi_rank, "Linked-chunk I/O");
#endif

    
    H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_LINK_CHUNK);

    
    H5CX_set_mpio_actual_io_mode(H5D_MPIO_CHUNK_COLLECTIVE);

    

    if (H5D__mpio_collective_filtered_chunk_io_setup(io_info, dset_infos, num_dset_infos, mpi_rank,
                                                     &chunk_list) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL, "couldn't construct filtered I/O info list");

    if (io_info->op_type == H5D_IO_OP_READ) { 
        if (H5D__mpio_collective_filtered_chunk_read(&chunk_list, io_info, num_dset_infos, mpi_rank) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "couldn't read filtered chunks");
    }
    else { 
        if (mpi_size > 1) {
            
            if (H5D__mpio_redistribute_shared_chunks(&chunk_list, io_info, mpi_rank, mpi_size,
                                                     &rank_chunks_assigned_map) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "unable to redistribute shared chunks");

            
            if (H5D__mpio_share_chunk_modification_data(&chunk_list, io_info, mpi_rank, mpi_size,
                                                        &chunk_msg_bufs, &chunk_msg_bufs_len) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                            "unable to send chunk modification data between MPI ranks");

            
            assert(chunk_list.num_chunk_infos == rank_chunks_assigned_map[mpi_rank]);
        }

        
        if (H5D__mpio_collective_filtered_chunk_update(&chunk_list, chunk_msg_bufs, chunk_msg_bufs_len,
                                                       io_info, num_dset_infos, mpi_rank) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "couldn't update modified chunks");

        
        HASH_CLEAR(hh, chunk_list.chunk_hash_table);

        
        if (H5D__mpio_collective_filtered_chunk_reallocate(&chunk_list, rank_chunks_assigned_map, io_info,
                                                           num_dset_infos, mpi_rank, mpi_size) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                        "couldn't collectively re-allocate file space for chunks");

        
        if (H5D__mpio_collective_filtered_vec_io(&chunk_list, io_info->f_sh, io_info->op_type) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "couldn't perform vector I/O on filtered chunks");

        
        for (size_t i = 0; i < chunk_list.num_chunk_infos; i++) {
            if (chunk_list.chunk_infos[i].buf) {
                H5MM_free(chunk_list.chunk_infos[i].buf);
                chunk_list.chunk_infos[i].buf = NULL;
            }
        }

        
        if (H5D__mpio_collective_filtered_chunk_reinsert(&chunk_list, rank_chunks_assigned_map, io_info,
                                                         num_dset_infos, mpi_rank, mpi_size) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                        "couldn't collectively re-insert modified chunks into chunk index");
    }

done:
    if (ret_value < 0)
        H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_NO_CHUNK_OPTIMIZATION);

    if (chunk_msg_bufs) {
        for (size_t i = 0; i < (size_t)chunk_msg_bufs_len; i++)
            H5MM_free(chunk_msg_bufs[i]);

        H5MM_free(chunk_msg_bufs);
    }

    HASH_CLEAR(hh, chunk_list.chunk_hash_table);

    if (rank_chunks_assigned_map)
        H5MM_free(rank_chunks_assigned_map);

    
    if (chunk_list.chunk_infos) {
        for (size_t i = 0; i < chunk_list.num_chunk_infos; i++)
            if (chunk_list.chunk_infos[i].buf)
                H5MM_free(chunk_list.chunk_infos[i].buf);

        H5MM_free(chunk_list.chunk_infos);
    } 

    
    if ((num_dset_infos == 1) && (chunk_list.dset_info.single_dset_info)) {
        H5D_mpio_filtered_dset_info_t *curr_dset_info = chunk_list.dset_info.single_dset_info;

        if (curr_dset_info->fb_info_init && H5D__fill_term(&curr_dset_info->fb_info) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "can't release fill buffer info");
        if (curr_dset_info->fill_space && H5S_close(curr_dset_info->fill_space) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CLOSEERROR, FAIL, "can't close fill space");

        H5MM_free(chunk_list.dset_info.single_dset_info);
        chunk_list.dset_info.single_dset_info = NULL;
    }
    else if ((num_dset_infos > 1) && (chunk_list.dset_info.dset_info_hash_table)) {
        H5D_mpio_filtered_dset_info_t *curr_dset_info;
        H5D_mpio_filtered_dset_info_t *tmp;

        HASH_ITER(hh, chunk_list.dset_info.dset_info_hash_table, curr_dset_info, tmp)
        {
            HASH_DELETE(hh, chunk_list.dset_info.dset_info_hash_table, curr_dset_info);

            if (curr_dset_info->fb_info_init && H5D__fill_term(&curr_dset_info->fb_info) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "can't release fill buffer info");
            if (curr_dset_info->fill_space && H5S_close(curr_dset_info->fill_space) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CLOSEERROR, FAIL, "can't close fill space");

            H5MM_free(curr_dset_info);
            curr_dset_info = NULL;
        }
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__multi_chunk_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_info, int mpi_rank,
                               int mpi_size)
{
    uint8_t                   *chunk_io_option = NULL;
    haddr_t                   *chunk_addr      = NULL;
    H5D_storage_t              store; 
    H5FD_mpio_collective_opt_t last_coll_opt_mode =
        H5FD_MPIO_COLLECTIVE_IO; 
    H5FD_mpio_collective_opt_t orig_coll_opt_mode =
        H5FD_MPIO_COLLECTIVE_IO;           
    size_t                    total_chunk; 
    size_t                    num_chunk;   
    H5SL_node_t              *piece_node      = NULL; 
    H5D_piece_info_t         *next_chunk_info = NULL; 
    size_t                    u;                      
    H5D_mpio_actual_io_mode_t actual_io_mode =
        H5D_MPIO_NO_COLLECTIVE; 
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE_TAG(dset_info->dset->oloc.addr)

    assert(dset_info->layout->type == H5D_CHUNKED);

    
    if (H5CX_get_mpio_coll_opt(&orig_coll_opt_mode) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get MPI-I/O collective_op property");

    
    H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_MULTI_CHUNK);

    
    H5_CHECKED_ASSIGN(total_chunk, size_t, dset_info->layout->u.chunk.nchunks, hsize_t);
    assert(total_chunk != 0);

    
    chunk_io_option = (uint8_t *)H5MM_calloc(total_chunk);
    chunk_addr      = (haddr_t *)H5MM_calloc(total_chunk * sizeof(haddr_t));

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_DEBUG_VA(mpi_rank, "total_chunk %zu", total_chunk);
#endif

    
    if (H5D__obtain_mpio_mode(io_info, dset_info, chunk_io_option, chunk_addr, mpi_rank, mpi_size) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTRECV, FAIL, "unable to obtain MPIO mode");

    
    io_info->base_maddr = dset_info->buf;

    
    dset_info->store = &store;

    
    num_chunk = H5SL_count(dset_info->layout_io_info.chunk_map->dset_sel_pieces);

    if (num_chunk) {
        
        if (NULL == (piece_node = H5SL_first(dset_info->layout_io_info.chunk_map->dset_sel_pieces)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't get piece node from skip list");
        if (NULL == (next_chunk_info = (H5D_piece_info_t *)H5SL_item(piece_node)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't get piece info from skip list");
    }

    
    for (u = 0; u < total_chunk; u++) {
        H5D_piece_info_t *chunk_info; 
        H5S_t            *fspace;     
        H5S_t            *mspace; 

#ifdef H5Dmpio_DEBUG
        H5D_MPIO_DEBUG_VA(mpi_rank, "mpi_rank = %d, chunk index = %zu", mpi_rank, u);
#endif

        
        assert(!num_chunk || next_chunk_info);
        assert(!num_chunk || next_chunk_info->index >= u);
        if (num_chunk && next_chunk_info->index == u) {
            
            chunk_info = next_chunk_info;

            
            num_chunk--;

            
            if (num_chunk) {
                if (NULL == (piece_node = H5SL_next(piece_node)))
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "chunk skip list terminated early");
                if (NULL == (next_chunk_info = (H5D_piece_info_t *)H5SL_item(piece_node)))
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't get piece info from skip list");
            }

            
            store.chunk.scaled = chunk_info->scaled;
        }
        else
            chunk_info = NULL;

        
        if (chunk_io_option[u] == H5D_CHUNK_IO_MODE_COL) {
#ifdef H5Dmpio_DEBUG
            H5D_MPIO_DEBUG_VA(mpi_rank, "inside collective chunk IO mpi_rank = %d, chunk index = %zu",
                              mpi_rank, u);
#endif

            
            if (chunk_info) {
                fspace = chunk_info->fspace;
                mspace = chunk_info->mspace;

                
                actual_io_mode = (H5D_mpio_actual_io_mode_t)(actual_io_mode | H5D_MPIO_CHUNK_COLLECTIVE);

            } 
            else {
                fspace = mspace = NULL;
            } 

            
            if (last_coll_opt_mode != H5FD_MPIO_COLLECTIVE_IO) {
                if (H5CX_set_mpio_coll_opt(H5FD_MPIO_COLLECTIVE_IO) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "can't switch to collective I/O");
                last_coll_opt_mode = H5FD_MPIO_COLLECTIVE_IO;
            } 

            
            io_info->store_faddr = chunk_addr[u];

            
            if (H5D__inter_collective_io(io_info, dset_info, fspace, mspace) < 0)
                HGOTO_ERROR(H5E_IO, H5E_CANTGET, FAIL, "couldn't finish shared collective MPI-IO");
        }      
        else { 
#ifdef H5Dmpio_DEBUG
            H5D_MPIO_DEBUG_VA(mpi_rank, "inside independent IO mpi_rank = %d, chunk index = %zu", mpi_rank,
                              u);
#endif

            assert(chunk_io_option[u] == 0);

            
            if (chunk_info) {
                fspace = chunk_info->fspace;
                mspace = chunk_info->mspace;

                
                actual_io_mode = (H5D_mpio_actual_io_mode_t)(actual_io_mode | H5D_MPIO_CHUNK_INDEPENDENT);
            } 
            else {
                fspace = mspace = NULL;
            } 

            
            if (last_coll_opt_mode != H5FD_MPIO_INDIVIDUAL_IO) {
                if (H5CX_set_mpio_coll_opt(H5FD_MPIO_INDIVIDUAL_IO) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "can't switch to individual I/O");
                last_coll_opt_mode = H5FD_MPIO_INDIVIDUAL_IO;
            } 

            
            io_info->store_faddr = chunk_addr[u];

            
            if (H5D__inter_collective_io(io_info, dset_info, fspace, mspace) < 0)
                HGOTO_ERROR(H5E_IO, H5E_CANTGET, FAIL, "couldn't finish shared collective MPI-IO");
#ifdef H5Dmpio_DEBUG
            H5D_MPIO_DEBUG(mpi_rank, "after inter collective IO");
#endif
        } 
    }     

    
    H5CX_set_mpio_actual_io_mode(actual_io_mode);

done:
    if (ret_value < 0)
        H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_NO_CHUNK_OPTIMIZATION);

    
    if (H5CX_set_mpio_coll_opt(orig_coll_opt_mode) < 0)
        HDONE_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "can't reset MPI-I/O collective_op property");

    
    if (chunk_io_option)
        H5MM_xfree(chunk_io_option);
    if (chunk_addr)
        H5MM_xfree(chunk_addr);

    FUNC_LEAVE_NOAPI_TAG(ret_value)
} 

static herr_t
H5D__multi_chunk_filtered_collective_io(H5D_io_info_t *io_info, H5D_dset_io_info_t *dset_infos,
                                        size_t num_dset_infos, int mpi_rank, int mpi_size)
{
    H5D_filtered_collective_io_info_t chunk_list     = {0};
    unsigned char                   **chunk_msg_bufs = NULL;
    bool                              have_chunk_to_process;
    size_t                            max_num_chunks;
    int                               chunk_msg_bufs_len = 0;
    int                               mpi_code;
    herr_t                            ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE_TAG(dset_infos->dset->oloc.addr)

    assert(io_info);
    assert(num_dset_infos == 1); 

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_DEBUG_VA(mpi_rank, "Performing Multi-chunk I/O (%s) with MPI Comm size of %d",
                      io_info->op_type == H5D_IO_OP_WRITE ? "write" : "read", mpi_size);
    H5D_MPIO_TIME_START(mpi_rank, "Multi-chunk I/O");
#endif

    
    H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_MULTI_CHUNK);

    
    H5CX_set_mpio_actual_io_mode(H5D_MPIO_CHUNK_COLLECTIVE);

    
    if (H5D__mpio_collective_filtered_chunk_io_setup(io_info, dset_infos, 1, mpi_rank, &chunk_list) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL, "couldn't construct filtered I/O info list");

    
    if (MPI_SUCCESS != (mpi_code = MPI_Allreduce(&chunk_list.num_chunk_infos, &max_num_chunks, 1,
                                                 MPI_UNSIGNED_LONG_LONG, MPI_MAX, io_info->comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Allreduce failed", mpi_code)

    
    if (0 == max_num_chunks)
        HGOTO_DONE(SUCCEED);

    if (io_info->op_type == H5D_IO_OP_READ) { 
        for (size_t i = 0; i < max_num_chunks; i++) {
            H5D_filtered_collective_io_info_t single_chunk_list = chunk_list;

            
            have_chunk_to_process = (i < chunk_list.num_chunk_infos);

            
            if (have_chunk_to_process) {
                single_chunk_list.chunk_infos        = &chunk_list.chunk_infos[i];
                single_chunk_list.num_chunk_infos    = 1;
                single_chunk_list.num_chunks_to_read = chunk_list.chunk_infos[i].need_read ? 1 : 0;
            }
            else {
                single_chunk_list.chunk_infos        = NULL;
                single_chunk_list.num_chunk_infos    = 0;
                single_chunk_list.num_chunks_to_read = 0;
            }

            if (H5D__mpio_collective_filtered_chunk_read(&single_chunk_list, io_info, 1, mpi_rank) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "couldn't read filtered chunks");

            if (have_chunk_to_process && chunk_list.chunk_infos[i].buf) {
                H5MM_free(chunk_list.chunk_infos[i].buf);
                chunk_list.chunk_infos[i].buf = NULL;
            }
        }
    }
    else { 
        if (mpi_size > 1) {
            
            if (H5D__mpio_redistribute_shared_chunks(&chunk_list, io_info, mpi_rank, mpi_size, NULL) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "unable to redistribute shared chunks");

            
            if (H5D__mpio_share_chunk_modification_data(&chunk_list, io_info, mpi_rank, mpi_size,
                                                        &chunk_msg_bufs, &chunk_msg_bufs_len) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                            "unable to send chunk modification data between MPI ranks");
        }

        
        for (size_t i = 0; i < max_num_chunks; i++) {
            H5D_filtered_collective_io_info_t single_chunk_list = chunk_list;

            
            have_chunk_to_process =
                (i < chunk_list.num_chunk_infos) && (mpi_rank == chunk_list.chunk_infos[i].new_owner);

            
            if (have_chunk_to_process) {
                single_chunk_list.chunk_infos        = &chunk_list.chunk_infos[i];
                single_chunk_list.num_chunk_infos    = 1;
                single_chunk_list.num_chunks_to_read = chunk_list.chunk_infos[i].need_read ? 1 : 0;
            }
            else {
                single_chunk_list.chunk_infos        = NULL;
                single_chunk_list.num_chunk_infos    = 0;
                single_chunk_list.num_chunks_to_read = 0;
            }

            
            if (H5D__mpio_collective_filtered_chunk_update(&single_chunk_list, chunk_msg_bufs,
                                                           chunk_msg_bufs_len, io_info, 1, mpi_rank) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "couldn't update modified chunks");

            
            if (H5D__mpio_collective_filtered_chunk_reallocate(&single_chunk_list, NULL, io_info, 1, mpi_rank,
                                                               mpi_size) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                            "couldn't collectively re-allocate file space for chunks");

            
            if (H5D__mpio_collective_filtered_vec_io(&single_chunk_list, io_info->f_sh, io_info->op_type) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                            "couldn't perform vector I/O on filtered chunks");

            
            if (have_chunk_to_process && chunk_list.chunk_infos[i].buf) {
                H5MM_free(chunk_list.chunk_infos[i].buf);
                chunk_list.chunk_infos[i].buf = NULL;
            }

            
            if (H5D__mpio_collective_filtered_chunk_reinsert(&single_chunk_list, NULL, io_info, 1, mpi_rank,
                                                             mpi_size) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                            "couldn't collectively re-insert modified chunks into chunk index");
        } 
    }

done:
    if (ret_value < 0)
        H5CX_set_mpio_actual_chunk_opt(H5D_MPIO_NO_CHUNK_OPTIMIZATION);

    if (chunk_msg_bufs) {
        for (size_t i = 0; i < (size_t)chunk_msg_bufs_len; i++)
            H5MM_free(chunk_msg_bufs[i]);

        H5MM_free(chunk_msg_bufs);
    }

    HASH_CLEAR(hh, chunk_list.chunk_hash_table);

    
    if (chunk_list.chunk_infos) {
        for (size_t i = 0; i < chunk_list.num_chunk_infos; i++)
            if (chunk_list.chunk_infos[i].buf)
                H5MM_free(chunk_list.chunk_infos[i].buf);

        H5MM_free(chunk_list.chunk_infos);
    } 

    
    if ((num_dset_infos == 1) && (chunk_list.dset_info.single_dset_info)) {
        H5D_mpio_filtered_dset_info_t *curr_dset_info = chunk_list.dset_info.single_dset_info;

        if (curr_dset_info->fb_info_init && H5D__fill_term(&curr_dset_info->fb_info) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "can't release fill buffer info");
        if (curr_dset_info->fill_space && H5S_close(curr_dset_info->fill_space) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CLOSEERROR, FAIL, "can't close fill space");

        H5MM_free(chunk_list.dset_info.single_dset_info);
        chunk_list.dset_info.single_dset_info = NULL;
    }
    else if ((num_dset_infos > 1) && (chunk_list.dset_info.dset_info_hash_table)) {
        H5D_mpio_filtered_dset_info_t *curr_dset_info;
        H5D_mpio_filtered_dset_info_t *tmp;

        HASH_ITER(hh, chunk_list.dset_info.dset_info_hash_table, curr_dset_info, tmp)
        {
            HASH_DELETE(hh, chunk_list.dset_info.dset_info_hash_table, curr_dset_info);

            if (curr_dset_info->fb_info_init && H5D__fill_term(&curr_dset_info->fb_info) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "can't release fill buffer info");
            if (curr_dset_info->fill_space && H5S_close(curr_dset_info->fill_space) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CLOSEERROR, FAIL, "can't close fill space");

            H5MM_free(curr_dset_info);
            curr_dset_info = NULL;
        }
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI_TAG(ret_value)
} 

static herr_t
H5D__inter_collective_io(H5D_io_info_t *io_info, const H5D_dset_io_info_t *di, H5S_t *file_space,
                         H5S_t *mem_space)
{
    int          mpi_buf_count; 
    bool         mbt_is_derived = false;
    bool         mft_is_derived = false;
    MPI_Datatype mpi_file_type, mpi_buf_type;
    int          mpi_code; 
#ifdef H5Dmpio_DEBUG
    int mpi_rank;
#endif
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

#ifdef H5Dmpio_DEBUG
    mpi_rank = H5F_mpi_get_rank(di->dset->oloc.file);
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Inter collective I/O");
    if (mpi_rank < 0)
        HGOTO_ERROR(H5E_IO, H5E_MPI, FAIL, "unable to obtain MPI rank");
#endif

    assert(io_info);

    if ((file_space != NULL) && (mem_space != NULL)) {
        int      mpi_file_count;     
        hsize_t *permute_map = NULL; 
        bool is_permuted = false;

        assert(di);

        
        
        if (H5S_mpio_space_type(file_space, di->type_info.src_type_size, &mpi_file_type, &mpi_file_count,
                                &mft_is_derived, 
                                true,            
                                &permute_map,    
                                &is_permuted ) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI file type");
        
        if (is_permuted)
            assert(permute_map);
        if (H5S_mpio_space_type(mem_space, di->type_info.src_type_size, &mpi_buf_type, &mpi_buf_count,
                                &mbt_is_derived, 
                                false,           
                                &permute_map     
                                ,
                                &is_permuted ) < 0)
            HGOTO_ERROR(H5E_DATASPACE, H5E_BADTYPE, FAIL, "couldn't create MPI buffer type");
        
        if (is_permuted)
            assert(!permute_map);
    } 
    else {
        
        mpi_buf_type   = MPI_BYTE;
        mpi_file_type  = MPI_BYTE;
        mpi_buf_count  = 0;
        mbt_is_derived = false;
        mft_is_derived = false;
    } 

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_DEBUG(mpi_rank, "before final collective I/O");
#endif

    
    if (H5D__final_collective_io(io_info, (hsize_t)mpi_buf_count, mpi_file_type, mpi_buf_type) < 0)
        HGOTO_ERROR(H5E_IO, H5E_CANTGET, FAIL, "couldn't finish collective MPI-IO");

done:
    
    if (mbt_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&mpi_buf_type)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    if (mft_is_derived && MPI_SUCCESS != (mpi_code = MPI_Type_free(&mpi_file_type)))
        HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_DEBUG_VA(mpi_rank, "before leaving inter_collective_io ret_value = %d", ret_value);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__final_collective_io(H5D_io_info_t *io_info, hsize_t mpi_buf_count, MPI_Datatype mpi_file_type,
                         MPI_Datatype mpi_buf_type)
{
#ifdef H5Dmpio_DEBUG
    int mpi_rank;
#endif
    herr_t ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

#ifdef H5Dmpio_DEBUG
    mpi_rank = H5F_mpi_get_rank(io_info->dsets_info[0].dset->oloc.file);
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Final collective I/O");
    if (mpi_rank < 0)
        HGOTO_ERROR(H5E_IO, H5E_MPI, FAIL, "unable to obtain MPI rank");
#endif

    
    if (H5CX_set_mpi_coll_datatypes(mpi_buf_type, mpi_file_type) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "can't set MPI-I/O collective I/O datatypes");

    if (io_info->op_type == H5D_IO_OP_WRITE) {
        if ((io_info->md_io_ops.single_write_md)(io_info, mpi_buf_count, NULL, NULL) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "optimized write failed");
    } 
    else {
        if ((io_info->md_io_ops.single_read_md)(io_info, mpi_buf_count, NULL, NULL) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "optimized read failed");
    } 

done:
#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_DEBUG_VA(mpi_rank, "ret_value before leaving final_collective_io=%d", ret_value);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static int
H5D__cmp_piece_addr(const void *piece_info1, const void *piece_info2)
{
    haddr_t addr1;
    haddr_t addr2;
    int     ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

    addr1 = (*((const H5D_piece_info_t *const *)piece_info1))->faddr;
    addr2 = (*((const H5D_piece_info_t *const *)piece_info2))->faddr;

    ret_value = H5_addr_cmp(addr1, addr2);

    FUNC_LEAVE_NOAPI(ret_value)
} 

static int
H5D__cmp_filtered_collective_io_info_entry(const void *filtered_collective_io_info_entry1,
                                           const void *filtered_collective_io_info_entry2)
{
    const H5D_filtered_collective_chunk_info_t *entry1;
    const H5D_filtered_collective_chunk_info_t *entry2;
    haddr_t                                     addr1     = HADDR_UNDEF;
    haddr_t                                     addr2     = HADDR_UNDEF;
    int                                         ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

    entry1 = (const H5D_filtered_collective_chunk_info_t *)filtered_collective_io_info_entry1;
    entry2 = (const H5D_filtered_collective_chunk_info_t *)filtered_collective_io_info_entry2;

    addr1 = entry1->chunk_new.offset;
    addr2 = entry2->chunk_new.offset;

    
    if (H5_addr_defined(addr1) && H5_addr_defined(addr2)) {
        ret_value = H5_addr_cmp(addr1, addr2);
    }
    else if (!H5_addr_defined(addr1) && !H5_addr_defined(addr2)) {
        haddr_t oloc_addr1 = entry1->index_info.dset_oloc_addr;
        haddr_t oloc_addr2 = entry2->index_info.dset_oloc_addr;

        if (0 == (ret_value = H5_addr_cmp(oloc_addr1, oloc_addr2))) {
            hsize_t chunk_idx1 = entry1->index_info.chunk_idx;
            hsize_t chunk_idx2 = entry2->index_info.chunk_idx;

            ret_value = (chunk_idx1 > chunk_idx2) - (chunk_idx1 < chunk_idx2);
        }
    }
    else
        ret_value = H5_addr_defined(addr1) ? 1 : -1;

    FUNC_LEAVE_NOAPI(ret_value)
} 

static int
H5D__cmp_chunk_redistribute_info(const void *_entry1, const void *_entry2)
{
    const H5D_chunk_redistribute_info_t *entry1;
    const H5D_chunk_redistribute_info_t *entry2;
    haddr_t                              oloc_addr1;
    haddr_t                              oloc_addr2;
    int                                  ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

    entry1 = (const H5D_chunk_redistribute_info_t *)_entry1;
    entry2 = (const H5D_chunk_redistribute_info_t *)_entry2;

    oloc_addr1 = entry1->dset_oloc_addr;
    oloc_addr2 = entry2->dset_oloc_addr;

    
    if (0 == (ret_value = H5_addr_cmp(oloc_addr1, oloc_addr2))) {
        hsize_t chunk_index1 = entry1->chunk_idx;
        hsize_t chunk_index2 = entry2->chunk_idx;

        
        if (chunk_index1 == chunk_index2) {
            int orig_owner1 = entry1->orig_owner;
            int orig_owner2 = entry2->orig_owner;

            

            ret_value = (orig_owner1 > orig_owner2) - (orig_owner1 < orig_owner2);
        }
        else
            ret_value = (chunk_index1 > chunk_index2) - (chunk_index1 < chunk_index2);
    }

    FUNC_LEAVE_NOAPI(ret_value)
} 

static int
H5D__cmp_chunk_redistribute_info_orig_owner(const void *_entry1, const void *_entry2)
{
    const H5D_chunk_redistribute_info_t *entry1;
    const H5D_chunk_redistribute_info_t *entry2;
    int                                  owner1    = -1;
    int                                  owner2    = -1;
    int                                  ret_value = 0;

    FUNC_ENTER_PACKAGE_NOERR

    entry1 = (const H5D_chunk_redistribute_info_t *)_entry1;
    entry2 = (const H5D_chunk_redistribute_info_t *)_entry2;

    owner1 = entry1->orig_owner;
    owner2 = entry2->orig_owner;

    if (owner1 == owner2) {
        haddr_t addr1 = entry1->chunk_block.offset;
        haddr_t addr2 = entry2->chunk_block.offset;

        
        if (H5_addr_defined(addr1) && H5_addr_defined(addr2)) {
            ret_value = H5_addr_cmp(addr1, addr2);
        }
        else if (!H5_addr_defined(addr1) && !H5_addr_defined(addr2)) {
            haddr_t oloc_addr1 = entry1->dset_oloc_addr;
            haddr_t oloc_addr2 = entry2->dset_oloc_addr;

            if (0 == (ret_value = H5_addr_cmp(oloc_addr1, oloc_addr2))) {
                hsize_t chunk_idx1 = entry1->chunk_idx;
                hsize_t chunk_idx2 = entry2->chunk_idx;

                ret_value = (chunk_idx1 > chunk_idx2) - (chunk_idx1 < chunk_idx2);
            }
        }
        else
            ret_value = H5_addr_defined(addr1) ? 1 : -1;
    }
    else
        ret_value = (owner1 > owner2) - (owner1 < owner2);

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__obtain_mpio_mode(H5D_io_info_t *io_info, H5D_dset_io_info_t *di, uint8_t assign_io_mode[],
                      haddr_t chunk_addr[], int mpi_rank, int mpi_size)
{
    size_t                  total_chunks;
    unsigned                percent_nproc_per_chunk, threshold_nproc_per_chunk;
    uint8_t                *io_mode_info      = NULL;
    uint8_t                *recv_io_mode_info = NULL;
    uint8_t                *mergebuf          = NULL;
    uint8_t                *tempbuf;
    H5SL_node_t            *chunk_node;
    H5D_piece_info_t       *chunk_info;
    H5P_coll_md_read_flag_t md_reads_file_flag;
    bool                    md_reads_context_flag;
    bool                    restore_md_reads_state = false;
    MPI_Comm                comm;
    int                     root;
    size_t                  ic;
    int                     mpi_code;
    herr_t                  ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(di->layout->type == H5D_CHUNKED);

    
    root = 0;
    comm = io_info->comm;

    
    H5_CHECKED_ASSIGN(total_chunks, size_t, di->layout->u.chunk.nchunks, hsize_t);
    if (H5CX_get_mpio_chunk_opt_ratio(&percent_nproc_per_chunk) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't get percent nproc per chunk");
    
    if (0 == percent_nproc_per_chunk) {
        if (H5D__chunk_addrmap(di->dset, chunk_addr) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get chunk address");
        for (ic = 0; ic < total_chunks; ic++)
            assign_io_mode[ic] = H5D_CHUNK_IO_MODE_COL;

        HGOTO_DONE(SUCCEED);
    } 

    threshold_nproc_per_chunk = (unsigned)mpi_size * percent_nproc_per_chunk / 100;

    
    if (NULL == (io_mode_info = (uint8_t *)H5MM_calloc(total_chunks)))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate I/O mode info buffer");
    if (NULL == (mergebuf = (uint8_t *)H5MM_malloc((sizeof(haddr_t) + 1) * total_chunks)))
        HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate mergebuf buffer");
    tempbuf = mergebuf + total_chunks;
    if (mpi_rank == root)
        if (NULL == (recv_io_mode_info = (uint8_t *)H5MM_malloc(total_chunks * (size_t)mpi_size)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate recv I/O mode info buffer");

    
    chunk_node = H5SL_first(di->layout_io_info.chunk_map->dset_sel_pieces);
    while (chunk_node) {
        chunk_info = (H5D_piece_info_t *)H5SL_item(chunk_node);

        io_mode_info[chunk_info->index] = H5D_CHUNK_SELECT_REG; 
        chunk_node                      = H5SL_next(chunk_node);
    } 

    
    H5_CHECK_OVERFLOW(total_chunks, size_t, int);
    if (MPI_SUCCESS != (mpi_code = MPI_Gather(io_mode_info, (int)total_chunks, MPI_BYTE, recv_io_mode_info,
                                              (int)total_chunks, MPI_BYTE, root, comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Gather failed", mpi_code)

    
    if (mpi_rank == root) {
        size_t    nproc;
        unsigned *nproc_per_chunk;

        
        if (H5F_get_coll_metadata_reads(di->dset->oloc.file)) {
#ifndef NDEBUG
            {
                H5D_chk_idx_info_t idx_info;
                bool               index_is_open;

                idx_info.f      = di->dset->oloc.file;
                idx_info.pline  = &di->dset->shared->dcpl_cache.pline;
                idx_info.layout = &di->dset->shared->layout;

                
                idx_info.layout->storage.u.chunk.ops->is_open(&idx_info, &index_is_open);
                assert(index_is_open);
            }
#endif

            md_reads_file_flag    = H5P_FORCE_FALSE;
            md_reads_context_flag = false;
            H5F_set_coll_metadata_reads(di->dset->oloc.file, &md_reads_file_flag, &md_reads_context_flag);
            restore_md_reads_state = true;
        }

        
        if (NULL == (nproc_per_chunk = (unsigned *)H5MM_calloc(total_chunks * sizeof(unsigned))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate nproc_per_chunk buffer");

        
        if (H5D__chunk_addrmap(di->dset, chunk_addr) < 0) {
            H5MM_free(nproc_per_chunk);
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get chunk address");
        } 

        
        for (nproc = 0; nproc < (size_t)mpi_size; nproc++) {
            uint8_t *tmp_recv_io_mode_info = recv_io_mode_info + (nproc * total_chunks);

            
            for (ic = 0; ic < total_chunks; ic++, tmp_recv_io_mode_info++) {
                if (*tmp_recv_io_mode_info != 0) {
                    nproc_per_chunk[ic]++;
                } 
            }     
        }         

        
        for (ic = 0; ic < total_chunks; ic++) {
            if (nproc_per_chunk[ic] > MAX(1, threshold_nproc_per_chunk)) {
                assign_io_mode[ic] = H5D_CHUNK_IO_MODE_COL;
            } 
        }     

        
        H5MM_memcpy(mergebuf, assign_io_mode, total_chunks);
        H5MM_memcpy(tempbuf, chunk_addr, sizeof(haddr_t) * total_chunks);

        H5MM_free(nproc_per_chunk);
    } 

    
    if ((sizeof(haddr_t) + 1) * total_chunks > INT_MAX)
        HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "result overflow");
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Bcast(mergebuf, (int)((sizeof(haddr_t) + 1) * total_chunks), MPI_BYTE, root, comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_BCast failed", mpi_code)

    H5MM_memcpy(assign_io_mode, mergebuf, total_chunks);
    H5MM_memcpy(chunk_addr, tempbuf, sizeof(haddr_t) * total_chunks);

#ifdef H5_HAVE_INSTRUMENTED_LIBRARY
    {
        bool coll_op = false;

        for (ic = 0; ic < total_chunks; ic++)
            if (assign_io_mode[ic] == H5D_CHUNK_IO_MODE_COL) {
                if (H5CX_test_set_mpio_coll_chunk_multi_ratio_coll(0) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
                coll_op = true;
                break;
            } 

        if (!coll_op)
            if (H5CX_test_set_mpio_coll_chunk_multi_ratio_ind(0) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTSET, FAIL, "unable to set property value");
    }
#endif

done:
    
    if (restore_md_reads_state)
        H5F_set_coll_metadata_reads(di->dset->oloc.file, &md_reads_file_flag, &md_reads_context_flag);

    if (io_mode_info)
        H5MM_free(io_mode_info);
    if (mergebuf)
        H5MM_free(mergebuf);
    if (recv_io_mode_info) {
        assert(mpi_rank == root);
        H5MM_free(recv_io_mode_info);
    } 

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_chunk_io_setup(const H5D_io_info_t *io_info, const H5D_dset_io_info_t *di,
                                             size_t num_dset_infos, int mpi_rank,
                                             H5D_filtered_collective_io_info_t *chunk_list)
{
    H5D_filtered_collective_chunk_info_t *local_info_array    = NULL;
    H5D_mpio_filtered_dset_info_t        *curr_dset_info      = NULL;
    size_t                                num_chunks_selected = 0;
    size_t                                num_chunks_to_read  = 0;
    size_t                                buf_idx             = 0;
    bool                                  need_sort           = false;
    herr_t                                ret_value           = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(io_info);
    assert(di);
    assert(chunk_list);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Filtered Collective I/O Setup");
#endif

    
    if (num_dset_infos > 1) {
        
        HDcompile_assert(offsetof(H5D_chunk_index_info_t, dset_oloc_addr) >
                         offsetof(H5D_chunk_index_info_t, chunk_idx));

        
        chunk_list->chunk_hash_table_keylen = offsetof(H5D_chunk_index_info_t, dset_oloc_addr) +
                                              sizeof(haddr_t) - offsetof(H5D_chunk_index_info_t, chunk_idx);
    }
    else
        chunk_list->chunk_hash_table_keylen = sizeof(hsize_t);

    chunk_list->all_dset_indices_empty       = true;
    chunk_list->no_dset_index_insert_methods = true;

    
    for (size_t dset_idx = 0; dset_idx < num_dset_infos; dset_idx++) {
        
        if (di[dset_idx].skip_io)
            continue;

        
        if ((di[dset_idx].dset->shared->dcpl_cache.pline.nused == 0) ||
            (di[dset_idx].layout->type == H5D_CONTIGUOUS))
            continue;

        assert(di[dset_idx].layout->type == H5D_CHUNKED);
        assert(di[dset_idx].layout->storage.type == H5D_CHUNKED);

        num_chunks_selected += H5SL_count(di[dset_idx].layout_io_info.chunk_map->dset_sel_pieces);
    }

    if (num_chunks_selected)
        if (NULL == (local_info_array = H5MM_malloc(num_chunks_selected * sizeof(*local_info_array))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate local io info array buffer");

    for (size_t dset_idx = 0; dset_idx < num_dset_infos; dset_idx++) {
        H5D_chunk_ud_t udata;
        H5O_fill_t    *fill_msg;
        haddr_t        prev_tag = HADDR_UNDEF;

        
        if (di[dset_idx].skip_io)
            continue;

        
        if ((di[dset_idx].dset->shared->dcpl_cache.pline.nused == 0) ||
            (di[dset_idx].layout->type == H5D_CONTIGUOUS))
            continue;

        assert(di[dset_idx].layout->storage.type == H5D_CHUNKED);
        assert(di[dset_idx].layout->storage.u.chunk.idx_type != H5D_CHUNK_IDX_NONE);

        
        if (NULL == (curr_dset_info = H5MM_malloc(sizeof(H5D_mpio_filtered_dset_info_t))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate space for dataset info");

        memset(&curr_dset_info->fb_info, 0, sizeof(H5D_fill_buf_info_t));

        H5D_MPIO_INIT_CHUNK_IDX_INFO(curr_dset_info->chunk_idx_info, di[dset_idx].dset);

        curr_dset_info->dset_io_info    = &di[dset_idx];
        curr_dset_info->file_chunk_size = di[dset_idx].dset->shared->layout.u.chunk.size;
        curr_dset_info->dset_oloc_addr  = di[dset_idx].dset->oloc.addr;
        curr_dset_info->fill_space      = NULL;
        curr_dset_info->fb_info_init    = false;
        curr_dset_info->index_empty     = false;

        
        fill_msg = &di[dset_idx].dset->shared->dcpl_cache.fill;
        curr_dset_info->should_fill =
            (fill_msg->fill_time == H5D_FILL_TIME_ALLOC) ||
            ((fill_msg->fill_time == H5D_FILL_TIME_IFSET) && fill_msg->fill_defined);

        if (curr_dset_info->should_fill) {
            hsize_t chunk_dims[H5S_MAX_RANK];

            assert(di[dset_idx].dset->shared->ndims == di[dset_idx].dset->shared->layout.u.chunk.ndims - 1);
            for (size_t dim_idx = 0; dim_idx < di[dset_idx].dset->shared->layout.u.chunk.ndims - 1; dim_idx++)
                chunk_dims[dim_idx] = di[dset_idx].dset->shared->layout.u.chunk.dim[dim_idx];

            
            if (NULL == (curr_dset_info->fill_space = H5S_create_simple(
                             di[dset_idx].dset->shared->layout.u.chunk.ndims - 1, chunk_dims, NULL)))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL, "unable to create chunk fill dataspace");

            
            if (H5D__fill_init(&curr_dset_info->fb_info, NULL, (H5MM_allocate_t)H5D__chunk_mem_alloc,
                               (void *)&di[dset_idx].dset->shared->dcpl_cache.pline,
                               (H5MM_free_t)H5D__chunk_mem_free,
                               (void *)&di[dset_idx].dset->shared->dcpl_cache.pline,
                               &di[dset_idx].dset->shared->dcpl_cache.fill, di[dset_idx].dset->shared->type,
                               0, curr_dset_info->file_chunk_size) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL, "can't initialize fill value buffer");

            curr_dset_info->fb_info_init = true;
        }

        
        if (fill_msg->alloc_time == H5D_ALLOC_TIME_INCR)
            if (H5D__chunk_index_empty(di[dset_idx].dset, &curr_dset_info->index_empty) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "couldn't determine if chunk index is empty");

        if ((fill_msg->alloc_time != H5D_ALLOC_TIME_INCR) || !curr_dset_info->index_empty)
            chunk_list->all_dset_indices_empty = false;

        if (curr_dset_info->chunk_idx_info.layout->storage.u.chunk.ops->insert)
            chunk_list->no_dset_index_insert_methods = false;

        
        if (num_dset_infos > 1) {
            HASH_ADD(hh, chunk_list->dset_info.dset_info_hash_table, dset_oloc_addr, sizeof(haddr_t),
                     curr_dset_info);
        }
        else
            chunk_list->dset_info.single_dset_info = curr_dset_info;
        curr_dset_info = NULL;

        

        
        H5AC_tag(di[dset_idx].dset->oloc.addr, &prev_tag);

        if (H5SL_count(di[dset_idx].layout_io_info.chunk_map->dset_sel_pieces)) {
            H5SL_node_t *chunk_node;
            bool         filter_partial_edge_chunks;

            
            filter_partial_edge_chunks = !(di[dset_idx].dset->shared->layout.u.chunk.flags &
                                           H5O_LAYOUT_CHUNK_DONT_FILTER_PARTIAL_BOUND_CHUNKS);

            chunk_node = H5SL_first(di[dset_idx].layout_io_info.chunk_map->dset_sel_pieces);
            while (chunk_node) {
                H5D_piece_info_t *chunk_info;
                hsize_t           select_npoints;

                chunk_info = (H5D_piece_info_t *)H5SL_item(chunk_node);
                assert(chunk_info->filtered_dset);

                
                if (H5D__chunk_lookup(di[dset_idx].dset, chunk_info->scaled, &udata) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "error looking up chunk address");

                
                local_info_array[buf_idx].chunk_info     = chunk_info;
                local_info_array[buf_idx].chunk_buf_size = 0;
                local_info_array[buf_idx].num_writers    = 0;
                local_info_array[buf_idx].orig_owner     = mpi_rank;
                local_info_array[buf_idx].new_owner      = mpi_rank;
                local_info_array[buf_idx].buf            = NULL;

                select_npoints = H5S_GET_SELECT_NPOINTS(chunk_info->fspace);
                local_info_array[buf_idx].io_size =
                    (size_t)select_npoints * di[dset_idx].type_info.dst_type_size;

                
                if (io_info->op_type == H5D_IO_OP_READ)
                    local_info_array[buf_idx].need_read = true;
                else {
                    local_info_array[buf_idx].need_read =
                        local_info_array[buf_idx].io_size <
                        (size_t)di[dset_idx].dset->shared->layout.u.chunk.size;
                }

                if (local_info_array[buf_idx].need_read)
                    num_chunks_to_read++;

                local_info_array[buf_idx].skip_filter_pline = false;
                if (!filter_partial_edge_chunks) {
                    
                    if (H5D__chunk_is_partial_edge_chunk(
                            di[dset_idx].dset->shared->ndims, di[dset_idx].dset->shared->layout.u.chunk.dim,
                            chunk_info->scaled, di[dset_idx].dset->shared->curr_dims))
                        local_info_array[buf_idx].skip_filter_pline = true;
                }

                
                local_info_array[buf_idx].chunk_current = udata.chunk_block;
                local_info_array[buf_idx].chunk_new     = udata.chunk_block;

                
                if (!need_sort && buf_idx) {
                    haddr_t curr_chunk_offset = local_info_array[buf_idx].chunk_current.offset;
                    haddr_t prev_chunk_offset = local_info_array[buf_idx - 1].chunk_current.offset;

                    if (!H5_addr_defined(prev_chunk_offset) || !H5_addr_defined(curr_chunk_offset) ||
                        (curr_chunk_offset < prev_chunk_offset))
                        need_sort = true;
                }

                
                memset(&local_info_array[buf_idx].index_info, 0, sizeof(H5D_chunk_index_info_t));

                
                if (di[dset_idx].dset->shared->layout.u.chunk.idx_type == H5D_CHUNK_IDX_EARRAY)
                    local_info_array[buf_idx].index_info.chunk_idx = udata.chunk_idx;
                else
                    local_info_array[buf_idx].index_info.chunk_idx = chunk_info->index;

                assert(H5_addr_defined(di[dset_idx].dset->oloc.addr));
                local_info_array[buf_idx].index_info.dset_oloc_addr = di[dset_idx].dset->oloc.addr;

                local_info_array[buf_idx].index_info.filter_mask = udata.filter_mask;
                local_info_array[buf_idx].index_info.need_insert = false;

                buf_idx++;

                chunk_node = H5SL_next(chunk_node);
            }
        }

        
        H5AC_tag(prev_tag, NULL);
    }

    
    if (local_info_array && need_sort)
        qsort(local_info_array, num_chunks_selected, sizeof(H5D_filtered_collective_chunk_info_t),
              H5D__cmp_filtered_collective_io_info_entry);

    chunk_list->chunk_infos        = local_info_array;
    chunk_list->num_chunk_infos    = num_chunks_selected;
    chunk_list->num_chunks_to_read = num_chunks_to_read;

#ifdef H5Dmpio_DEBUG
    H5D__mpio_dump_collective_filtered_chunk_list(chunk_list, mpi_rank);
#endif

done:
    if (ret_value < 0) {
        
        if (curr_dset_info) {
            if (curr_dset_info->fb_info_init && H5D__fill_term(&curr_dset_info->fb_info) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "can't release fill buffer info");
            if (curr_dset_info->fill_space && H5S_close(curr_dset_info->fill_space) < 0)
                HDONE_ERROR(H5E_DATASET, H5E_CLOSEERROR, FAIL, "can't close fill space");

            H5MM_free(curr_dset_info);
            curr_dset_info = NULL;

            if (num_dset_infos == 1)
                chunk_list->dset_info.single_dset_info = NULL;
        }

        
        if (num_dset_infos > 1) {
            H5D_mpio_filtered_dset_info_t *tmp;

            HASH_ITER(hh, chunk_list->dset_info.dset_info_hash_table, curr_dset_info, tmp)
            {
                HASH_DELETE(hh, chunk_list->dset_info.dset_info_hash_table, curr_dset_info);
                H5MM_free(curr_dset_info);
                curr_dset_info = NULL;
            }
        }

        if (num_dset_infos == 1)
            chunk_list->dset_info.single_dset_info = NULL;
        else
            chunk_list->dset_info.dset_info_hash_table = NULL;

        H5MM_free(local_info_array);
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_redistribute_shared_chunks(H5D_filtered_collective_io_info_t *chunk_list,
                                     const H5D_io_info_t *io_info, int mpi_rank, int mpi_size,
                                     size_t **rank_chunks_assigned_map)
{
    bool    redistribute_on_all_ranks;
    size_t *num_chunks_map       = NULL;
    size_t  coll_chunk_list_size = 0;
    int     mpi_code;
    herr_t  ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(io_info);
    assert(mpi_size > 1); 

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Redistribute shared chunks");
#endif

    
    if (NULL == (num_chunks_map = H5MM_malloc((size_t)mpi_size * sizeof(*num_chunks_map))))
        HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "couldn't allocate assigned chunks array");

    
    if (MPI_SUCCESS != (mpi_code = MPI_Allgather(&chunk_list->num_chunk_infos, 1, H5_SIZE_T_AS_MPI_TYPE,
                                                 num_chunks_map, 1, H5_SIZE_T_AS_MPI_TYPE, io_info->comm)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Allgather failed", mpi_code)

    for (int curr_rank = 0; curr_rank < mpi_size; curr_rank++)
        coll_chunk_list_size += num_chunks_map[curr_rank];

    
    redistribute_on_all_ranks = coll_chunk_list_size < H5D_CHUNK_REDISTRIBUTE_THRES;

    if (H5D__mpio_redistribute_shared_chunks_int(chunk_list, num_chunks_map, redistribute_on_all_ranks,
                                                 io_info, mpi_rank, mpi_size) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTREDISTRIBUTE, FAIL, "can't redistribute shared chunks");

    
    if (rank_chunks_assigned_map) {
        
        if (!redistribute_on_all_ranks) {
            if (MPI_SUCCESS !=
                (mpi_code = MPI_Bcast(num_chunks_map, mpi_size, H5_SIZE_T_AS_MPI_TYPE, 0, io_info->comm)))
                HMPI_GOTO_ERROR(FAIL, "couldn't broadcast chunk mapping to other ranks", mpi_code)
        }

        *rank_chunks_assigned_map = num_chunks_map;
    }

done:
    if (!rank_chunks_assigned_map || (ret_value < 0)) {
        num_chunks_map = H5MM_xfree(num_chunks_map);
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_redistribute_shared_chunks_int(H5D_filtered_collective_io_info_t *chunk_list,
                                         size_t *num_chunks_assigned_map, bool all_ranks_involved,
                                         const H5D_io_info_t *io_info, int mpi_rank, int mpi_size)
{
    MPI_Datatype struct_type;
    MPI_Datatype packed_type;
    bool         struct_type_derived         = false;
    bool         packed_type_derived         = false;
    size_t       coll_chunk_list_num_entries = 0;
    void        *coll_chunk_list             = NULL;
    int         *counts_disps_array          = NULL;
    int         *counts_ptr                  = NULL;
    int         *displacements_ptr           = NULL;
    int          num_chunks_int;
    int          mpi_code;
    herr_t       ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(num_chunks_assigned_map);
    assert(io_info);
    assert(mpi_size > 1);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Redistribute shared chunks (internal)");
#endif

    
    H5_CHECKED_ASSIGN(num_chunks_int, int, num_chunks_assigned_map[mpi_rank], size_t);

    

    if (all_ranks_involved || (mpi_rank == 0)) {
        
        if (NULL == (counts_disps_array = H5MM_malloc(2 * (size_t)mpi_size * sizeof(*counts_disps_array)))) {
            
            HDONE_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                        "couldn't allocate receive counts and displacements array");
        }
        else {
            
            counts_ptr = counts_disps_array;

            for (int curr_rank = 0; curr_rank < mpi_size; curr_rank++)
                H5_CHECKED_ASSIGN(counts_ptr[curr_rank], int, num_chunks_assigned_map[curr_rank], size_t);

            
            displacements_ptr = &counts_disps_array[mpi_size];

            *displacements_ptr = 0;
            for (int curr_rank = 1; curr_rank < mpi_size; curr_rank++)
                displacements_ptr[curr_rank] = displacements_ptr[curr_rank - 1] + counts_ptr[curr_rank - 1];
        }
    }

    
    if (H5D__mpio_get_chunk_redistribute_info_types(&packed_type, &packed_type_derived, &struct_type,
                                                    &struct_type_derived) < 0) {
        
        HDONE_ERROR(H5E_DATASET, H5E_CANTGET, FAIL,
                    "can't create derived datatypes for chunk redistribution info");
    }

    
    if (H5_mpio_gatherv_alloc(chunk_list->chunk_infos, num_chunks_int, struct_type, counts_ptr,
                              displacements_ptr, packed_type, all_ranks_involved, 0, io_info->comm, mpi_rank,
                              mpi_size, &coll_chunk_list, &coll_chunk_list_num_entries) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGATHER, FAIL,
                    "can't gather chunk redistribution info to involved ranks");

    
    if (all_ranks_involved) {
        counts_disps_array = H5MM_xfree(counts_disps_array);
    }

    
    if (coll_chunk_list_num_entries == 0)
        HGOTO_DONE(SUCCEED);

    

    if (all_ranks_involved || (mpi_rank == 0)) {
        H5D_chunk_redistribute_info_t *chunk_entry;

        
        memset(num_chunks_assigned_map, 0, (size_t)mpi_size * sizeof(*num_chunks_assigned_map));

        
        qsort(coll_chunk_list, coll_chunk_list_num_entries, sizeof(H5D_chunk_redistribute_info_t),
              H5D__cmp_chunk_redistribute_info);

        
        chunk_entry = &((H5D_chunk_redistribute_info_t *)coll_chunk_list)[0];
        for (size_t entry_idx = 0; entry_idx < coll_chunk_list_num_entries;) {
            haddr_t curr_oloc_addr;
            hsize_t curr_chunk_idx;
            size_t  set_begin_index;
            bool    keep_processing;
            int     num_writers;
            int     new_chunk_owner;

            
            new_chunk_owner = chunk_entry->orig_owner;

            
            curr_oloc_addr = chunk_entry->dset_oloc_addr;
            curr_chunk_idx = chunk_entry->chunk_idx;

            
            num_writers = 0;

            
            set_begin_index = entry_idx;

            
            do {
                
                if (num_chunks_assigned_map[chunk_entry->orig_owner] <
                    num_chunks_assigned_map[new_chunk_owner])
                    new_chunk_owner = chunk_entry->orig_owner;

                
                num_writers++;

                chunk_entry++;

                keep_processing =
                    
                    (++entry_idx < coll_chunk_list_num_entries) &&
                    
                    (H5_addr_eq(chunk_entry->dset_oloc_addr, curr_oloc_addr)) &&
                    
                    (chunk_entry->chunk_idx == curr_chunk_idx);
            } while (keep_processing);

            
            assert(num_writers <= mpi_size);

            
            for (; set_begin_index < entry_idx; set_begin_index++) {
                H5D_chunk_redistribute_info_t *entry;

                entry = &((H5D_chunk_redistribute_info_t *)coll_chunk_list)[set_begin_index];

                entry->new_owner   = new_chunk_owner;
                entry->num_writers = num_writers;
            }

            
            num_chunks_assigned_map[new_chunk_owner]++;
        }

        
        qsort(coll_chunk_list, coll_chunk_list_num_entries, sizeof(H5D_chunk_redistribute_info_t),
              H5D__cmp_chunk_redistribute_info_orig_owner);
    }

    if (all_ranks_involved) {
        size_t entry_idx;

        
        for (entry_idx = 0; entry_idx < coll_chunk_list_num_entries; entry_idx++)
            if (mpi_rank == ((H5D_chunk_redistribute_info_t *)coll_chunk_list)[entry_idx].orig_owner)
                break;

        for (size_t info_idx = 0; info_idx < (size_t)num_chunks_int; info_idx++) {
            H5D_chunk_redistribute_info_t *coll_entry;

            coll_entry = &((H5D_chunk_redistribute_info_t *)coll_chunk_list)[entry_idx++];

            chunk_list->chunk_infos[info_idx].new_owner   = coll_entry->new_owner;
            chunk_list->chunk_infos[info_idx].num_writers = coll_entry->num_writers;

            
            if (chunk_list->chunk_infos[info_idx].need_read &&
                (chunk_list->chunk_infos[info_idx].new_owner != mpi_rank)) {
                chunk_list->chunk_infos[info_idx].need_read = false;

                assert(chunk_list->num_chunks_to_read > 0);
                chunk_list->num_chunks_to_read--;
            }
        }
    }
    else {
        
        if (MPI_SUCCESS !=
            (mpi_code = MPI_Scatterv(coll_chunk_list, counts_ptr, displacements_ptr, packed_type,
                                     chunk_list->chunk_infos, num_chunks_int, struct_type, 0, io_info->comm)))
            HMPI_GOTO_ERROR(FAIL, "unable to scatter shared chunks info buffer", mpi_code)

        
        for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
            if ((chunk_list->chunk_infos[info_idx].new_owner != mpi_rank) &&
                chunk_list->chunk_infos[info_idx].need_read) {
                chunk_list->chunk_infos[info_idx].need_read = false;

                assert(chunk_list->num_chunks_to_read > 0);
                chunk_list->num_chunks_to_read--;
            }
        }
    }

#ifdef H5Dmpio_DEBUG
    H5D__mpio_dump_collective_filtered_chunk_list(chunk_list, mpi_rank);
#endif

done:
    H5MM_free(coll_chunk_list);

    if (struct_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&struct_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (packed_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&packed_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

    H5MM_free(counts_disps_array);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_share_chunk_modification_data(H5D_filtered_collective_io_info_t *chunk_list, H5D_io_info_t *io_info,
                                        int mpi_rank, int H5_ATTR_NDEBUG_UNUSED mpi_size,
                                        unsigned char ***chunk_msg_bufs, int *chunk_msg_bufs_len)
{
    H5D_filtered_collective_chunk_info_t *chunk_table       = NULL;
    H5S_sel_iter_t                       *mem_iter          = NULL;
    unsigned char                       **msg_send_bufs     = NULL;
    unsigned char                       **msg_recv_bufs     = NULL;
    MPI_Request                          *send_requests     = NULL;
    MPI_Request                          *recv_requests     = NULL;
    MPI_Request                           ibarrier          = MPI_REQUEST_NULL;
    bool                                  mem_iter_init     = false;
    bool                                  ibarrier_posted   = false;
    size_t                                send_bufs_nalloc  = 0;
    size_t                                num_send_requests = 0;
    size_t                                num_recv_requests = 0;
    size_t                                num_msgs_incoming = 0;
    size_t                                hash_keylen       = 0;
    size_t                                last_assigned_idx;
    int                                   mpi_code;
    herr_t                                ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(io_info);
    assert(mpi_size > 1);
    assert(chunk_msg_bufs);
    assert(chunk_msg_bufs_len);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Share chunk modification data");
#endif

    
    H5CX_set_libver_bounds(NULL);

    if (chunk_list->num_chunk_infos > 0) {
        hash_keylen = chunk_list->chunk_hash_table_keylen;
        assert(hash_keylen > 0);

        
        if (NULL == (mem_iter = H5FL_MALLOC(H5S_sel_iter_t)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate dataspace selection iterator");

        
        send_bufs_nalloc = H5D_CHUNK_NUM_SEND_MSGS_INIT;
        if (NULL == (msg_send_bufs = H5MM_malloc(send_bufs_nalloc * sizeof(*msg_send_bufs))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                        "couldn't allocate chunk modification message buffer array");

        if (NULL == (send_requests = H5MM_malloc(send_bufs_nalloc * sizeof(*send_requests))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate send requests array");
    }

    
    last_assigned_idx = 0;
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = &chunk_list->chunk_infos[info_idx];

        if (mpi_rank == chunk_entry->new_owner) {
            num_msgs_incoming += (size_t)(chunk_entry->num_writers - 1);

            
            chunk_list->chunk_infos[last_assigned_idx] = chunk_list->chunk_infos[info_idx];

            
            HASH_ADD(hh, chunk_table, index_info.chunk_idx, hash_keylen,
                     &chunk_list->chunk_infos[last_assigned_idx]);

            last_assigned_idx++;
        }
        else {
            H5D_piece_info_t *chunk_info = chunk_entry->chunk_info;
            unsigned char    *mod_data_p = NULL;
            hsize_t           iter_nelmts;
            size_t            mod_data_size = 0;
            size_t            space_size    = 0;

            
            mod_data_size += hash_keylen;

            
            if (H5S_encode(chunk_info->fspace, &mod_data_p, &space_size) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "unable to get encoded dataspace size");
            mod_data_size += space_size;

            
            iter_nelmts = H5S_GET_SELECT_NPOINTS(chunk_info->mspace);
            H5_CHECK_OVERFLOW(iter_nelmts, hsize_t, size_t);

            mod_data_size += (size_t)iter_nelmts * chunk_info->dset_info->type_info.src_type_size;

            if (NULL == (msg_send_bufs[num_send_requests] = H5MM_malloc(mod_data_size)))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk modification message buffer");

            mod_data_p = msg_send_bufs[num_send_requests];

            
            H5MM_memcpy(mod_data_p, &chunk_entry->index_info.chunk_idx, hash_keylen);
            mod_data_p += hash_keylen;

            
            if (H5S_encode(chunk_info->fspace, &mod_data_p, &mod_data_size) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTENCODE, FAIL, "unable to encode dataspace");

            
            if (H5S_select_iter_init(mem_iter, chunk_info->mspace,
                                     chunk_info->dset_info->type_info.src_type_size,
                                     H5S_SEL_ITER_SHARE_WITH_DATASPACE) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                            "unable to initialize memory selection information");
            mem_iter_init = true;

            
            if (0 ==
                H5D__gather_mem(chunk_info->dset_info->buf.cvp, mem_iter, (size_t)iter_nelmts, mod_data_p))
                HGOTO_ERROR(H5E_IO, H5E_CANTGATHER, FAIL, "couldn't gather from write buffer");

            
            H5_CHECK_OVERFLOW(mod_data_size, size_t, int);

            
            if (MPI_SUCCESS !=
                (mpi_code = MPI_Issend(msg_send_bufs[num_send_requests], (int)mod_data_size, MPI_BYTE,
                                       chunk_entry->new_owner, H5D_CHUNK_MOD_DATA_TAG, io_info->comm,
                                       &send_requests[num_send_requests])))
                HMPI_GOTO_ERROR(FAIL, "MPI_Issend failed", mpi_code)

            num_send_requests++;

            
            if (num_send_requests == send_bufs_nalloc) {
                void *tmp_alloc;

                send_bufs_nalloc = (size_t)((double)send_bufs_nalloc * 1.5);

                if (NULL ==
                    (tmp_alloc = H5MM_realloc(msg_send_bufs, send_bufs_nalloc * sizeof(*msg_send_bufs))))
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                                "couldn't resize chunk modification message buffer array");
                msg_send_bufs = tmp_alloc;

                if (NULL ==
                    (tmp_alloc = H5MM_realloc(send_requests, send_bufs_nalloc * sizeof(*send_requests))))
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't resize send requests array");
                send_requests = tmp_alloc;
            }

            if (H5S_SELECT_ITER_RELEASE(mem_iter) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "couldn't release memory selection iterator");
            mem_iter_init = false;
        }
    }

    
    if (num_send_requests > INT_MAX || num_msgs_incoming > INT_MAX)
        HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL,
                    "too many shared chunks in parallel filtered write operation");

    H5_CHECK_OVERFLOW(num_send_requests, size_t, int);
    H5_CHECK_OVERFLOW(num_msgs_incoming, size_t, int);

    
    if (num_msgs_incoming) {
        if (NULL == (msg_recv_bufs = H5MM_malloc(num_msgs_incoming * sizeof(*msg_recv_bufs))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                        "couldn't allocate chunk modification message buffer array");

        if (NULL == (recv_requests = H5MM_malloc(num_msgs_incoming * sizeof(*recv_requests))))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate receive requests array");
    }

    
    do {
        MPI_Status status;
        int        msg_flag;

        
        if (MPI_SUCCESS != (mpi_code = MPI_Iprobe(MPI_ANY_SOURCE, H5D_CHUNK_MOD_DATA_TAG, io_info->comm,
                                                  &msg_flag, &status)))
            HMPI_GOTO_ERROR(FAIL, "MPI_Iprobe failed", mpi_code)

        
        if (msg_flag) {
            MPI_Count msg_size = 0;

            if (MPI_SUCCESS != (mpi_code = MPI_Get_elements_x(&status, MPI_BYTE, &msg_size)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Get_elements_x failed", mpi_code)

            H5_CHECK_OVERFLOW(msg_size, MPI_Count, int);
            if (msg_size <= 0)
                HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "invalid chunk modification message size");

            assert((num_recv_requests + 1) <= num_msgs_incoming);
            if (NULL ==
                (msg_recv_bufs[num_recv_requests] = H5MM_malloc((size_t)msg_size * sizeof(unsigned char))))
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL,
                            "couldn't allocate chunk modification message receive buffer");

            if (MPI_SUCCESS != (mpi_code = MPI_Irecv(msg_recv_bufs[num_recv_requests], (int)msg_size,
                                                     MPI_BYTE, status.MPI_SOURCE, H5D_CHUNK_MOD_DATA_TAG,
                                                     io_info->comm, &recv_requests[num_recv_requests])))
                HMPI_GOTO_ERROR(FAIL, "MPI_Irecv failed", mpi_code)

            num_recv_requests++;
        }

        if (ibarrier_posted) {
            int ibarrier_completed;

            if (MPI_SUCCESS != (mpi_code = MPI_Test(&ibarrier, &ibarrier_completed, MPI_STATUS_IGNORE)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Test failed", mpi_code)

            if (ibarrier_completed)
                break;
        }
        else {
            int all_sends_completed;

            
            H5_WARN_MPI_STATUSES_IGNORE_OFF
            if (MPI_SUCCESS != (mpi_code = MPI_Testall((int)num_send_requests, send_requests,
                                                       &all_sends_completed, MPI_STATUSES_IGNORE)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Testall failed", mpi_code)
            H5_WARN_MPI_STATUSES_IGNORE_ON

            if (all_sends_completed) {
                
                if (MPI_SUCCESS != (mpi_code = MPI_Ibarrier(io_info->comm, &ibarrier)))
                    HMPI_GOTO_ERROR(FAIL, "MPI_Ibarrier failed", mpi_code)
                ibarrier_posted = true;

                
                if (msg_send_bufs) {
                    for (size_t i = 0; i < num_send_requests; i++) {
                        if (msg_send_bufs[i])
                            H5MM_free(msg_send_bufs[i]);
                    }

                    msg_send_bufs = H5MM_xfree(msg_send_bufs);
                }
            }
        }
    } while (1);

    
    H5_WARN_MPI_STATUSES_IGNORE_OFF
    if (MPI_SUCCESS != (mpi_code = MPI_Waitall((int)num_recv_requests, recv_requests, MPI_STATUSES_IGNORE)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Waitall failed", mpi_code)
    H5_WARN_MPI_STATUSES_IGNORE_ON

    
    chunk_list->num_chunk_infos = last_assigned_idx;

    
    chunk_list->chunk_hash_table = chunk_table;

    
    *chunk_msg_bufs     = msg_recv_bufs;
    *chunk_msg_bufs_len = (int)num_recv_requests;

done:
    if (ret_value < 0) {
        
        if (!ibarrier_posted) {
            if (MPI_SUCCESS != (mpi_code = MPI_Ibarrier(io_info->comm, &ibarrier)))
                HMPI_GOTO_ERROR(FAIL, "MPI_Ibarrier failed", mpi_code)
        }

        if (num_send_requests) {
            for (size_t i = 0; i < num_send_requests; i++) {
                MPI_Cancel(&send_requests[i]);
            }
        }

        if (recv_requests) {
            for (size_t i = 0; i < num_recv_requests; i++) {
                MPI_Cancel(&recv_requests[i]);
            }
        }

        if (msg_recv_bufs) {
            for (size_t i = 0; i < num_recv_requests; i++) {
                H5MM_free(msg_recv_bufs[i]);
            }

            H5MM_free(msg_recv_bufs);
        }

        HASH_CLEAR(hh, chunk_table);
    }

    if (recv_requests)
        H5MM_free(recv_requests);
    if (send_requests)
        H5MM_free(send_requests);

    if (msg_send_bufs) {
        for (size_t i = 0; i < num_send_requests; i++) {
            if (msg_send_bufs[i])
                H5MM_free(msg_send_bufs[i]);
        }

        H5MM_free(msg_send_bufs);
    }

    if (mem_iter) {
        if (mem_iter_init && H5S_SELECT_ITER_RELEASE(mem_iter) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "couldn't release dataspace selection iterator");
        mem_iter = H5FL_FREE(H5S_sel_iter_t, mem_iter);
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_chunk_read(H5D_filtered_collective_io_info_t *chunk_list,
                                         const H5D_io_info_t *io_info, size_t num_dset_infos, int mpi_rank)
{
    H5Z_EDC_t err_detect; 
    H5Z_cb_t  filter_cb;  
    herr_t    ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(io_info);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Filtered collective chunk read");
#else
    (void)mpi_rank;
#endif

    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = &chunk_list->chunk_infos[info_idx];
        H5D_mpio_filtered_dset_info_t        *cached_dset_info;
        hsize_t                               file_chunk_size;

        assert(chunk_entry->need_read);

        
        if (num_dset_infos > 1) {
            HASH_FIND(hh, chunk_list->dset_info.dset_info_hash_table, &chunk_entry->index_info.dset_oloc_addr,
                      sizeof(haddr_t), cached_dset_info);
            if (cached_dset_info == NULL) {
                if (chunk_list->all_dset_indices_empty)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
                else {
                    
                    HDONE_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
                    break;
                }
            }
        }
        else
            cached_dset_info = chunk_list->dset_info.single_dset_info;
        assert(cached_dset_info);

        file_chunk_size = cached_dset_info->file_chunk_size;

        chunk_entry->chunk_buf_size = MAX(chunk_entry->chunk_current.length, file_chunk_size);

        if (NULL == (chunk_entry->buf = H5MM_malloc(chunk_entry->chunk_buf_size))) {
            if (chunk_list->all_dset_indices_empty)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk data buffer");
            else {
                
                HDONE_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk data buffer");
                break;
            }
        }

        
        if (cached_dset_info->index_empty || !H5_addr_defined(chunk_entry->chunk_current.offset)) {
            chunk_entry->need_read = false;

            
            assert(chunk_list->num_chunks_to_read > 0);
            chunk_list->num_chunks_to_read--;
        }

        if (chunk_entry->need_read) {
            
            if (chunk_entry->skip_filter_pline)
                chunk_entry->chunk_new.length = file_chunk_size;
            else
                chunk_entry->chunk_new.length = chunk_entry->chunk_current.length;
        }
        else {
            
            chunk_entry->chunk_new.length = file_chunk_size;

            
            if (cached_dset_info->should_fill) {
                assert(cached_dset_info->fb_info_init);
                assert(cached_dset_info->fb_info.fill_buf);

                
                if (H5D__fill(cached_dset_info->fb_info.fill_buf,
                              cached_dset_info->dset_io_info->type_info.dset_type, chunk_entry->buf,
                              cached_dset_info->dset_io_info->type_info.mem_type,
                              cached_dset_info->fill_space) < 0) {
                    if (chunk_list->all_dset_indices_empty)
                        HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                                    "couldn't fill chunk buffer with fill value");
                    else {
                        
                        HDONE_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                                    "couldn't fill chunk buffer with fill value");
                        break;
                    }
                }
            }
        }
    }

    
    if (!chunk_list->all_dset_indices_empty)
        if (H5D__mpio_collective_filtered_vec_io(chunk_list, io_info->f_sh, H5D_IO_OP_READ) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "couldn't perform vector I/O on filtered chunks");

    if (chunk_list->num_chunk_infos) {
        
        if (H5CX_get_err_detect(&err_detect) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get error detection info");
        if (H5CX_get_filter_cb(&filter_cb) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get I/O filter callback function");
    }

    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = &chunk_list->chunk_infos[info_idx];
        H5D_piece_info_t                     *chunk_info  = chunk_entry->chunk_info;
        hsize_t                               iter_nelmts;

        
        if (chunk_entry->need_read && !chunk_entry->skip_filter_pline) {
            if (H5Z_pipeline(&chunk_info->dset_info->dset->shared->dcpl_cache.pline, H5Z_FLAG_REVERSE,
                             &(chunk_entry->index_info.filter_mask), err_detect, filter_cb,
                             (size_t *)&chunk_entry->chunk_new.length, &chunk_entry->chunk_buf_size,
                             &chunk_entry->buf) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFILTER, FAIL, "couldn't unfilter chunk for modifying");
        }

        
        iter_nelmts = H5S_GET_SELECT_NPOINTS(chunk_info->fspace);

        if (H5D_select_io_mem(chunk_info->dset_info->buf.vp, chunk_info->mspace, chunk_entry->buf,
                              chunk_info->fspace, chunk_info->dset_info->type_info.src_type_size,
                              (size_t)iter_nelmts) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "couldn't copy chunk data to read buffer");
    }

done:
    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        if (chunk_list->chunk_infos[info_idx].buf) {
            H5MM_free(chunk_list->chunk_infos[info_idx].buf);
            chunk_list->chunk_infos[info_idx].buf = NULL;
        }
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_chunk_update(H5D_filtered_collective_io_info_t *chunk_list,
                                           unsigned char **chunk_msg_bufs, int chunk_msg_bufs_len,
                                           const H5D_io_info_t *io_info, size_t num_dset_infos, int mpi_rank)
{
    H5S_sel_iter_t *sel_iter = NULL; 
    H5Z_EDC_t       err_detect;      
    H5Z_cb_t        filter_cb;       
    uint8_t        *key_buf       = NULL;
    H5S_t          *dataspace     = NULL;
    bool            sel_iter_init = false;
    herr_t          ret_value     = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert((chunk_msg_bufs && chunk_list->chunk_hash_table) || 0 == chunk_msg_bufs_len);
    assert(io_info);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Filtered collective chunk update");
#endif

    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = &chunk_list->chunk_infos[info_idx];
        H5D_mpio_filtered_dset_info_t        *cached_dset_info;
        hsize_t                               file_chunk_size;

        assert(mpi_rank == chunk_entry->new_owner);

        
        if (num_dset_infos > 1) {
            HASH_FIND(hh, chunk_list->dset_info.dset_info_hash_table, &chunk_entry->index_info.dset_oloc_addr,
                      sizeof(haddr_t), cached_dset_info);
            if (cached_dset_info == NULL) {
                if (chunk_list->all_dset_indices_empty)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
                else {
                    
                    HDONE_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
                    break;
                }
            }
        }
        else
            cached_dset_info = chunk_list->dset_info.single_dset_info;
        assert(cached_dset_info);

        file_chunk_size = cached_dset_info->file_chunk_size;

        chunk_entry->chunk_buf_size = MAX(chunk_entry->chunk_current.length, file_chunk_size);

        
        if (!H5_addr_defined(chunk_entry->chunk_current.offset) && !cached_dset_info->should_fill)
            chunk_entry->buf = H5MM_calloc(chunk_entry->chunk_buf_size);
        else
            chunk_entry->buf = H5MM_malloc(chunk_entry->chunk_buf_size);

        if (NULL == chunk_entry->buf) {
            if (chunk_list->all_dset_indices_empty)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk data buffer");
            else {
                
                HDONE_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate chunk data buffer");
                break;
            }
        }

        if (!chunk_entry->need_read)
            
            chunk_entry->chunk_new.length = file_chunk_size;
        else {
            
            if (cached_dset_info->index_empty || !H5_addr_defined(chunk_entry->chunk_current.offset)) {
                chunk_entry->need_read = false;

                
                assert(chunk_list->num_chunks_to_read > 0);
                chunk_list->num_chunks_to_read--;
            }

            if (chunk_entry->need_read) {
                
                if (chunk_entry->skip_filter_pline)
                    chunk_entry->chunk_new.length = file_chunk_size;
                else
                    chunk_entry->chunk_new.length = chunk_entry->chunk_current.length;
            }
            else {
                
                chunk_entry->chunk_new.length = file_chunk_size;

                
                if (cached_dset_info->should_fill) {
                    assert(cached_dset_info->fb_info_init);
                    assert(cached_dset_info->fb_info.fill_buf);

                    
                    if (H5D__fill(cached_dset_info->fb_info.fill_buf,
                                  cached_dset_info->dset_io_info->type_info.dset_type, chunk_entry->buf,
                                  cached_dset_info->dset_io_info->type_info.mem_type,
                                  cached_dset_info->fill_space) < 0) {
                        if (chunk_list->all_dset_indices_empty)
                            HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                                        "couldn't fill chunk buffer with fill value");
                        else {
                            
                            HDONE_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                                        "couldn't fill chunk buffer with fill value");
                            break;
                        }
                    }
                }
            }
        }
    }

    
    if (!chunk_list->all_dset_indices_empty)
        if (H5D__mpio_collective_filtered_vec_io(chunk_list, io_info->f_sh, H5D_IO_OP_READ) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "couldn't perform vector I/O on filtered chunks");

    

    if (chunk_list->num_chunk_infos > 0) {
        
        if (H5CX_get_err_detect(&err_detect) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get error detection info");
        if (H5CX_get_filter_cb(&filter_cb) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't get I/O filter callback function");
    }

    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = &chunk_list->chunk_infos[info_idx];
        H5D_piece_info_t                     *chunk_info  = chunk_entry->chunk_info;
        hsize_t                               iter_nelmts;

        assert(mpi_rank == chunk_entry->new_owner);

        
        if (chunk_entry->need_read && !chunk_entry->skip_filter_pline) {
            if (H5Z_pipeline(&chunk_info->dset_info->dset->shared->dcpl_cache.pline, H5Z_FLAG_REVERSE,
                             &(chunk_entry->index_info.filter_mask), err_detect, filter_cb,
                             (size_t *)&chunk_entry->chunk_new.length, &chunk_entry->chunk_buf_size,
                             &chunk_entry->buf) < 0)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFILTER, FAIL, "couldn't unfilter chunk for modifying");
        }

        iter_nelmts = H5S_GET_SELECT_NPOINTS(chunk_info->mspace);

        if (H5D_select_io_mem(chunk_entry->buf, chunk_info->fspace, chunk_info->dset_info->buf.cvp,
                              chunk_info->mspace, chunk_info->dset_info->type_info.dst_type_size,
                              (size_t)iter_nelmts) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "couldn't copy chunk data to write buffer");
    }

    
    if (chunk_msg_bufs_len > 0) {
        assert(chunk_list->chunk_hash_table_keylen > 0);
        if (NULL == (key_buf = H5MM_malloc(chunk_list->chunk_hash_table_keylen)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate hash table key buffer");

        if (NULL == (sel_iter = H5FL_MALLOC(H5S_sel_iter_t)))
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "couldn't allocate memory iterator");
    }

    
    for (size_t buf_idx = 0; buf_idx < (size_t)chunk_msg_bufs_len; buf_idx++) {
        H5D_filtered_collective_chunk_info_t *chunk_entry = NULL;
        const unsigned char                  *msg_ptr     = chunk_msg_bufs[buf_idx];

        if (msg_ptr) {
            
            H5MM_memcpy(key_buf, msg_ptr, chunk_list->chunk_hash_table_keylen);
            msg_ptr += chunk_list->chunk_hash_table_keylen;

            
            HASH_FIND(hh, chunk_list->chunk_hash_table, key_buf, chunk_list->chunk_hash_table_keylen,
                      chunk_entry);
            if (chunk_entry == NULL)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find chunk entry");
            if (mpi_rank != chunk_entry->new_owner)
                HGOTO_ERROR(H5E_DATASET, H5E_BADVALUE, FAIL, "chunk owner set to incorrect MPI rank");

            
            if (!chunk_entry->buf)
                continue;
            else {
                hsize_t iter_nelmts;

                
                if (NULL == (dataspace = H5S_decode(&msg_ptr)))
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTDECODE, FAIL, "unable to decode dataspace");

                if (H5S_select_iter_init(sel_iter, dataspace,
                                         chunk_entry->chunk_info->dset_info->type_info.dst_type_size,
                                         H5S_SEL_ITER_SHARE_WITH_DATASPACE) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTINIT, FAIL,
                                "unable to initialize memory selection information");
                sel_iter_init = true;

                iter_nelmts = H5S_GET_SELECT_NPOINTS(dataspace);

                
                if (H5D__scatter_mem(msg_ptr, sel_iter, (size_t)iter_nelmts, chunk_entry->buf) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "couldn't scatter to write buffer");

                if (H5S_SELECT_ITER_RELEASE(sel_iter) < 0)
                    HGOTO_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "couldn't release selection iterator");
                sel_iter_init = false;

                if (dataspace) {
                    if (H5S_close(dataspace) < 0)
                        HGOTO_ERROR(H5E_DATASPACE, H5E_CANTFREE, FAIL, "can't close dataspace");
                    dataspace = NULL;
                }

                H5MM_free(chunk_msg_bufs[buf_idx]);
                chunk_msg_bufs[buf_idx] = NULL;
            }
        }
    }

    
    for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
        if (!chunk_list->chunk_infos[info_idx].skip_filter_pline) {
            if (H5Z_pipeline(
                    &chunk_list->chunk_infos[info_idx].chunk_info->dset_info->dset->shared->dcpl_cache.pline,
                    0, &(chunk_list->chunk_infos[info_idx].index_info.filter_mask), err_detect, filter_cb,
                    (size_t *)&chunk_list->chunk_infos[info_idx].chunk_new.length,
                    &chunk_list->chunk_infos[info_idx].chunk_buf_size,
                    &chunk_list->chunk_infos[info_idx].buf) < 0)
                HGOTO_ERROR(H5E_PLINE, H5E_CANTFILTER, FAIL, "output pipeline failed");
        }

#if H5_SIZEOF_SIZE_T > 4
        
        if (chunk_list->chunk_infos[info_idx].chunk_new.length > ((size_t)0xffffffff))
            HGOTO_ERROR(H5E_DATASET, H5E_BADRANGE, FAIL, "chunk too large for 32-bit length");
#endif
    }

done:
    if (dataspace && (H5S_close(dataspace) < 0))
        HDONE_ERROR(H5E_DATASPACE, H5E_CANTFREE, FAIL, "can't close dataspace");

    if (sel_iter) {
        if (sel_iter_init && H5S_SELECT_ITER_RELEASE(sel_iter) < 0)
            HDONE_ERROR(H5E_DATASET, H5E_CANTFREE, FAIL, "couldn't release selection iterator");
        sel_iter = H5FL_FREE(H5S_sel_iter_t, sel_iter);
    }

    H5MM_free(key_buf);

    
    if (ret_value < 0) {
        for (size_t info_idx = 0; info_idx < chunk_list->num_chunk_infos; info_idx++) {
            if (chunk_list->chunk_infos[info_idx].buf) {
                H5MM_free(chunk_list->chunk_infos[info_idx].buf);
                chunk_list->chunk_infos[info_idx].buf = NULL;
            }
        }
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_chunk_reallocate(H5D_filtered_collective_io_info_t *chunk_list,
                                               size_t *num_chunks_assigned_map, H5D_io_info_t *io_info,
                                               size_t num_dset_infos, int mpi_rank, int mpi_size)
{
    H5D_chunk_alloc_info_t *collective_list = NULL;
    MPI_Datatype            send_type;
    MPI_Datatype            recv_type;
    bool                    send_type_derived          = false;
    bool                    recv_type_derived          = false;
    bool                    need_sort                  = false;
    size_t                  collective_num_entries     = 0;
    size_t                  num_local_chunks_processed = 0;
    void                   *gathered_array             = NULL;
    int                    *counts_disps_array         = NULL;
    int                    *counts_ptr                 = NULL;
    int                    *displacements_ptr          = NULL;
    int                     mpi_code;
    herr_t                  ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(io_info);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Reallocation of chunk file space");
#endif

    
    H5_CHECK_OVERFLOW(chunk_list->num_chunk_infos, size_t, int);

    
    if (H5D__mpio_get_chunk_alloc_info_types(&recv_type, &recv_type_derived, &send_type, &send_type_derived) <
        0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL,
                    "can't create derived datatypes for chunk file space info");

    
    if (num_chunks_assigned_map) {
        
        if (NULL == (counts_disps_array = H5MM_malloc(2 * (size_t)mpi_size * sizeof(*counts_disps_array)))) {
            
            HDONE_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                        "couldn't allocate receive counts and displacements array");
        }
        else {
            
            counts_ptr = counts_disps_array;

            for (int curr_rank = 0; curr_rank < mpi_size; curr_rank++)
                H5_CHECKED_ASSIGN(counts_ptr[curr_rank], int, num_chunks_assigned_map[curr_rank], size_t);

            
            displacements_ptr = &counts_disps_array[mpi_size];

            *displacements_ptr = 0;
            for (int curr_rank = 1; curr_rank < mpi_size; curr_rank++)
                displacements_ptr[curr_rank] = displacements_ptr[curr_rank - 1] + counts_ptr[curr_rank - 1];
        }

        
        if (H5_mpio_gatherv_alloc(chunk_list->chunk_infos, (int)chunk_list->num_chunk_infos, send_type,
                                  counts_ptr, displacements_ptr, recv_type, true, 0, io_info->comm, mpi_rank,
                                  mpi_size, &gathered_array, &collective_num_entries) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGATHER, FAIL,
                        "can't gather chunk file space info to/from ranks");
    }
    else {
        
        if (H5_mpio_gatherv_alloc_simple(chunk_list->chunk_infos, (int)chunk_list->num_chunk_infos, send_type,
                                         recv_type, true, 0, io_info->comm, mpi_rank, mpi_size,
                                         &gathered_array, &collective_num_entries) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGATHER, FAIL,
                        "can't gather chunk file space info to/from ranks");
    }

    
    collective_list            = (H5D_chunk_alloc_info_t *)gathered_array;
    num_local_chunks_processed = 0;
    for (size_t entry_idx = 0; entry_idx < collective_num_entries; entry_idx++) {
        H5D_mpio_filtered_dset_info_t *cached_dset_info;
        H5D_chunk_alloc_info_t        *coll_entry = &collective_list[entry_idx];
        bool                           need_insert;
        bool                           update_local_chunk;

        
        if (num_dset_infos > 1) {
            HASH_FIND(hh, chunk_list->dset_info.dset_info_hash_table, &coll_entry->dset_oloc_addr,
                      sizeof(haddr_t), cached_dset_info);
            if (cached_dset_info == NULL)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
        }
        else
            cached_dset_info = chunk_list->dset_info.single_dset_info;
        assert(cached_dset_info);

        if (H5D__chunk_file_alloc(&cached_dset_info->chunk_idx_info, &coll_entry->chunk_current,
                                  &coll_entry->chunk_new, &need_insert, NULL) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTALLOC, FAIL, "unable to allocate chunk");

        
        update_local_chunk =
            (num_local_chunks_processed < chunk_list->num_chunk_infos) &&
            (coll_entry->dset_oloc_addr ==
             chunk_list->chunk_infos[num_local_chunks_processed].index_info.dset_oloc_addr) &&
            (coll_entry->chunk_idx ==
             chunk_list->chunk_infos[num_local_chunks_processed].index_info.chunk_idx);

        if (update_local_chunk) {
            H5D_filtered_collective_chunk_info_t *local_chunk;

            local_chunk = &chunk_list->chunk_infos[num_local_chunks_processed];

            
            assert(mpi_rank == local_chunk->orig_owner);
            assert(mpi_rank == local_chunk->new_owner);

            local_chunk->chunk_new              = coll_entry->chunk_new;
            local_chunk->index_info.need_insert = need_insert;

            
            if (num_local_chunks_processed) {
                haddr_t curr_chunk_offset = local_chunk->chunk_new.offset;
                haddr_t prev_chunk_offset =
                    chunk_list->chunk_infos[num_local_chunks_processed - 1].chunk_new.offset;

                assert(H5_addr_defined(prev_chunk_offset) && H5_addr_defined(curr_chunk_offset));
                if (curr_chunk_offset < prev_chunk_offset)
                    need_sort = true;
            }

            num_local_chunks_processed++;
        }
    }

    assert(chunk_list->num_chunk_infos == num_local_chunks_processed);

    
    if (need_sort)
        qsort(chunk_list->chunk_infos, chunk_list->num_chunk_infos,
              sizeof(H5D_filtered_collective_chunk_info_t), H5D__cmp_filtered_collective_io_info_entry);

done:
    H5MM_free(gathered_array);
    H5MM_free(counts_disps_array);

    if (send_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&send_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (recv_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&recv_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_chunk_reinsert(H5D_filtered_collective_io_info_t *chunk_list,
                                             size_t *num_chunks_assigned_map, H5D_io_info_t *io_info,
                                             size_t num_dset_infos, int mpi_rank, int mpi_size)
{
    MPI_Datatype send_type;
    MPI_Datatype recv_type;
    size_t       collective_num_entries = 0;
    bool         send_type_derived      = false;
    bool         recv_type_derived      = false;
    void        *gathered_array         = NULL;
    int         *counts_disps_array     = NULL;
    int         *counts_ptr             = NULL;
    int         *displacements_ptr      = NULL;
    int          mpi_code;
    herr_t       ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(io_info);

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TRACE_ENTER(mpi_rank);
    H5D_MPIO_TIME_START(mpi_rank, "Reinsertion of modified chunks into chunk index");
#endif

    
    if (chunk_list->no_dset_index_insert_methods)
        HGOTO_DONE(SUCCEED);

    
    H5_CHECK_OVERFLOW(chunk_list->num_chunk_infos, size_t, int);

    
    if (H5D__mpio_get_chunk_insert_info_types(&recv_type, &recv_type_derived, &send_type,
                                              &send_type_derived) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL,
                    "can't create derived datatypes for chunk re-insertion info");

    
    if (num_chunks_assigned_map) {
        
        if (NULL == (counts_disps_array = H5MM_malloc(2 * (size_t)mpi_size * sizeof(*counts_disps_array)))) {
            
            HDONE_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                        "couldn't allocate receive counts and displacements array");
        }
        else {
            
            counts_ptr = counts_disps_array;

            for (int curr_rank = 0; curr_rank < mpi_size; curr_rank++)
                H5_CHECKED_ASSIGN(counts_ptr[curr_rank], int, num_chunks_assigned_map[curr_rank], size_t);

            
            displacements_ptr = &counts_disps_array[mpi_size];

            *displacements_ptr = 0;
            for (int curr_rank = 1; curr_rank < mpi_size; curr_rank++)
                displacements_ptr[curr_rank] = displacements_ptr[curr_rank - 1] + counts_ptr[curr_rank - 1];
        }

        
        if (H5_mpio_gatherv_alloc(chunk_list->chunk_infos, (int)chunk_list->num_chunk_infos, send_type,
                                  counts_ptr, displacements_ptr, recv_type, true, 0, io_info->comm, mpi_rank,
                                  mpi_size, &gathered_array, &collective_num_entries) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGATHER, FAIL,
                        "can't gather chunk index re-insertion info to/from ranks");
    }
    else {
        
        if (H5_mpio_gatherv_alloc_simple(chunk_list->chunk_infos, (int)chunk_list->num_chunk_infos, send_type,
                                         recv_type, true, 0, io_info->comm, mpi_rank, mpi_size,
                                         &gathered_array, &collective_num_entries) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTGATHER, FAIL,
                        "can't gather chunk index re-insertion info to/from ranks");
    }

    for (size_t entry_idx = 0; entry_idx < collective_num_entries; entry_idx++) {
        H5D_mpio_filtered_dset_info_t *cached_dset_info;
        H5D_chunk_insert_info_t       *coll_entry = &((H5D_chunk_insert_info_t *)gathered_array)[entry_idx];
        H5D_chunk_ud_t                 chunk_ud;
        haddr_t                        prev_tag = HADDR_UNDEF;
        hsize_t                        scaled_coords[H5O_LAYOUT_NDIMS];

        
        if (!coll_entry->index_info.need_insert)
            continue;

        
        if (num_dset_infos > 1) {
            HASH_FIND(hh, chunk_list->dset_info.dset_info_hash_table, &coll_entry->index_info.dset_oloc_addr,
                      sizeof(haddr_t), cached_dset_info);
            if (cached_dset_info == NULL)
                HGOTO_ERROR(H5E_DATASET, H5E_CANTFIND, FAIL, "unable to find cached dataset info entry");
        }
        else
            cached_dset_info = chunk_list->dset_info.single_dset_info;
        assert(cached_dset_info);

        chunk_ud.common.layout  = &cached_dset_info->chunk_idx_info.layout->u.chunk;
        chunk_ud.common.storage = &cached_dset_info->chunk_idx_info.layout->storage.u.chunk;
        chunk_ud.common.scaled  = scaled_coords;

        chunk_ud.chunk_block = coll_entry->chunk_block;
        chunk_ud.chunk_idx   = coll_entry->index_info.chunk_idx;
        chunk_ud.filter_mask = coll_entry->index_info.filter_mask;

        
        if (cached_dset_info->chunk_idx_info.layout->u.chunk.idx_type == H5D_CHUNK_IDX_EARRAY &&
            cached_dset_info->chunk_idx_info.layout->u.chunk.u.earray.unlim_dim > 0) {
            
            H5VM_array_calc_pre(
                chunk_ud.chunk_idx, cached_dset_info->dset_io_info->dset->shared->ndims,
                cached_dset_info->chunk_idx_info.layout->u.chunk.u.earray.swizzled_down_chunks,
                scaled_coords);

            H5VM_unswizzle_coords(hsize_t, scaled_coords,
                                  cached_dset_info->chunk_idx_info.layout->u.chunk.u.earray.unlim_dim);
        }
        else {
            H5VM_array_calc_pre(chunk_ud.chunk_idx, cached_dset_info->dset_io_info->dset->shared->ndims,
                                cached_dset_info->dset_io_info->dset->shared->layout.u.chunk.down_chunks,
                                scaled_coords);
        }

        scaled_coords[cached_dset_info->dset_io_info->dset->shared->ndims] = 0;

#ifndef NDEBUG
        
        for (size_t dbg_idx = 0; dbg_idx < chunk_list->num_chunk_infos; dbg_idx++) {
            bool same_chunk;

            
            same_chunk = (0 == H5_addr_cmp(coll_entry->index_info.dset_oloc_addr,
                                           chunk_list->chunk_infos[dbg_idx].index_info.dset_oloc_addr));
            same_chunk = same_chunk && (coll_entry->index_info.chunk_idx ==
                                        chunk_list->chunk_infos[dbg_idx].index_info.chunk_idx);

            if (same_chunk) {
                bool coords_match =
                    !memcmp(scaled_coords, chunk_list->chunk_infos[dbg_idx].chunk_info->scaled,
                            cached_dset_info->dset_io_info->dset->shared->ndims * sizeof(hsize_t));

                assert(coords_match && "Calculated scaled coordinates for chunk didn't match "
                                       "chunk's actual scaled coordinates!");
                break;
            }
        }
#endif

        
        H5AC_tag(cached_dset_info->dset_io_info->dset->oloc.addr, &prev_tag);

        if ((cached_dset_info->chunk_idx_info.layout->storage.u.chunk.ops->insert)(
                &cached_dset_info->chunk_idx_info, &chunk_ud, cached_dset_info->dset_io_info->dset) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_CANTINSERT, FAIL, "unable to insert chunk address into index");

        
        H5AC_tag(prev_tag, NULL);
    }

done:
    H5MM_free(gathered_array);
    H5MM_free(counts_disps_array);

    if (send_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&send_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (recv_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&recv_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

#ifdef H5Dmpio_DEBUG
    H5D_MPIO_TIME_STOP(mpi_rank);
    H5D_MPIO_TRACE_EXIT(mpi_rank);
#endif

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_get_chunk_redistribute_info_types(MPI_Datatype *contig_type, bool *contig_type_derived,
                                            MPI_Datatype *resized_type, bool *resized_type_derived)
{
    MPI_Datatype struct_type              = MPI_DATATYPE_NULL;
    bool         struct_type_derived      = false;
    MPI_Datatype chunk_block_type         = MPI_DATATYPE_NULL;
    bool         chunk_block_type_derived = false;
    MPI_Datatype types[6];
    MPI_Aint     displacements[6];
    int          block_lengths[6];
    int          field_count;
    int          mpi_code;
    herr_t       ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(contig_type);
    assert(contig_type_derived);
    assert(resized_type);
    assert(resized_type_derived);

    *contig_type_derived  = false;
    *resized_type_derived = false;

    
    if (H5F_mpi_get_file_block_type(false, &chunk_block_type, &chunk_block_type_derived) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't create derived type for chunk file description");

    field_count = 6;
    assert(field_count == (sizeof(types) / sizeof(MPI_Datatype)));

    
    block_lengths[0] = 1;
    block_lengths[1] = 1;
    block_lengths[2] = 1;
    block_lengths[3] = 1;
    block_lengths[4] = 1;
    block_lengths[5] = 1;
    displacements[0] = offsetof(H5D_chunk_redistribute_info_t, chunk_block);
    displacements[1] = offsetof(H5D_chunk_redistribute_info_t, chunk_idx);
    displacements[2] = offsetof(H5D_chunk_redistribute_info_t, dset_oloc_addr);
    displacements[3] = offsetof(H5D_chunk_redistribute_info_t, orig_owner);
    displacements[4] = offsetof(H5D_chunk_redistribute_info_t, new_owner);
    displacements[5] = offsetof(H5D_chunk_redistribute_info_t, num_writers);
    types[0]         = chunk_block_type;
    types[1]         = HSIZE_AS_MPI_TYPE;
    types[2]         = HADDR_AS_MPI_TYPE;
    types[3]         = MPI_INT;
    types[4]         = MPI_INT;
    types[5]         = MPI_INT;
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    *contig_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

    
    block_lengths[0] = 1;
    block_lengths[1] = 1;
    block_lengths[2] = 1;
    block_lengths[3] = 1;
    block_lengths[4] = 1;
    block_lengths[5] = 1;
    displacements[0] = offsetof(H5D_filtered_collective_chunk_info_t, chunk_current);
    displacements[1] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.chunk_idx);
    displacements[2] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.dset_oloc_addr);
    displacements[3] = offsetof(H5D_filtered_collective_chunk_info_t, orig_owner);
    displacements[4] = offsetof(H5D_filtered_collective_chunk_info_t, new_owner);
    displacements[5] = offsetof(H5D_filtered_collective_chunk_info_t, num_writers);
    types[0]         = chunk_block_type;
    types[1]         = HSIZE_AS_MPI_TYPE;
    types[2]         = HADDR_AS_MPI_TYPE;
    types[3]         = MPI_INT;
    types[4]         = MPI_INT;
    types[5]         = MPI_INT;
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, &struct_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    struct_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_resized(
                            struct_type, 0, sizeof(H5D_filtered_collective_chunk_info_t), resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_resized failed", mpi_code)
    *resized_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

done:
    if (struct_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&struct_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (chunk_block_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&chunk_block_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

    if (ret_value < 0) {
        if (*resized_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(resized_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *resized_type_derived = false;
        }
        if (*contig_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(contig_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *contig_type_derived = false;
        }
    }

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_get_chunk_alloc_info_types(MPI_Datatype *contig_type, bool *contig_type_derived,
                                     MPI_Datatype *resized_type, bool *resized_type_derived)
{
    MPI_Datatype struct_type              = MPI_DATATYPE_NULL;
    bool         struct_type_derived      = false;
    MPI_Datatype chunk_block_type         = MPI_DATATYPE_NULL;
    bool         chunk_block_type_derived = false;
    MPI_Datatype types[4];
    MPI_Aint     displacements[4];
    int          block_lengths[4];
    int          field_count;
    int          mpi_code;
    herr_t       ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(contig_type);
    assert(contig_type_derived);
    assert(resized_type);
    assert(resized_type_derived);

    *contig_type_derived  = false;
    *resized_type_derived = false;

    
    if (H5F_mpi_get_file_block_type(false, &chunk_block_type, &chunk_block_type_derived) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't create derived type for chunk file description");

    field_count = 4;
    assert(field_count == (sizeof(types) / sizeof(MPI_Datatype)));

    
    block_lengths[0] = 1;
    block_lengths[1] = 1;
    block_lengths[2] = 1;
    block_lengths[3] = 1;
    displacements[0] = offsetof(H5D_chunk_alloc_info_t, chunk_current);
    displacements[1] = offsetof(H5D_chunk_alloc_info_t, chunk_new);
    displacements[2] = offsetof(H5D_chunk_alloc_info_t, chunk_idx);
    displacements[3] = offsetof(H5D_chunk_alloc_info_t, dset_oloc_addr);
    types[0]         = chunk_block_type;
    types[1]         = chunk_block_type;
    types[2]         = HSIZE_AS_MPI_TYPE;
    types[3]         = HADDR_AS_MPI_TYPE;
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    *contig_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

    
    block_lengths[0] = 1;
    block_lengths[1] = 1;
    block_lengths[2] = 1;
    block_lengths[3] = 1;
    displacements[0] = offsetof(H5D_filtered_collective_chunk_info_t, chunk_current);
    displacements[1] = offsetof(H5D_filtered_collective_chunk_info_t, chunk_new);
    displacements[2] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.chunk_idx);
    displacements[3] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.dset_oloc_addr);
    types[0]         = chunk_block_type;
    types[1]         = chunk_block_type;
    types[2]         = HSIZE_AS_MPI_TYPE;
    types[3]         = HADDR_AS_MPI_TYPE;
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, &struct_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    struct_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_resized(
                            struct_type, 0, sizeof(H5D_filtered_collective_chunk_info_t), resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_resized failed", mpi_code)
    *resized_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

done:
    if (struct_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&struct_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (chunk_block_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&chunk_block_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

    if (ret_value < 0) {
        if (*resized_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(resized_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *resized_type_derived = false;
        }
        if (*contig_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(contig_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *contig_type_derived = false;
        }
    }

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_get_chunk_insert_info_types(MPI_Datatype *contig_type, bool *contig_type_derived,
                                      MPI_Datatype *resized_type, bool *resized_type_derived)
{
    MPI_Datatype struct_type              = MPI_DATATYPE_NULL;
    bool         struct_type_derived      = false;
    MPI_Datatype chunk_block_type         = MPI_DATATYPE_NULL;
    bool         chunk_block_type_derived = false;
    MPI_Aint     contig_type_extent;
    MPI_Datatype types[5];
    MPI_Aint     displacements[5];
    int          block_lengths[5];
    int          field_count;
    int          mpi_code;
    herr_t       ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(contig_type);
    assert(contig_type_derived);
    assert(resized_type);
    assert(resized_type_derived);

    *contig_type_derived  = false;
    *resized_type_derived = false;

    
    if (H5F_mpi_get_file_block_type(false, &chunk_block_type, &chunk_block_type_derived) < 0)
        HGOTO_ERROR(H5E_DATASET, H5E_CANTGET, FAIL, "can't create derived type for chunk file description");

    field_count = 5;
    assert(field_count == (sizeof(types) / sizeof(MPI_Datatype)));

    
    block_lengths[0] = 1;
    block_lengths[1] = 1;
    block_lengths[2] = 1;
    block_lengths[3] = 1;
    block_lengths[4] = 1;
    displacements[0] = offsetof(H5D_chunk_insert_info_t, chunk_block);
    displacements[1] = offsetof(H5D_chunk_insert_info_t, index_info.chunk_idx);
    displacements[2] = offsetof(H5D_chunk_insert_info_t, index_info.dset_oloc_addr);
    displacements[3] = offsetof(H5D_chunk_insert_info_t, index_info.filter_mask);
    displacements[4] = offsetof(H5D_chunk_insert_info_t, index_info.need_insert);
    types[0]         = chunk_block_type;
    types[1]         = HSIZE_AS_MPI_TYPE;
    types[2]         = HADDR_AS_MPI_TYPE;
    types[3]         = MPI_UNSIGNED;
    types[4]         = MPI_C_BOOL;
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, &struct_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    struct_type_derived = true;

    contig_type_extent = (MPI_Aint)(sizeof(H5F_block_t) + sizeof(H5D_chunk_index_info_t));

    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_resized(struct_type, 0, contig_type_extent, contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_resized failed", mpi_code)
    *contig_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(contig_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

    struct_type_derived = false;
    if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&struct_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_free failed", mpi_code)

    
    displacements[0] = offsetof(H5D_filtered_collective_chunk_info_t, chunk_new);
    displacements[1] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.chunk_idx);
    displacements[2] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.dset_oloc_addr);
    displacements[3] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.filter_mask);
    displacements[4] = offsetof(H5D_filtered_collective_chunk_info_t, index_info.need_insert);
    if (MPI_SUCCESS !=
        (mpi_code = MPI_Type_create_struct(field_count, block_lengths, displacements, types, &struct_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_struct failed", mpi_code)
    struct_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_create_resized(
                            struct_type, 0, sizeof(H5D_filtered_collective_chunk_info_t), resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_create_resized failed", mpi_code)
    *resized_type_derived = true;

    if (MPI_SUCCESS != (mpi_code = MPI_Type_commit(resized_type)))
        HMPI_GOTO_ERROR(FAIL, "MPI_Type_commit failed", mpi_code)

done:
    if (struct_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&struct_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }
    if (chunk_block_type_derived) {
        if (MPI_SUCCESS != (mpi_code = MPI_Type_free(&chunk_block_type)))
            HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
    }

    if (ret_value < 0) {
        if (*resized_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(resized_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *resized_type_derived = false;
        }
        if (*contig_type_derived) {
            if (MPI_SUCCESS != (mpi_code = MPI_Type_free(contig_type)))
                HMPI_DONE_ERROR(FAIL, "MPI_Type_free failed", mpi_code)
            *contig_type_derived = false;
        }
    }

    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5D__mpio_collective_filtered_vec_io(const H5D_filtered_collective_io_info_t *chunk_list, H5F_shared_t *f_sh,
                                     H5D_io_op_type_t op_type)
{
    const void **io_wbufs = NULL;
    void       **io_rbufs = NULL;
    H5FD_mem_t   io_types[2];
    uint32_t     iovec_count = 0;
    haddr_t     *io_addrs    = NULL;
    size_t      *io_sizes    = NULL;
    herr_t       ret_value   = SUCCEED;

    FUNC_ENTER_PACKAGE

    assert(chunk_list);
    assert(f_sh);

    if (op_type == H5D_IO_OP_WRITE)
        iovec_count = (uint32_t)chunk_list->num_chunk_infos;
    else {
        assert(chunk_list->num_chunks_to_read <= chunk_list->num_chunk_infos);
        iovec_count = (uint32_t)chunk_list->num_chunks_to_read;
    }

    if (iovec_count > 0) {
        if (chunk_list->num_chunk_infos > UINT32_MAX)
            HGOTO_ERROR(H5E_INTERNAL, H5E_BADRANGE, FAIL,
                        "number of chunk entries in I/O operation exceeds UINT32_MAX");

        if (NULL == (io_addrs = H5MM_malloc(iovec_count * sizeof(*io_addrs))))
            HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                        "couldn't allocate space for I/O addresses vector");
        if (NULL == (io_sizes = H5MM_malloc(iovec_count * sizeof(*io_sizes))))
            HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "couldn't allocate space for I/O sizes vector");

        if (op_type == H5D_IO_OP_WRITE) {
            if (NULL == (io_wbufs = H5MM_malloc(iovec_count * sizeof(*io_wbufs))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "couldn't allocate space for I/O buffers vector");
        }
        else {
            if (NULL == (io_rbufs = H5MM_malloc(iovec_count * sizeof(*io_rbufs))))
                HGOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL,
                            "couldn't allocate space for I/O buffers vector");
        }

        
        io_types[0] = H5FD_MEM_DRAW;
        io_types[1] = H5FD_MEM_NOLIST;

        for (size_t i = 0, vec_idx = 0; i < chunk_list->num_chunk_infos; i++) {
            H5F_block_t *chunk_block;

            if (op_type == H5D_IO_OP_READ && !chunk_list->chunk_infos[i].need_read)
                continue;

            
            assert(vec_idx < iovec_count);

            
            chunk_block = (op_type == H5D_IO_OP_READ) ? &chunk_list->chunk_infos[i].chunk_current
                                                      : &chunk_list->chunk_infos[i].chunk_new;

            assert(H5_addr_defined(chunk_block->offset));
            io_addrs[vec_idx] = chunk_block->offset;

            
#ifndef NDEBUG
            if (vec_idx > 0)
                assert(io_addrs[vec_idx] > io_addrs[vec_idx - 1]);
#endif

            io_sizes[vec_idx] = (size_t)chunk_block->length;

            if (op_type == H5D_IO_OP_WRITE)
                io_wbufs[vec_idx] = chunk_list->chunk_infos[i].buf;
            else
                io_rbufs[vec_idx] = chunk_list->chunk_infos[i].buf;

            vec_idx++;
        }
    }

    if (op_type == H5D_IO_OP_WRITE) {
        if (H5F_shared_vector_write(f_sh, iovec_count, io_types, io_addrs, io_sizes, io_wbufs) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_WRITEERROR, FAIL, "vector write call failed");
    }
    else {
        if (H5F_shared_vector_read(f_sh, iovec_count, io_types, io_addrs, io_sizes, io_rbufs) < 0)
            HGOTO_ERROR(H5E_DATASET, H5E_READERROR, FAIL, "vector read call failed");
    }

done:
    H5MM_free(io_wbufs);
    H5MM_free(io_rbufs);
    H5MM_free(io_sizes);
    H5MM_free(io_addrs);

    FUNC_LEAVE_NOAPI(ret_value)
}

#ifdef H5Dmpio_DEBUG

static herr_t
H5D__mpio_dump_collective_filtered_chunk_list(H5D_filtered_collective_io_info_t *chunk_list, int mpi_rank)
{
    H5D_filtered_collective_chunk_info_t *chunk_entry;
    size_t                                i;
    herr_t                                ret_value = SUCCEED;

    FUNC_ENTER_PACKAGE_NOERR

    H5D_MPIO_DEBUG(mpi_rank, "CHUNK LIST: [");
    for (i = 0; i < chunk_list->num_chunk_infos; i++) {
        unsigned chunk_rank;

        chunk_entry = &chunk_list->chunk_infos[i];

        assert(chunk_entry->chunk_info);
        chunk_rank = (unsigned)H5S_GET_EXTENT_NDIMS(chunk_entry->chunk_info->fspace);

        H5D_MPIO_DEBUG(mpi_rank, " {");
        H5D_MPIO_DEBUG_VA(mpi_rank, "   - Entry %zu -", i);

        H5D_MPIO_DEBUG(mpi_rank, "   - Chunk Fspace Info -");
        H5D_MPIO_DEBUG_VA(mpi_rank,
                          "     Chunk Current Info: { Offset: %" PRIuHADDR ", Length: %" PRIuHADDR " }",
                          chunk_entry->chunk_current.offset, chunk_entry->chunk_current.length);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk New Info: { Offset: %" PRIuHADDR ", Length: %" PRIuHADDR " }",
                          chunk_entry->chunk_new.offset, chunk_entry->chunk_new.length);

        H5D_MPIO_DEBUG(mpi_rank, "   - Chunk Insert Info -");
        H5D_MPIO_DEBUG_VA(mpi_rank,
                          "     Chunk Scaled Coords (4-d): { %" PRIuHSIZE ", %" PRIuHSIZE ", %" PRIuHSIZE
                          ", %" PRIuHSIZE " }",
                          chunk_rank < 1 ? 0 : chunk_entry->chunk_info->scaled[0],
                          chunk_rank < 2 ? 0 : chunk_entry->chunk_info->scaled[1],
                          chunk_rank < 3 ? 0 : chunk_entry->chunk_info->scaled[2],
                          chunk_rank < 4 ? 0 : chunk_entry->chunk_info->scaled[3]);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk Index: %" PRIuHSIZE, chunk_entry->index_info.chunk_idx);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Dataset Object Header Address: %" PRIuHADDR,
                          chunk_entry->index_info.dset_oloc_addr);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Filter Mask: %u", chunk_entry->index_info.filter_mask);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Need Insert: %s",
                          chunk_entry->index_info.need_insert ? "YES" : "NO");

        H5D_MPIO_DEBUG(mpi_rank, "   - Other Info -");
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk Info Ptr: %p", (void *)chunk_entry->chunk_info);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Need Read: %s", chunk_entry->need_read ? "YES" : "NO");
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk I/O Size: %zu", chunk_entry->io_size);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk Buffer Size: %zu", chunk_entry->chunk_buf_size);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Original Owner: %d", chunk_entry->orig_owner);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     New Owner: %d", chunk_entry->new_owner);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     # of Writers: %d", chunk_entry->num_writers);
        H5D_MPIO_DEBUG_VA(mpi_rank, "     Chunk Data Buffer Ptr: %p", (void *)chunk_entry->buf);

        H5D_MPIO_DEBUG(mpi_rank, " }");
    }
    H5D_MPIO_DEBUG(mpi_rank, "]");

    FUNC_LEAVE_NOAPI(ret_value)
} 

#endif

#endif 
