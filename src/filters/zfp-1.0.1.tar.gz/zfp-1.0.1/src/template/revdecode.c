static void _t2(rev_inv_xform, Int, DIMS)(Int* p);

/* private functions ------------------------------------------------------- */

/* reversible inverse lifting transform of 4-vector */
static void
_t1(rev_inv_lift, Int)(Int* p, uint s)
{
  /* hdf5lib: work in UInt, where the arithmetic wraps exactly as the original
     signed version does in practice; there, overflow and left shifts of
     negative values are undefined behaviour, which UBSan reports. */
  UInt x, y, z, w;
  x = (UInt)*p; p += s;
  y = (UInt)*p; p += s;
  z = (UInt)*p; p += s;
  w = (UInt)*p; p += s;

  /*
  ** high-order Lorenzo transform (P4 Pascal matrix)
  ** ( 1  0  0  0) (x)
  ** ( 1  1  0  0) (y)
  ** ( 1  2  1  0) (z)
  ** ( 1  3  3  1) (w)
  */
  w += z;
  z += y; w += z;
  y += x; z += y; w += z;

  p -= s; *p = (Int)w;
  p -= s; *p = (Int)z;
  p -= s; *p = (Int)y;
  p -= s; *p = (Int)x;
}

/* decode block of integers using reversible algorithm */
static uint
_t2(rev_decode_block, Int, DIMS)(bitstream* stream, uint minbits, uint maxbits, Int* iblock)
{
  /* decode number of significant bits */
  uint bits = PBITS;
  uint prec = (uint)stream_read_bits(stream, PBITS) + 1;
  cache_align_(UInt ublock[BLOCK_SIZE]);
  /* decode integer coefficients */
  bits += _t1(decode_ints, UInt)(stream, maxbits - bits, prec, ublock, BLOCK_SIZE);
  /* read at least minbits bits */
  if (bits < minbits) {
    stream_skip(stream, minbits - bits);
    bits = minbits;
  }
  /* reorder unsigned coefficients and convert to signed integer */
  _t1(inv_order, Int)(ublock, iblock, PERM, BLOCK_SIZE);
  /* perform decorrelating transform */
  _t2(rev_inv_xform, Int, DIMS)(iblock);
  return bits;
}
