static void _t2(rev_fwd_xform, Int, DIMS)(Int* p);

/* private functions ------------------------------------------------------- */

/* reversible forward lifting transform of 4-vector */
static void
_t1(rev_fwd_lift, Int)(Int* p, uint s)
{
  /* hdf5lib: work in UInt, where the arithmetic wraps exactly as the original
     signed version does in practice; there, overflow and left shifts of
     negative values are undefined behaviour, which UBSan reports. */
  UInt x, y, z, w;
  x = (UInt)*p; p += s;
  y = (UInt)*p; p += s;
  z = (UInt)*p; p += s;
  w = (UInt)*p; p += s;

  /*
  ** high-order Lorenzo transform
  ** ( 1  0  0  0) (x)
  ** (-1  1  0  0) (y)
  ** ( 1 -2  1  0) (z)
  ** (-1  3 -3  1) (w)
  */
  w -= z; z -= y; y -= x;
  w -= z; z -= y;
  w -= z;

  p -= s; *p = (Int)w;
  p -= s; *p = (Int)z;
  p -= s; *p = (Int)y;
  p -= s; *p = (Int)x;
}

/* return precision required to encode block reversibly */
static uint
_t1(rev_precision, UInt)(const UInt* block, uint n)
{
  uint p = 0;
  uint s;
  /* compute bitwise OR of all values */
  UInt m = 0;
  while (n--)
    m |= *block++;
  /* count trailing zeros via binary search */
  for (s = (uint)(CHAR_BIT * sizeof(UInt)); m; s /= 2)
    if ((UInt)(m << (s - 1))) {
      m <<= s - 1;
      m <<= 1;
      p += s;
    }
  return p;
}

/* encode block of integers using reversible algorithm */
static uint
_t2(rev_encode_block, Int, DIMS)(bitstream* stream, uint minbits, uint maxbits, uint maxprec, Int* iblock)
{
  uint bits = PBITS;
  uint prec;
  cache_align_(UInt ublock[BLOCK_SIZE]);
  /* perform decorrelating transform */
  _t2(rev_fwd_xform, Int, DIMS)(iblock);
  /* reorder signed coefficients and convert to unsigned integer */
  _t1(fwd_order, Int)(ublock, iblock, PERM, BLOCK_SIZE);
  /* determine and encode number of significant bits */
  prec = _t1(rev_precision, UInt)(ublock, BLOCK_SIZE);
  prec = MIN(prec, maxprec);
  prec = MAX(prec, 1);
  stream_write_bits(stream, prec - 1, PBITS);
  /* encode integer coefficients */
  bits += _t1(encode_ints, UInt)(stream, maxbits - bits, prec, ublock, BLOCK_SIZE);
  /* write at least minbits bits by padding with zeros */
  if (bits < minbits) {
    stream_pad(stream, minbits - bits);
    bits = minbits;
  }
  return bits;
}
