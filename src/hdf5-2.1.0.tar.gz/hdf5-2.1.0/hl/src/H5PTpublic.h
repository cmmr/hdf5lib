/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5PTpublic_H
#define H5PTpublic_H

#ifdef __cplusplus
extern "C" {
#endif

H5HL_DLL hid_t H5PTcreate(hid_t loc_id, const char *dset_name, hid_t dtype_id, hsize_t chunk_size,
                          hid_t plist_id);

H5HL_DLL hid_t H5PTopen(hid_t loc_id, const char *dset_name);

H5HL_DLL herr_t H5PTclose(hid_t table_id);

H5HL_DLL hid_t H5PTcreate_fl(hid_t loc_id, const char *dset_name, hid_t dtype_id, hsize_t chunk_size,
                             int compression);

H5HL_DLL herr_t H5PTappend(hid_t table_id, size_t nrecords, const void *data);

H5HL_DLL herr_t H5PTget_next(hid_t table_id, size_t nrecords, void *data);

H5HL_DLL herr_t H5PTread_packets(hid_t table_id, hsize_t start, size_t nrecords, void *data);

H5HL_DLL herr_t H5PTget_num_packets(hid_t table_id, hsize_t *nrecords);

H5HL_DLL herr_t H5PTis_valid(hid_t table_id);

H5HL_DLL herr_t H5PTis_varlen(hid_t table_id);

H5HL_DLL hid_t H5PTget_dataset(hid_t table_id);

H5HL_DLL hid_t H5PTget_type(hid_t table_id);

H5HL_DLL herr_t H5PTcreate_index(hid_t table_id);

H5HL_DLL herr_t H5PTset_index(hid_t table_id, hsize_t pt_index);

H5HL_DLL herr_t H5PTget_index(hid_t table_id, hsize_t *pt_index);

H5HL_DLL herr_t H5PTfree_vlen_buff(hid_t table_id, size_t bufflen, void *buff);

#ifdef __cplusplus
}
#endif

#endif
