#if defined (__GNUC__)                                            
#if ((__GNUC__ * 100) + __GNUC_MINOR__) >= 402                    
#pragma GCC diagnostic ignored "-Wconversion"                     
#pragma GCC diagnostic ignored "-Wimplicit-function-declaration"  
#pragma GCC diagnostic ignored "-Wmissing-prototypes"             
#pragma GCC diagnostic ignored "-Wnested-externs"                 
#pragma GCC diagnostic ignored "-Wold-style-definition"           
#pragma GCC diagnostic ignored "-Wredundant-decls"                
#pragma GCC diagnostic ignored "-Wsign-compare"                   
#pragma GCC diagnostic ignored "-Wsign-conversion"                
#pragma GCC diagnostic ignored "-Wstrict-overflow"                
#pragma GCC diagnostic ignored "-Wstrict-prototypes"              
#pragma GCC diagnostic ignored "-Wimplicit-fallthrough"           
#if !defined (__clang__)                                          
#pragma GCC diagnostic ignored "-Wlarger-than="                   
#pragma GCC diagnostic ignored "-Wsuggest-attribute=const"        
#pragma GCC diagnostic ignored "-Wsuggest-attribute=pure"         
#endif                                                            
#pragma GCC diagnostic ignored "-Wswitch-default"                 
#pragma GCC diagnostic ignored "-Wunused-function"                
#pragma GCC diagnostic ignored "-Wunused-macros"                  
#pragma GCC diagnostic ignored "-Wunused-parameter"               
#endif                                                            
#if ((__GNUC__ * 100) + __GNUC_MINOR__) >= 600                    
#pragma GCC diagnostic ignored "-Wnull-dereference"               
#endif                                                            
#elif defined _MSC_VER                                            
#pragma warning(push, 1)                                          
#endif                                                            

#include <r_compat.h>

#define YYBISON 30802

#define YYBISON_VERSION "3.8.2"

#define YYSKELETON_NAME "yacc.c"

#define YYPURE 0

#define YYPUSH 0

#define YYPULL 1

#define yyparse         H5LTyyparse
#define yylex           H5LTyylex
#define yyerror         H5LTyyerror
#define yydebug         H5LTyydebug
#define yynerrs         H5LTyynerrs
#define yylval          H5LTyylval
#define yychar          H5LTyychar

#line 19 "hl/src//H5LTparse.y"

#include <stdio.h>
#include <string.h>
#include <hdf5.h>

#include "H5private.h"

extern int yylex(void);
extern int yyerror(const char *);

#define STACK_SIZE      16

struct cmpd_info {
    hid_t       id;             
    bool        is_field;       
    bool        first_memb;     
};

static struct cmpd_info cmpd_stack[STACK_SIZE] = {
    {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1},
    {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1},
    {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1},
    {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1} };

static int csindex = -1;                

struct arr_info {
    hsize_t             dims[H5S_MAX_RANK];     
    unsigned            ndims;                  
    bool                is_dim;                 
};

static struct arr_info arr_stack[STACK_SIZE];
static int asindex = -1;                

static H5T_str_t   str_pad;                
static H5T_cset_t  str_cset;               
static bool        is_variable = 0;        
static size_t      str_size;               
   
static hid_t       enum_id;                
static bool        is_enum = 0;            
static bool        is_enum_memb = 0;       
static char*       enum_memb_symbol;       

#line 128 "hl/src//H5LTparse.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "H5LTparse.h"

enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      
  YYSYMBOL_YYerror = 1,                    
  YYSYMBOL_YYUNDEF = 2,                    
  YYSYMBOL_H5T_STD_I8BE_TOKEN = 3,         
  YYSYMBOL_H5T_STD_I8LE_TOKEN = 4,         
  YYSYMBOL_H5T_STD_I16BE_TOKEN = 5,        
  YYSYMBOL_H5T_STD_I16LE_TOKEN = 6,        
  YYSYMBOL_H5T_STD_I32BE_TOKEN = 7,        
  YYSYMBOL_H5T_STD_I32LE_TOKEN = 8,        
  YYSYMBOL_H5T_STD_I64BE_TOKEN = 9,        
  YYSYMBOL_H5T_STD_I64LE_TOKEN = 10,       
  YYSYMBOL_H5T_STD_U8BE_TOKEN = 11,        
  YYSYMBOL_H5T_STD_U8LE_TOKEN = 12,        
  YYSYMBOL_H5T_STD_U16BE_TOKEN = 13,       
  YYSYMBOL_H5T_STD_U16LE_TOKEN = 14,       
  YYSYMBOL_H5T_STD_U32BE_TOKEN = 15,       
  YYSYMBOL_H5T_STD_U32LE_TOKEN = 16,       
  YYSYMBOL_H5T_STD_U64BE_TOKEN = 17,       
  YYSYMBOL_H5T_STD_U64LE_TOKEN = 18,       
  YYSYMBOL_H5T_NATIVE_CHAR_TOKEN = 19,     
  YYSYMBOL_H5T_NATIVE_SCHAR_TOKEN = 20,    
  YYSYMBOL_H5T_NATIVE_UCHAR_TOKEN = 21,    
  YYSYMBOL_H5T_NATIVE_SHORT_TOKEN = 22,    
  YYSYMBOL_H5T_NATIVE_USHORT_TOKEN = 23,   
  YYSYMBOL_H5T_NATIVE_INT_TOKEN = 24,      
  YYSYMBOL_H5T_NATIVE_UINT_TOKEN = 25,     
  YYSYMBOL_H5T_NATIVE_LONG_TOKEN = 26,     
  YYSYMBOL_H5T_NATIVE_ULONG_TOKEN = 27,    
  YYSYMBOL_H5T_NATIVE_LLONG_TOKEN = 28,    
  YYSYMBOL_H5T_NATIVE_ULLONG_TOKEN = 29,   
  YYSYMBOL_H5T_IEEE_F16BE_TOKEN = 30,      
  YYSYMBOL_H5T_IEEE_F16LE_TOKEN = 31,      
  YYSYMBOL_H5T_IEEE_F32BE_TOKEN = 32,      
  YYSYMBOL_H5T_IEEE_F32LE_TOKEN = 33,      
  YYSYMBOL_H5T_IEEE_F64BE_TOKEN = 34,      
  YYSYMBOL_H5T_IEEE_F64LE_TOKEN = 35,      
  YYSYMBOL_H5T_FLOAT_BFLOAT16BE_TOKEN = 36, 
  YYSYMBOL_H5T_FLOAT_BFLOAT16LE_TOKEN = 37, 
  YYSYMBOL_H5T_FLOAT_F8E4M3_TOKEN = 38,    
  YYSYMBOL_H5T_FLOAT_F8E5M2_TOKEN = 39,    
  YYSYMBOL_H5T_FLOAT_F6E2M3_TOKEN = 40,    
  YYSYMBOL_H5T_FLOAT_F6E3M2_TOKEN = 41,    
  YYSYMBOL_H5T_FLOAT_F4E2M1_TOKEN = 42,    
  YYSYMBOL_H5T_NATIVE_FLOAT16_TOKEN = 43,  
  YYSYMBOL_H5T_NATIVE_FLOAT_TOKEN = 44,    
  YYSYMBOL_H5T_NATIVE_DOUBLE_TOKEN = 45,   
  YYSYMBOL_H5T_NATIVE_LDOUBLE_TOKEN = 46,  
  YYSYMBOL_H5T_COMPLEX_IEEE_F16BE_TOKEN = 47, 
  YYSYMBOL_H5T_COMPLEX_IEEE_F16LE_TOKEN = 48, 
  YYSYMBOL_H5T_COMPLEX_IEEE_F32BE_TOKEN = 49, 
  YYSYMBOL_H5T_COMPLEX_IEEE_F32LE_TOKEN = 50, 
  YYSYMBOL_H5T_COMPLEX_IEEE_F64BE_TOKEN = 51, 
  YYSYMBOL_H5T_COMPLEX_IEEE_F64LE_TOKEN = 52, 
  YYSYMBOL_H5T_NATIVE_FLOAT_COMPLEX_TOKEN = 53, 
  YYSYMBOL_H5T_NATIVE_DOUBLE_COMPLEX_TOKEN = 54, 
  YYSYMBOL_H5T_NATIVE_LDOUBLE_COMPLEX_TOKEN = 55, 
  YYSYMBOL_H5T_STRING_TOKEN = 56,          
  YYSYMBOL_STRSIZE_TOKEN = 57,             
  YYSYMBOL_STRPAD_TOKEN = 58,              
  YYSYMBOL_CSET_TOKEN = 59,                
  YYSYMBOL_CTYPE_TOKEN = 60,               
  YYSYMBOL_H5T_VARIABLE_TOKEN = 61,        
  YYSYMBOL_H5T_STR_NULLTERM_TOKEN = 62,    
  YYSYMBOL_H5T_STR_NULLPAD_TOKEN = 63,     
  YYSYMBOL_H5T_STR_SPACEPAD_TOKEN = 64,    
  YYSYMBOL_H5T_CSET_ASCII_TOKEN = 65,      
  YYSYMBOL_H5T_CSET_UTF8_TOKEN = 66,       
  YYSYMBOL_H5T_C_S1_TOKEN = 67,            
  YYSYMBOL_H5T_FORTRAN_S1_TOKEN = 68,      
  YYSYMBOL_H5T_OPAQUE_TOKEN = 69,          
  YYSYMBOL_OPQ_SIZE_TOKEN = 70,            
  YYSYMBOL_OPQ_TAG_TOKEN = 71,             
  YYSYMBOL_H5T_COMPOUND_TOKEN = 72,        
  YYSYMBOL_H5T_ENUM_TOKEN = 73,            
  YYSYMBOL_H5T_ARRAY_TOKEN = 74,           
  YYSYMBOL_H5T_VLEN_TOKEN = 75,            
  YYSYMBOL_H5T_COMPLEX_TOKEN = 76,         
  YYSYMBOL_STRING = 77,                    
  YYSYMBOL_NUMBER = 78,                    
  YYSYMBOL_79_ = 79,                       
  YYSYMBOL_80_ = 80,                       
  YYSYMBOL_81_ = 81,                       
  YYSYMBOL_82_ = 82,                       
  YYSYMBOL_83_ = 83,                       
  YYSYMBOL_84_ = 84,                       
  YYSYMBOL_YYACCEPT = 85,                  
  YYSYMBOL_start = 86,                     
  YYSYMBOL_ddl_type = 87,                  
  YYSYMBOL_atomic_type = 88,               
  YYSYMBOL_integer_type = 89,              
  YYSYMBOL_fp_type = 90,                   
  YYSYMBOL_compound_type = 91,             
  YYSYMBOL_92_1 = 92,                      
  YYSYMBOL_memb_list = 93,                 
  YYSYMBOL_memb_def = 94,                  
  YYSYMBOL_95_2 = 95,                      
  YYSYMBOL_field_name = 96,                
  YYSYMBOL_field_offset = 97,              
  YYSYMBOL_offset = 98,                    
  YYSYMBOL_array_type = 99,                
  YYSYMBOL_100_3 = 100,                    
  YYSYMBOL_dim_list = 101,                 
  YYSYMBOL_dim = 102,                      
  YYSYMBOL_103_4 = 103,                    
  YYSYMBOL_104_5 = 104,                    
  YYSYMBOL_dimsize = 105,                  
  YYSYMBOL_vlen_type = 106,                
  YYSYMBOL_complex_type = 107,             
  YYSYMBOL_opaque_type = 108,              
  YYSYMBOL_109_6 = 109,                    
  YYSYMBOL_110_7 = 110,                    
  YYSYMBOL_opaque_size = 111,              
  YYSYMBOL_opaque_tag = 112,               
  YYSYMBOL_string_type = 113,              
  YYSYMBOL_114_8 = 114,                    
  YYSYMBOL_115_9 = 115,                    
  YYSYMBOL_116_10 = 116,                   
  YYSYMBOL_117_11 = 117,                   
  YYSYMBOL_strsize = 118,                  
  YYSYMBOL_strpad = 119,                   
  YYSYMBOL_cset = 120,                     
  YYSYMBOL_ctype = 121,                    
  YYSYMBOL_enum_type = 122,                
  YYSYMBOL_123_12 = 123,                   
  YYSYMBOL_enum_list = 124,                
  YYSYMBOL_enum_def = 125,                 
  YYSYMBOL_126_13 = 126,                   
  YYSYMBOL_enum_symbol = 127,              
  YYSYMBOL_enum_val = 128                  
};
typedef enum yysymbol_kind_t yysymbol_kind_t;

#ifdef short
# undef short
#endif

#ifndef __PTRDIFF_MAX__
# include <limits.h> 
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> 
#  define YY_STDINT_H
# endif
#endif

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> 
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> 
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))

typedef yytype_uint8 yy_state_t;

typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> 
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) 
#endif

#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) 
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif

#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> 
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> 
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> 
      
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   
#  define YYSTACK_FREE(Ptr) do { ; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    
#   define YYSTACK_ALLOC_MAXIMUM 4032 
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> 
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); 
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); 
#   endif
#  endif
# endif
#endif 

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED

# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif 

#define YYFINAL  80

#define YYLAST   260

#define YYNTOKENS  85

#define YYNNTS  44

#define YYNRULES  113

#define YYNSTATES  158

#define YYMAXUTOK   333

#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    83,    84,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    81,     2,    82,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    79,     2,    80,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78
};

#if YYDEBUG

static const yytype_int16 yyrline[] =
{
       0,   112,   112,   113,   115,   116,   117,   118,   119,   121,
     122,   123,   124,   125,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
     154,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,   177,   176,
     185,   186,   188,   188,   225,   233,   234,   237,   239,   239,
     248,   249,   251,   252,   251,   259,   262,   266,   267,   268,
     269,   270,   271,   272,   273,   274,   275,   282,   287,   279,
     294,   296,   301,   308,   317,   324,   298,   348,   349,   351,
     352,   353,   355,   356,   358,   359,   363,   362,   367,   368,
     370,   370,   420,   422
};
#endif

#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0

static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "H5T_STD_I8BE_TOKEN",
  "H5T_STD_I8LE_TOKEN", "H5T_STD_I16BE_TOKEN", "H5T_STD_I16LE_TOKEN",
  "H5T_STD_I32BE_TOKEN", "H5T_STD_I32LE_TOKEN", "H5T_STD_I64BE_TOKEN",
  "H5T_STD_I64LE_TOKEN", "H5T_STD_U8BE_TOKEN", "H5T_STD_U8LE_TOKEN",
  "H5T_STD_U16BE_TOKEN", "H5T_STD_U16LE_TOKEN", "H5T_STD_U32BE_TOKEN",
  "H5T_STD_U32LE_TOKEN", "H5T_STD_U64BE_TOKEN", "H5T_STD_U64LE_TOKEN",
  "H5T_NATIVE_CHAR_TOKEN", "H5T_NATIVE_SCHAR_TOKEN",
  "H5T_NATIVE_UCHAR_TOKEN", "H5T_NATIVE_SHORT_TOKEN",
  "H5T_NATIVE_USHORT_TOKEN", "H5T_NATIVE_INT_TOKEN",
  "H5T_NATIVE_UINT_TOKEN", "H5T_NATIVE_LONG_TOKEN",
  "H5T_NATIVE_ULONG_TOKEN", "H5T_NATIVE_LLONG_TOKEN",
  "H5T_NATIVE_ULLONG_TOKEN", "H5T_IEEE_F16BE_TOKEN",
  "H5T_IEEE_F16LE_TOKEN", "H5T_IEEE_F32BE_TOKEN", "H5T_IEEE_F32LE_TOKEN",
  "H5T_IEEE_F64BE_TOKEN", "H5T_IEEE_F64LE_TOKEN",
  "H5T_FLOAT_BFLOAT16BE_TOKEN", "H5T_FLOAT_BFLOAT16LE_TOKEN",
  "H5T_FLOAT_F8E4M3_TOKEN", "H5T_FLOAT_F8E5M2_TOKEN",
  "H5T_FLOAT_F6E2M3_TOKEN", "H5T_FLOAT_F6E3M2_TOKEN",
  "H5T_FLOAT_F4E2M1_TOKEN", "H5T_NATIVE_FLOAT16_TOKEN",
  "H5T_NATIVE_FLOAT_TOKEN", "H5T_NATIVE_DOUBLE_TOKEN",
  "H5T_NATIVE_LDOUBLE_TOKEN", "H5T_COMPLEX_IEEE_F16BE_TOKEN",
  "H5T_COMPLEX_IEEE_F16LE_TOKEN", "H5T_COMPLEX_IEEE_F32BE_TOKEN",
  "H5T_COMPLEX_IEEE_F32LE_TOKEN", "H5T_COMPLEX_IEEE_F64BE_TOKEN",
  "H5T_COMPLEX_IEEE_F64LE_TOKEN", "H5T_NATIVE_FLOAT_COMPLEX_TOKEN",
  "H5T_NATIVE_DOUBLE_COMPLEX_TOKEN", "H5T_NATIVE_LDOUBLE_COMPLEX_TOKEN",
  "H5T_STRING_TOKEN", "STRSIZE_TOKEN", "STRPAD_TOKEN", "CSET_TOKEN",
  "CTYPE_TOKEN", "H5T_VARIABLE_TOKEN", "H5T_STR_NULLTERM_TOKEN",
  "H5T_STR_NULLPAD_TOKEN", "H5T_STR_SPACEPAD_TOKEN",
  "H5T_CSET_ASCII_TOKEN", "H5T_CSET_UTF8_TOKEN", "H5T_C_S1_TOKEN",
  "H5T_FORTRAN_S1_TOKEN", "H5T_OPAQUE_TOKEN", "OPQ_SIZE_TOKEN",
  "OPQ_TAG_TOKEN", "H5T_COMPOUND_TOKEN", "H5T_ENUM_TOKEN",
  "H5T_ARRAY_TOKEN", "H5T_VLEN_TOKEN", "H5T_COMPLEX_TOKEN", "STRING",
  "NUMBER", "'{'", "'}'", "'['", "']'", "':'", "';'", "$accept", "start",
  "ddl_type", "atomic_type", "integer_type", "fp_type", "compound_type",
  "$@1", "memb_list", "memb_def", "$@2", "field_name", "field_offset",
  "offset", "array_type", "$@3", "dim_list", "dim", "$@4", "$@5",
  "dimsize", "vlen_type", "complex_type", "opaque_type", "@6", "$@7",
  "opaque_size", "opaque_tag", "string_type", "$@8", "$@9", "$@10", "@11",
  "strsize", "strpad", "cset", "ctype", "enum_type", "$@12", "enum_list",
  "enum_def", "$@13", "enum_symbol", "enum_val", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-24)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

static const yytype_int16 yypact[] =
{
     154,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -21,   -15,   -24,   -14,   -24,    -4,
      -2,   133,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,    77,    65,    58,   228,    59,   154,   154,
     -24,    75,    61,   -24,    56,   -24,    62,    63,   -24,   -24,
      57,   -24,    60,    76,   -24,    -3,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,    66,   -24,    89,    83,    78,
     -23,   134,   -24,    -1,   136,   -24,   128,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   130,   -24,   131,   138,
     135,   139,   140,   -24,   -24,   -24,   -24,   -24,   -24,   137,
     -24,   159,   144,   -24,   -10,   -24,   -24,   -24,   141,   -24,
     160,     0,   -24,   -24,   174,   -24,   179,   -24
};

static const yytype_int8 yydefact[] =
{
       2,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    81,    80,    83,    82,    85,
      84,    77,    78,    79,     0,     0,    58,     0,    68,     0,
       0,     0,     3,     4,     9,    10,     5,     6,     7,     8,
      13,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       1,     0,     0,    60,     0,    70,     0,     0,    97,    98,
       0,    90,     0,     0,   106,     0,    76,    86,    92,    87,
      59,    62,    61,   108,    72,     0,    71,     0,     0,     0,
       0,     0,    69,     0,     0,    64,    65,   112,   107,   109,
     110,    75,    73,    99,   100,   101,     0,    91,     0,     0,
       0,     0,     0,    93,    88,    67,    66,    63,   113,     0,
      74,     0,     0,   111,     0,    89,   102,   103,     0,    94,
       0,     0,   104,   105,     0,    95,     0,    96
};

static const yytype_int16 yypgoto[] =
{
     -24,   -24,   -19,   -24,   184,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,   -24,
     -24,   -24,   -24,   -24
};

static const yytype_uint8 yydefgoto[] =
{
       0,    61,    62,    63,    64,    65,    66,    75,    93,   102,
     109,   116,   130,   136,    67,    77,    95,   106,   111,   132,
     122,    68,    69,    70,   108,   142,    92,   128,    71,   107,
     141,   150,   156,    90,   126,   148,   154,    72,   103,   110,
     119,   131,   120,   139
};

static const yytype_uint8 yytable[] =
{
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,   117,   146,   147,   118,    73,    86,
      87,   123,   124,   125,    74,    76,    55,   152,   153,    56,
      57,    58,    59,    60,   101,    78,   105,    79,   104,     1,
       2,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    80,    81,    82,    88,    83,    85,    91,
      94,    98,    96,    97,    99,    55,   112,   113,    56,    57,
      58,    59,    60,    89,   114,   115,   100,     1,     2,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,   129,   121,   127,   133,   134,   135,   138,   144,   137,
     151,   143,   140,    55,   145,   149,    56,    57,    58,    59,
      60,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,   155,   157,
      84
};

static const yytype_int8 yycheck[] =
{
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    77,    65,    66,    80,    79,    78,
      79,    62,    63,    64,    79,    79,    69,    67,    68,    72,
      73,    74,    75,    76,    93,    79,    95,    79,    81,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,     0,    57,    70,    61,    79,    79,    78,
      84,    84,    80,    80,    84,    69,    80,    58,    72,    73,
      74,    75,    76,    78,    71,    77,    80,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    83,    78,    77,    84,    84,    78,    78,    59,    84,
      60,    84,    82,    69,    80,    84,    72,    73,    74,    75,
      76,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    84,    80,
      76
};

static const yytype_uint8 yystos[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    69,    72,    73,    74,    75,
      76,    86,    87,    88,    89,    90,    91,    99,   106,   107,
     108,   113,   122,    79,    79,    92,    79,   100,    79,    79,
       0,    57,    70,    79,    89,    79,    87,    87,    61,    78,
     118,    78,   111,    93,    84,   101,    80,    80,    84,    84,
      80,    87,    94,   123,    81,    87,   102,   114,   109,    95,
     124,   103,    80,    58,    71,    77,    96,    77,    80,   125,
     127,    78,   105,    62,    63,    64,   119,    77,   112,    83,
      97,   126,   104,    84,    84,    78,    98,    84,    78,   128,
      82,   115,   110,    84,    59,    80,    65,    66,   120,    84,
     116,    60,    67,    68,   121,    84,   117,    80
};

static const yytype_uint8 yyr1[] =
{
       0,    85,    86,    86,    87,    87,    87,    87,    87,    88,
      88,    88,    88,    88,    89,    89,    89,    89,    89,    89,
      89,    89,    89,    89,    89,    89,    89,    89,    89,    89,
      89,    89,    89,    89,    89,    89,    89,    89,    89,    89,
      89,    90,    90,    90,    90,    90,    90,    90,    90,    90,
      90,    90,    90,    90,    90,    90,    90,    90,    92,    91,
      93,    93,    95,    94,    96,    97,    97,    98,   100,    99,
     101,   101,   103,   104,   102,   105,   106,   107,   107,   107,
     107,   107,   107,   107,   107,   107,   107,   109,   110,   108,
     111,   112,   114,   115,   116,   117,   113,   118,   118,   119,
     119,   119,   120,   120,   121,   121,   123,   122,   124,   124,
     126,   125,   127,   128
};

static const yytype_int8 yyr2[] =
{
       0,     2,     0,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     0,     5,
       0,     2,     0,     5,     1,     0,     2,     1,     0,     6,
       0,     2,     0,     0,     5,     1,     4,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     4,     0,     0,    11,
       1,     1,     0,     0,     0,     0,    19,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     0,     7,     0,     2,
       0,     4,     1,     1
};

enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

#define YYERRCODE YYUNDEF

#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> 
#  define YYFPRINTF Rfprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (Rstderr, "%s ", Title);                                   \
      yy_symbol_print (Rstderr,                                            \
                  Kind, Value); \
      YYFPRINTF (Rstderr, "\n");                                           \
    }                                                                     \
} while (0)

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (Rstderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (Rstderr, " %d", yybot);
    }
  YYFPRINTF (Rstderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (Rstderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (Rstderr, "   $%d = ", yyi + 1);
      yy_symbol_print (Rstderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (Rstderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

int yydebug;
#else 
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif 

#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}

int yychar;

YYSTYPE yylval;

int yynerrs;

hid_t
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    
    int yyerrstatus = 0;

    

    
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  
  int yyresult;
  
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  
  YYSTYPE yyval;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  
  int yylen = 0;

  YYDPRINTF ((Rstderr, "Starting parse\n"));

  yychar = YYEMPTY; 

  goto yysetstate;

yynewstate:
  
  yyssp++;

yysetstate:
  YYDPRINTF ((Rstderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else 
      
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((Rstderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif 

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

yybackup:
  

  
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  

  
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((Rstderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((Rstderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  
  if (yyerrstatus)
    yyerrstatus--;

  
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  
  yychar = YYEMPTY;
  goto yynewstate;

yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;

yyreduce:
  
  yylen = yyr2[yyn];

  
  yyval = yyvsp[1-yylen];

  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: 
#line 112 "hl/src//H5LTparse.y"
                { memset(arr_stack, 0, STACK_SIZE*sizeof(struct arr_info));  }
#line 1412 "hl/src//H5LTparse.c"
    break;

  case 3: 
#line 113 "hl/src//H5LTparse.y"
                          { return (yyval.hid);}
#line 1418 "hl/src//H5LTparse.c"
    break;

  case 14: 
#line 128 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I8BE); }
#line 1424 "hl/src//H5LTparse.c"
    break;

  case 15: 
#line 129 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I8LE); }
#line 1430 "hl/src//H5LTparse.c"
    break;

  case 16: 
#line 130 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I16BE); }
#line 1436 "hl/src//H5LTparse.c"
    break;

  case 17: 
#line 131 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I16LE); }
#line 1442 "hl/src//H5LTparse.c"
    break;

  case 18: 
#line 132 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I32BE); }
#line 1448 "hl/src//H5LTparse.c"
    break;

  case 19: 
#line 133 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I32LE); }
#line 1454 "hl/src//H5LTparse.c"
    break;

  case 20: 
#line 134 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I64BE); }
#line 1460 "hl/src//H5LTparse.c"
    break;

  case 21: 
#line 135 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_I64LE); }
#line 1466 "hl/src//H5LTparse.c"
    break;

  case 22: 
#line 136 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U8BE); }
#line 1472 "hl/src//H5LTparse.c"
    break;

  case 23: 
#line 137 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U8LE); }
#line 1478 "hl/src//H5LTparse.c"
    break;

  case 24: 
#line 138 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U16BE); }
#line 1484 "hl/src//H5LTparse.c"
    break;

  case 25: 
#line 139 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U16LE); }
#line 1490 "hl/src//H5LTparse.c"
    break;

  case 26: 
#line 140 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U32BE); }
#line 1496 "hl/src//H5LTparse.c"
    break;

  case 27: 
#line 141 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U32LE); }
#line 1502 "hl/src//H5LTparse.c"
    break;

  case 28: 
#line 142 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U64BE); }
#line 1508 "hl/src//H5LTparse.c"
    break;

  case 29: 
#line 143 "hl/src//H5LTparse.y"
                                            { (yyval.hid) = H5Tcopy(H5T_STD_U64LE); }
#line 1514 "hl/src//H5LTparse.c"
    break;

  case 30: 
#line 144 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_CHAR); }
#line 1520 "hl/src//H5LTparse.c"
    break;

  case 31: 
#line 145 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_SCHAR); }
#line 1526 "hl/src//H5LTparse.c"
    break;

  case 32: 
#line 146 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_UCHAR); }
#line 1532 "hl/src//H5LTparse.c"
    break;

  case 33: 
#line 147 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_SHORT); }
#line 1538 "hl/src//H5LTparse.c"
    break;

  case 34: 
#line 148 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_USHORT); }
#line 1544 "hl/src//H5LTparse.c"
    break;

  case 35: 
#line 149 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_INT); }
#line 1550 "hl/src//H5LTparse.c"
    break;

  case 36: 
#line 150 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_UINT); }
#line 1556 "hl/src//H5LTparse.c"
    break;

  case 37: 
#line 151 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_LONG); }
#line 1562 "hl/src//H5LTparse.c"
    break;

  case 38: 
#line 152 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_ULONG); }
#line 1568 "hl/src//H5LTparse.c"
    break;

  case 39: 
#line 153 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_LLONG); }
#line 1574 "hl/src//H5LTparse.c"
    break;

  case 40: 
#line 154 "hl/src//H5LTparse.y"
                                                { (yyval.hid) = H5Tcopy(H5T_NATIVE_ULLONG); }
#line 1580 "hl/src//H5LTparse.c"
    break;

  case 41: 
#line 157 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F16BE); }
#line 1586 "hl/src//H5LTparse.c"
    break;

  case 42: 
#line 158 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F16LE); }
#line 1592 "hl/src//H5LTparse.c"
    break;

  case 43: 
#line 159 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F32BE); }
#line 1598 "hl/src//H5LTparse.c"
    break;

  case 44: 
#line 160 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F32LE); }
#line 1604 "hl/src//H5LTparse.c"
    break;

  case 45: 
#line 161 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F64BE); }
#line 1610 "hl/src//H5LTparse.c"
    break;

  case 46: 
#line 162 "hl/src//H5LTparse.y"
                                             { (yyval.hid) = H5Tcopy(H5T_IEEE_F64LE); }
#line 1616 "hl/src//H5LTparse.c"
    break;

  case 47: 
#line 163 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_FLOAT_BFLOAT16BE); }
#line 1622 "hl/src//H5LTparse.c"
    break;

  case 48: 
#line 164 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_FLOAT_BFLOAT16LE); }
#line 1628 "hl/src//H5LTparse.c"
    break;

  case 49: 
#line 165 "hl/src//H5LTparse.y"
                                               { (yyval.hid) = H5Tcopy(H5T_FLOAT_F8E4M3); }
#line 1634 "hl/src//H5LTparse.c"
    break;

  case 50: 
#line 166 "hl/src//H5LTparse.y"
                                               { (yyval.hid) = H5Tcopy(H5T_FLOAT_F8E5M2); }
#line 1640 "hl/src//H5LTparse.c"
    break;

  case 51: 
#line 167 "hl/src//H5LTparse.y"
                                               { (yyval.hid) = H5Tcopy(H5T_FLOAT_F6E2M3); }
#line 1646 "hl/src//H5LTparse.c"
    break;

  case 52: 
#line 168 "hl/src//H5LTparse.y"
                                               { (yyval.hid) = H5Tcopy(H5T_FLOAT_F6E3M2); }
#line 1652 "hl/src//H5LTparse.c"
    break;

  case 53: 
#line 169 "hl/src//H5LTparse.y"
                                               { (yyval.hid) = H5Tcopy(H5T_FLOAT_F4E2M1); }
#line 1658 "hl/src//H5LTparse.c"
    break;

  case 54: 
#line 170 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_NATIVE_FLOAT16); }
#line 1664 "hl/src//H5LTparse.c"
    break;

  case 55: 
#line 171 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_NATIVE_FLOAT); }
#line 1670 "hl/src//H5LTparse.c"
    break;

  case 56: 
#line 172 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_NATIVE_DOUBLE); }
#line 1676 "hl/src//H5LTparse.c"
    break;

  case 57: 
#line 173 "hl/src//H5LTparse.y"
                                                   { (yyval.hid) = H5Tcopy(H5T_NATIVE_LDOUBLE); }
#line 1682 "hl/src//H5LTparse.c"
    break;

  case 58: 
#line 177 "hl/src//H5LTparse.y"
                            { csindex++; cmpd_stack[csindex].id = H5Tcreate(H5T_COMPOUND, 1);  }
#line 1688 "hl/src//H5LTparse.c"
    break;

  case 59: 
#line 179 "hl/src//H5LTparse.y"
                            { (yyval.hid) = cmpd_stack[csindex].id; 
                              cmpd_stack[csindex].id = 0;
                              cmpd_stack[csindex].first_memb = 1; 
                              csindex--;
                            }
#line 1698 "hl/src//H5LTparse.c"
    break;

  case 62: 
#line 188 "hl/src//H5LTparse.y"
                                 { cmpd_stack[csindex].is_field = 1;  }
#line 1704 "hl/src//H5LTparse.c"
    break;

  case 63: 
#line 190 "hl/src//H5LTparse.y"
                        {   
                            size_t origin_size, new_size;
                            hid_t dtype_id = cmpd_stack[csindex].id;

                            
                            if(cmpd_stack[csindex].first_memb) { 
                                new_size = H5Tget_size((yyvsp[-4].hid)) + (yyvsp[-1].ival);
                                H5Tset_size(dtype_id, new_size);
                                
                                H5Tinsert(dtype_id, (yyvsp[-2].sval), (yyvsp[-1].ival), (yyvsp[-4].hid));

                                cmpd_stack[csindex].first_memb = 0;
                            } else {
                                origin_size = H5Tget_size(dtype_id);
                                
                                if((yyvsp[-1].ival) == 0) {
                                    new_size = origin_size + H5Tget_size((yyvsp[-4].hid));
                                    H5Tset_size(dtype_id, new_size);
                                    H5Tinsert(dtype_id, (yyvsp[-2].sval), origin_size, (yyvsp[-4].hid));
                                } else {
                                    new_size = (yyvsp[-1].ival) + H5Tget_size((yyvsp[-4].hid));
                                    H5Tset_size(dtype_id, new_size);
                                    H5Tinsert(dtype_id, (yyvsp[-2].sval), (yyvsp[-1].ival), (yyvsp[-4].hid));
                                }
                            }
                            if((yyvsp[-2].sval)) {
                                free((yyvsp[-2].sval));
                                (yyvsp[-2].sval) = NULL;
                            }
                            cmpd_stack[csindex].is_field = 0;
                            H5Tclose((yyvsp[-4].hid));
                             
                            new_size = H5Tget_size(dtype_id);
                        }
#line 1743 "hl/src//H5LTparse.c"
    break;

  case 64: 
#line 226 "hl/src//H5LTparse.y"
                        {
                            (yyval.sval) = strdup(yylval.sval);
                            free(yylval.sval);
                            yylval.sval = NULL;
                        }
#line 1753 "hl/src//H5LTparse.c"
    break;

  case 65: 
#line 233 "hl/src//H5LTparse.y"
                        { (yyval.ival) = 0; }
#line 1759 "hl/src//H5LTparse.c"
    break;

  case 66: 
#line 235 "hl/src//H5LTparse.y"
                        { (yyval.ival) = yylval.ival; }
#line 1765 "hl/src//H5LTparse.c"
    break;

  case 68: 
#line 239 "hl/src//H5LTparse.y"
                                        { asindex++;  }
#line 1771 "hl/src//H5LTparse.c"
    break;

  case 69: 
#line 241 "hl/src//H5LTparse.y"
                        { 
                          (yyval.hid) = H5Tarray_create2((yyvsp[-1].hid), arr_stack[asindex].ndims, arr_stack[asindex].dims);
                          arr_stack[asindex].ndims = 0;
                          asindex--;
                          H5Tclose((yyvsp[-1].hid));
                        }
#line 1782 "hl/src//H5LTparse.c"
    break;

  case 72: 
#line 251 "hl/src//H5LTparse.y"
                            { arr_stack[asindex].is_dim = 1;  }
#line 1788 "hl/src//H5LTparse.c"
    break;

  case 73: 
#line 252 "hl/src//H5LTparse.y"
                                { unsigned ndims = arr_stack[asindex].ndims;
                                  arr_stack[asindex].dims[ndims] = (hsize_t)yylval.ival; 
                                  arr_stack[asindex].ndims++;
                                  arr_stack[asindex].is_dim = 0; 
                                }
#line 1798 "hl/src//H5LTparse.c"
    break;

  case 76: 
#line 263 "hl/src//H5LTparse.y"
                            { (yyval.hid) = H5Tvlen_create((yyvsp[-1].hid)); H5Tclose((yyvsp[-1].hid)); }
#line 1804 "hl/src//H5LTparse.c"
    break;

  case 77: 
#line 266 "hl/src//H5LTparse.y"
                                                        { (yyval.hid) = H5Tcopy(H5T_NATIVE_FLOAT_COMPLEX); }
#line 1810 "hl/src//H5LTparse.c"
    break;

  case 78: 
#line 267 "hl/src//H5LTparse.y"
                                                         { (yyval.hid) = H5Tcopy(H5T_NATIVE_DOUBLE_COMPLEX); }
#line 1816 "hl/src//H5LTparse.c"
    break;

  case 79: 
#line 268 "hl/src//H5LTparse.y"
                                                          { (yyval.hid) = H5Tcopy(H5T_NATIVE_LDOUBLE_COMPLEX); }
#line 1822 "hl/src//H5LTparse.c"
    break;

  case 80: 
#line 269 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F16LE); }
#line 1828 "hl/src//H5LTparse.c"
    break;

  case 81: 
#line 270 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F16BE); }
#line 1834 "hl/src//H5LTparse.c"
    break;

  case 82: 
#line 271 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F32LE); }
#line 1840 "hl/src//H5LTparse.c"
    break;

  case 83: 
#line 272 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F32BE); }
#line 1846 "hl/src//H5LTparse.c"
    break;

  case 84: 
#line 273 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F64LE); }
#line 1852 "hl/src//H5LTparse.c"
    break;

  case 85: 
#line 274 "hl/src//H5LTparse.y"
                                                      { (yyval.hid) = H5Tcopy(H5T_COMPLEX_IEEE_F64BE); }
#line 1858 "hl/src//H5LTparse.c"
    break;

  case 86: 
#line 276 "hl/src//H5LTparse.y"
                            { (yyval.hid) = H5Tcomplex_create((yyvsp[-1].hid)); H5Tclose((yyvsp[-1].hid)); }
#line 1864 "hl/src//H5LTparse.c"
    break;

  case 87: 
#line 282 "hl/src//H5LTparse.y"
                            {   
                                size_t size = (size_t)yylval.ival;
                                (yyval.hid) = H5Tcreate(H5T_OPAQUE, size);
                            }
#line 1873 "hl/src//H5LTparse.c"
    break;

  case 88: 
#line 287 "hl/src//H5LTparse.y"
                            {  
                                H5Tset_tag((yyvsp[-3].hid), yylval.sval);
                                free(yylval.sval);
                                yylval.sval = NULL;
                            }
#line 1883 "hl/src//H5LTparse.c"
    break;

  case 89: 
#line 292 "hl/src//H5LTparse.y"
                            { (yyval.hid) = (yyvsp[-5].hid); }
#line 1889 "hl/src//H5LTparse.c"
    break;

  case 92: 
#line 301 "hl/src//H5LTparse.y"
                            {  
                                if((yyvsp[-1].ival) == H5T_VARIABLE_TOKEN)
                                    is_variable = 1;
                                else 
                                    str_size = yylval.ival;
                            }
#line 1900 "hl/src//H5LTparse.c"
    break;

  case 93: 
#line 308 "hl/src//H5LTparse.y"
                            {
                                if((yyvsp[-1].ival) == H5T_STR_NULLTERM_TOKEN)
                                    str_pad = H5T_STR_NULLTERM;
                                else if((yyvsp[-1].ival) == H5T_STR_NULLPAD_TOKEN)
                                    str_pad = H5T_STR_NULLPAD;
                                else if((yyvsp[-1].ival) == H5T_STR_SPACEPAD_TOKEN)
                                    str_pad = H5T_STR_SPACEPAD;
                            }
#line 1913 "hl/src//H5LTparse.c"
    break;

  case 94: 
#line 317 "hl/src//H5LTparse.y"
                            {  
                                if((yyvsp[-1].ival) == H5T_CSET_ASCII_TOKEN)
                                    str_cset = H5T_CSET_ASCII;
                                else if((yyvsp[-1].ival) == H5T_CSET_UTF8_TOKEN)
                                    str_cset = H5T_CSET_UTF8;
                            }
#line 1924 "hl/src//H5LTparse.c"
    break;

  case 95: 
#line 324 "hl/src//H5LTparse.y"
                            {
                                if((yyvsp[-1].hid) == H5T_C_S1_TOKEN)
                                    (yyval.hid) = H5Tcopy(H5T_C_S1);
                                else if((yyvsp[-1].hid) == H5T_FORTRAN_S1_TOKEN)
                                    (yyval.hid) = H5Tcopy(H5T_FORTRAN_S1);
                            }
#line 1935 "hl/src//H5LTparse.c"
    break;

  case 96: 
#line 331 "hl/src//H5LTparse.y"
                            {   
                                hid_t str_id = (yyvsp[-1].hid);

                                
                                if(is_variable) {
                                    H5Tset_size(str_id, H5T_VARIABLE);
                                    is_variable = 0;
                                } else
                                    H5Tset_size(str_id, str_size);
                                
                                
                                H5Tset_strpad(str_id, str_pad);
                                H5Tset_cset(str_id, str_cset);

                                (yyval.hid) = str_id; 
                            }
#line 1956 "hl/src//H5LTparse.c"
    break;

  case 97: 
#line 348 "hl/src//H5LTparse.y"
                                               {(yyval.ival) = H5T_VARIABLE_TOKEN;}
#line 1962 "hl/src//H5LTparse.c"
    break;

  case 99: 
#line 351 "hl/src//H5LTparse.y"
                                               {(yyval.ival) = H5T_STR_NULLTERM_TOKEN;}
#line 1968 "hl/src//H5LTparse.c"
    break;

  case 100: 
#line 352 "hl/src//H5LTparse.y"
                                               {(yyval.ival) = H5T_STR_NULLPAD_TOKEN;}
#line 1974 "hl/src//H5LTparse.c"
    break;

  case 101: 
#line 353 "hl/src//H5LTparse.y"
                                               {(yyval.ival) = H5T_STR_SPACEPAD_TOKEN;}
#line 1980 "hl/src//H5LTparse.c"
    break;

  case 102: 
#line 355 "hl/src//H5LTparse.y"
                                             {(yyval.ival) = H5T_CSET_ASCII_TOKEN;}
#line 1986 "hl/src//H5LTparse.c"
    break;

  case 103: 
#line 356 "hl/src//H5LTparse.y"
                                            {(yyval.ival) = H5T_CSET_UTF8_TOKEN;}
#line 1992 "hl/src//H5LTparse.c"
    break;

  case 104: 
#line 358 "hl/src//H5LTparse.y"
                                               {(yyval.hid) = H5T_C_S1_TOKEN;}
#line 1998 "hl/src//H5LTparse.c"
    break;

  case 105: 
#line 359 "hl/src//H5LTparse.y"
                                               {(yyval.hid) = H5T_FORTRAN_S1_TOKEN;}
#line 2004 "hl/src//H5LTparse.c"
    break;

  case 106: 
#line 363 "hl/src//H5LTparse.y"
                            { is_enum = 1; enum_id = H5Tenum_create((yyvsp[-1].hid)); H5Tclose((yyvsp[-1].hid)); }
#line 2010 "hl/src//H5LTparse.c"
    break;

  case 107: 
#line 365 "hl/src//H5LTparse.y"
                            { is_enum = 0;  (yyval.hid) = enum_id; }
#line 2016 "hl/src//H5LTparse.c"
    break;

  case 110: 
#line 370 "hl/src//H5LTparse.y"
                                            {
                                                is_enum_memb = 1; 
                                                enum_memb_symbol = strdup(yylval.sval); 
                                                free(yylval.sval);
                                                yylval.sval = NULL;
                                            }
#line 2027 "hl/src//H5LTparse.c"
    break;

  case 111: 
#line 377 "hl/src//H5LTparse.y"
                            {
                                char char_val=(char)yylval.ival;
                                short short_val=(short)yylval.ival;
                                int int_val=(int)yylval.ival;
                                long long_val=(long)yylval.ival;
                                long long llong_val=(long long)yylval.ival;
                                hid_t super = H5Tget_super(enum_id);
                                hid_t native = H5Tget_native_type(super, H5T_DIR_ASCEND);
                                H5T_order_t super_order = H5Tget_order(super);
                                H5T_order_t native_order = H5Tget_order(native);
 
                                if(is_enum && is_enum_memb) { 
                                    
                                    if(H5Tequal(native, H5T_NATIVE_SCHAR) || H5Tequal(native, H5T_NATIVE_UCHAR)) {
                                        if(super_order != native_order)
                                            H5Tconvert(native, super, 1, &char_val, NULL, H5P_DEFAULT); 
                                        H5Tenum_insert(enum_id, enum_memb_symbol, &char_val);
                                    } else if(H5Tequal(native, H5T_NATIVE_SHORT) || H5Tequal(native, H5T_NATIVE_USHORT)) {
                                        if(super_order != native_order)
                                            H5Tconvert(native, super, 1, &short_val, NULL, H5P_DEFAULT); 
                                        H5Tenum_insert(enum_id, enum_memb_symbol, &short_val);
                                    } else if(H5Tequal(native, H5T_NATIVE_INT) || H5Tequal(native, H5T_NATIVE_UINT)) {
                                        if(super_order != native_order)
                                            H5Tconvert(native, super, 1, &int_val, NULL, H5P_DEFAULT); 
                                        H5Tenum_insert(enum_id, enum_memb_symbol, &int_val);
                                    } else if(H5Tequal(native, H5T_NATIVE_LONG) || H5Tequal(native, H5T_NATIVE_ULONG)) {
                                        if(super_order != native_order)
                                            H5Tconvert(native, super, 1, &long_val, NULL, H5P_DEFAULT); 
                                        H5Tenum_insert(enum_id, enum_memb_symbol, &long_val);
                                    } else if(H5Tequal(native, H5T_NATIVE_LLONG) || H5Tequal(native, H5T_NATIVE_ULLONG)) {
                                        if(super_order != native_order)
                                            H5Tconvert(native, super, 1, &llong_val, NULL, H5P_DEFAULT); 
                                        H5Tenum_insert(enum_id, enum_memb_symbol, &llong_val);
                                    }

                                    is_enum_memb = 0; 
                                    if(enum_memb_symbol) free(enum_memb_symbol);
                                }

                                H5Tclose(super);
                                H5Tclose(native);
                            }
#line 2074 "hl/src//H5LTparse.c"
    break;

#line 2078 "hl/src//H5LTparse.c"

      default: break;
    }
  
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;

yyerrlab:
  
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      

      if (yychar <= YYEOF)
        {
          
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  
  goto yyerrlab1;

yyerrorlab:
  
  if (0)
    YYERROR;
  ++yynerrs;

  
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;

yyerrlab1:
  yyerrstatus = 3;      

  
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      
      if (yyssp == yyss)
        YYABORT;

      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;

yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;

yyabortlab:
  yyresult = 1;
  goto yyreturnlab;

yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;

yyreturnlab:
  if (yychar != YYEMPTY)
    {
      
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

