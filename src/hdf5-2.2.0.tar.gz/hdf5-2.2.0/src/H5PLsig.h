/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5PLsig_H
#define H5PLsig_H

#define H5PL_SIG_MAGIC_LEN 8
static const uint8_t H5PL_SIG_MAGIC[H5PL_SIG_MAGIC_LEN] = {0x89, 'H', 'P', 'S', '\r', '\n', 0x1A, '\n'};

#define H5PL_SIG_FORMAT_VERSION_CURRENT 1

typedef enum {
    H5PL_SIG_ALGO_SHA256     = 0x01, 
    H5PL_SIG_ALGO_SHA384     = 0x02, 
    H5PL_SIG_ALGO_SHA512     = 0x03, 
    H5PL_SIG_ALGO_SHA256_PSS = 0x11, 
    H5PL_SIG_ALGO_SHA384_PSS = 0x12, 
    H5PL_SIG_ALGO_SHA512_PSS = 0x13, 
    H5PL_SIG_ALGO_SHA3_256   = 0x20, 
    H5PL_SIG_ALGO_BLAKE3     = 0x30  
} H5PL_sig_algo_t;

#define H5PL_SIG_FOOTER_SIZE 14

#define H5PL_SIG_ALGO_IS_PSS(id) ((id) >= H5PL_SIG_ALGO_SHA256_PSS && (id) <= H5PL_SIG_ALGO_SHA512_PSS)

#define H5PL_MAX_SIGNATURE_SIZE 1024

#define H5PL_MAX_PLUGIN_SIZE (1024LL * 1024LL * 1024LL)

typedef struct H5PL_sig_footer_t {
    uint32_t        signature_length; 
    H5PL_sig_algo_t algorithm_id;     
    uint8_t         format_version;   
} H5PL_sig_footer_t;

static inline void
H5PL_sig_encode_footer(uint8_t *buf, size_t buf_size, const H5PL_sig_footer_t *footer)
{
    uint8_t *p = buf;

    assert(buf_size >= H5PL_SIG_FOOTER_SIZE);
    (void)buf_size; 

    *p++ = (uint8_t)footer->algorithm_id;          
    UINT32ENCODE(p, footer->signature_length);     
    memcpy(p, H5PL_SIG_MAGIC, H5PL_SIG_MAGIC_LEN); 
    p += H5PL_SIG_MAGIC_LEN;
    *p++ = footer->format_version; 
} 

static inline bool
H5PL_sig_decode_footer(const uint8_t *buf, size_t buf_size, H5PL_sig_footer_t *footer)
{
    const uint8_t *p;

    if (buf_size < H5PL_SIG_FOOTER_SIZE)
        return false;

    
    if (memcmp(buf + 5, H5PL_SIG_MAGIC, H5PL_SIG_MAGIC_LEN) != 0)
        return false;

    
    p                    = buf;
    footer->algorithm_id = (H5PL_sig_algo_t)*p++; 
    UINT32DECODE(p, footer->signature_length);    
    
    p += H5PL_SIG_MAGIC_LEN;       
    footer->format_version = *p++; 

    
    if (footer->format_version < 1 || footer->format_version > H5PL_SIG_FORMAT_VERSION_CURRENT)
        return false;

    return true;
} 

#endif 
